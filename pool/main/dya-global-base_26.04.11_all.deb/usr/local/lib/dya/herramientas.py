"""
herramientas — acciones que la IA de D&A Global OS ejecuta por el usuario.

En vez de limitarse a abrir una aplicación, la IA puede CREAR el resultado:
una presentación (.pptx), un documento de Word (.docx) o una hoja de Excel
(.xlsx), y abrirlo. El modelo redacta el contenido (en JSON) y estas funciones
ponen el diseño: portada, colores del tema, índice, tablas con formato,
gráficos, cuadros destacados, fotos, encabezados y números de página. Así el
resultado es completo aunque la IA local sea pequeña.

Las fotos se buscan en Wikimedia Commons (licencias libres; se cita al autor)
cuando hay internet; sin conexión el diseño usa formas y colores. Todo lo
demás funciona sin internet (python-docx, openpyxl y python-pptx, que va en
vendor/ porque Ubuntu no lo empaqueta).

El asistente invoca una herramienta devolviendo en su JSON:
    "herramienta": {"nombre": "crear_presentacion", "titulo": ..., ...}
y aquí se ejecuta con ejecutar(nombre, args) -> (ok, mensaje).
"""
import concurrent.futures
import datetime
import hashlib
import html
import json
import os
import re
import subprocess
import sys
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor"))

FUENTE = "Ubuntu"
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
         "agosto", "septiembre", "octubre", "noviembre", "diciembre"]

# Colores de cada tema: oscuro (portada y títulos), acento, claro (fondos
# suaves) y extra (detalles y segunda serie de los gráficos).
TEMAS = {
    "azul":    {"oscuro": "1E3A8A", "acento": "2563EB", "claro": "DBEAFE", "extra": "F59E0B"},
    "verde":   {"oscuro": "14532D", "acento": "16A34A", "claro": "DCFCE7", "extra": "F59E0B"},
    "rojo":    {"oscuro": "7F1D1D", "acento": "DC2626", "claro": "FEE2E2", "extra": "2563EB"},
    "morado":  {"oscuro": "4C1D95", "acento": "7C3AED", "claro": "EDE9FE", "extra": "F59E0B"},
    "naranja": {"oscuro": "7C2D12", "acento": "EA580C", "claro": "FFEDD5", "extra": "0EA5E9"},
    "dya":     {"oscuro": "0A1220", "acento": "2EC4B6", "claro": "D5F5F2", "extra": "FF9F1C"},
}
TEXTO = "1F2937"
GRIS = "6B7280"
BORDE = "D1D5DB"
# Si la IA no elige tema, se deduce del tema del contenido
PISTAS_TEMA = [
    ("verde", "recicl naturaleza ambiente ecolog planta bosque salud agua "
              "energía renovable sostenib alimentación huerto deporte"),
    ("rojo", "historia guerra revoluci emergencia seguridad incendio pasión "
             "corazón urgente"),
    ("morado", "arte música cultura creativ moda diseño literatura poesía"),
    ("naranja", "cocina receta turismo viaje verano marketing ventas fiesta"),
    ("dya", "inteligencia artificial ciberseguridad linux programación "
            "software espacio universo"),
]


# ---------- utilidades ----------

def _carpeta_destino():
    """Carpeta donde guardar lo creado: Documentos del usuario, si existe."""
    for var in ("Documentos", "Documents"):
        ruta = os.path.join(os.path.expanduser("~"), var)
        if os.path.isdir(ruta):
            return ruta
    return os.path.expanduser("~")


def _nombre_archivo(titulo, extension):
    base = "".join(c for c in titulo if c.isalnum() or c in " -_").strip()
    base = base.replace(" ", "_")[:60] or "documento"
    marca = datetime.datetime.now().strftime("%Y%m%d-%H%M")
    return os.path.join(_carpeta_destino(), f"{base}-{marca}.{extension}")


def abrir_archivo(ruta):
    try:
        subprocess.Popen(["xdg-open", ruta],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError:
        pass


def _hoy():
    d = datetime.date.today()
    return f"{d.day} de {MESES[d.month - 1]} de {d.year}"


def _tema(nombre, texto=""):
    nombre = str(nombre or "").strip().lower()
    alias = {"blue": "azul", "green": "verde", "red": "rojo", "purple": "morado",
             "violeta": "morado", "orange": "naranja", "oscuro": "dya",
             "negro": "dya", "turquesa": "dya"}
    nombre = alias.get(nombre, nombre)
    if nombre in TEMAS:
        return TEMAS[nombre]
    texto = str(texto).lower()
    for tema, pistas in PISTAS_TEMA:
        if any(re.search(r"\b" + p, texto) for p in pistas.split()):
            return TEMAS[tema]
    return TEMAS["azul"]


def _txt(v):
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        return " ".join(_txt(x) for x in v)
    if isinstance(v, dict):
        return " ".join(_txt(x) for x in v.values())
    return str(v).strip()


def _lista(v):
    """Lista de textos (acepta una cadena con saltos de línea)."""
    if v is None:
        return []
    if isinstance(v, str):
        v = v.split("\n")
    if not isinstance(v, (list, tuple)):
        v = [v]
    salida = []
    for x in v:
        t = _txt(x).lstrip("-•*· ").strip()
        if t:
            salida.append(t)
    return salida


def _tabla(v):
    """Tabla como lista de filas de textos, todas con el mismo ancho."""
    if not isinstance(v, (list, tuple)):
        return []
    filas = []
    for f in v:
        if isinstance(f, dict):
            f = list(f.values())
        if not isinstance(f, (list, tuple)):
            f = [f]
        filas.append([_txt(c) if not isinstance(c, (int, float)) else c for c in f])
    filas = [f for f in filas if any(str(c).strip() for c in f)]
    if not filas:
        return []
    ancho = max(len(f) for f in filas)
    return [list(f) + [""] * (ancho - len(f)) for f in filas]


def _num(v):
    """Número de un texto como «1.234,50 €», «12,5 %» o «9.99»; si no, None."""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    if not s or s.startswith("="):
        return None
    s = re.sub(r"[€$£\s%]|EUR|USD|eur|usd|euros?", "", s)
    if not re.fullmatch(r"[-+]?[\d.,]+", s) or not re.search(r"\d", s):
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(".", "").replace(",", ".") if s.count(",") == 1 else s.replace(",", "")
    elif s.count(".") > 1 or re.fullmatch(r"[-+]?\d{1,3}\.\d{3}", s):
        s = s.replace(".", "")
    try:
        n = float(s)
    except ValueError:
        return None
    return int(n) if n.is_integer() and "." not in s else n


def _grafico(g):
    """Normaliza un gráfico a {"tipo", "titulo", "etiquetas", "series"}."""
    if not isinstance(g, dict):
        return None
    etiquetas = [_txt(e) for e in (g.get("etiquetas") or g.get("categorias") or [])]
    series = []
    for s in g.get("series") or []:
        if isinstance(s, dict):
            vals = [_num(x) for x in (s.get("valores") or [])]
            series.append((_txt(s.get("nombre")) or "Serie", [x or 0 for x in vals]))
    if not series and g.get("valores"):
        series.append((_txt(g.get("nombre")) or _txt(g.get("titulo")) or "Valor",
                       [_num(x) or 0 for x in g["valores"]]))
    if not series or not any(any(v) for _, v in series):
        return None
    largo = max(len(v) for _, v in series)
    etiquetas = (etiquetas + [str(i + 1) for i in range(len(etiquetas), largo)])[:largo]
    series = [(n, (v + [0] * largo)[:largo]) for n, v in series]
    tipo = _txt(g.get("tipo")).lower()
    if any(p in tipo for p in ("circ", "pie", "tarta", "quesito", "sector", "anillo")):
        tipo = "circular"
    elif "line" in tipo or "evol" in tipo:
        tipo = "lineas"
    else:
        tipo = "barras"
    return {"tipo": tipo, "titulo": _txt(g.get("titulo")),
            "etiquetas": etiquetas, "series": series}


def _colores_serie(t):
    return [t["acento"], t["extra"], t["oscuro"], "64748B", "10B981", "F43F5E",
            "8B5CF6", "0EA5E9"]


# ---------- fotos (Wikimedia Commons, con internet) ----------

DIR_FOTOS = os.path.join(os.environ.get("XDG_CACHE_HOME",
                                        os.path.expanduser("~/.cache")),
                         "dya-ia", "fotos")
AGENTE = "DyA-Global-OS/26.04 (https://davidapf.github.io/D-A-Global-OS)"


def _pedir(url, timeout=8):
    peticion = urllib.request.Request(url, headers={"User-Agent": AGENTE})
    with urllib.request.urlopen(peticion, timeout=timeout) as r:
        return r.read()


def _buscar_foto(consulta, contexto=""):
    """Descarga una foto apaisada sobre la consulta. Devuelve (ruta, crédito)
    o None si no hay internet o no se encuentra. Primero prueba con el
    contexto del documento («Venus» + «solar system»): una palabra suelta
    puede traer otra cosa (un cuadro de Botticelli)."""
    consulta, contexto = _txt(consulta), _txt(contexto)
    if not consulta:
        return None
    if contexto and contexto.lower() not in consulta.lower():
        r = _buscar_foto(f"{consulta} {contexto}")
        if r:
            return r
    os.makedirs(DIR_FOTOS, exist_ok=True)
    clave = hashlib.sha1(consulta.lower().encode()).hexdigest()[:16]
    ruta, ruta_info = (os.path.join(DIR_FOTOS, clave + e) for e in (".jpg", ".json"))
    if os.path.exists(ruta) and os.path.exists(ruta_info):
        with open(ruta_info) as f:
            return ruta, json.load(f).get("credito", "")
    url = "https://commons.wikimedia.org/w/api.php?" + urllib.parse.urlencode({
        "action": "query", "format": "json", "generator": "search",
        "gsrsearch": f"{consulta} filetype:bitmap", "gsrnamespace": 6,
        "gsrlimit": 10, "prop": "imageinfo", "iiurlwidth": 1600,
        "iiprop": "url|size|mime|extmetadata",
        "iiextmetadatafilter": "Artist|LicenseShortName"})
    try:
        datos = json.loads(_pedir(url))
    except (OSError, ValueError):
        return None
    paginas = sorted((datos.get("query") or {}).get("pages", {}).values(),
                     key=lambda p: p.get("index", 99))
    candidatas = []
    for p in paginas:
        info = (p.get("imageinfo") or [{}])[0]
        if info.get("mime") not in ("image/jpeg", "image/png") or not info.get("thumburl"):
            continue
        ancho, alto = info.get("width", 0), info.get("height", 1) or 1
        if ancho < 800:
            continue
        # Mejor apaisadas (encajan en diapositivas y páginas)
        candidatas.append((0 if 1.2 <= ancho / alto <= 2.0 else 1, p, info))
    if not candidatas:
        return None
    _, pagina, info = min(candidatas, key=lambda c: c[0])
    try:
        contenido = _pedir(info["thumburl"], timeout=15)
    except OSError:
        return None
    meta = info.get("extmetadata") or {}
    autor = re.sub(r"<[^>]+>", "", html.unescape(meta.get("Artist", {}).get("value", ""))).strip()
    licencia = meta.get("LicenseShortName", {}).get("value", "")
    credito = " · ".join(x for x in (f"Foto: {autor[:60]}" if autor else "Foto",
                                     licencia, "Wikimedia Commons") if x)
    try:
        from PIL import Image
        import io
        imagen = Image.open(io.BytesIO(contenido)).convert("RGB")
        imagen.save(ruta, "JPEG", quality=88)
    except Exception:  # noqa: BLE001 — imagen dañada: sin foto
        return None
    with open(ruta_info, "w") as f:
        json.dump({"credito": credito, "pagina": pagina.get("title", "")}, f)
    return ruta, credito


def _fotos(consultas, contexto=""):
    """Busca varias fotos a la vez. Devuelve {consulta: (ruta, crédito)}."""
    consultas = list(dict.fromkeys(c for c in map(_txt, consultas) if c))
    if not consultas:
        return {}
    print(f"Buscando {len(consultas)} foto(s) en Wikimedia Commons...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
        resultados = list(ex.map(lambda c: _buscar_foto(c, contexto), consultas))
    return {c: r for c, r in zip(consultas, resultados) if r}


def _recortar(ruta, ancho, alto):
    """Copia de la foto recortada a la proporción ancho:alto (sin deformar)."""
    from PIL import Image, ImageOps
    destino = f"{ruta[:-4]}-{int(ancho * 100 / alto)}.jpg"
    if not os.path.exists(destino):
        imagen = Image.open(ruta)
        alto_px = min(imagen.height, int(imagen.width * alto / ancho))
        ImageOps.fit(imagen, (int(alto_px * ancho / alto), alto_px),
                     centering=(0.5, 0.4)).save(destino, "JPEG", quality=88)
    return destino


# ---------- gráfico como imagen (para Word) ----------

def _fuente_pil(tam, negrita=False):
    from PIL import ImageFont
    for nombre in (("Ubuntu-B.ttf" if negrita else "Ubuntu-R.ttf"),
                   ("DejaVuSans-Bold.ttf" if negrita else "DejaVuSans.ttf")):
        for carpeta in ("/usr/share/fonts/truetype/ubuntu", "/usr/share/fonts/truetype/dejavu"):
            ruta = os.path.join(carpeta, nombre)
            if os.path.exists(ruta):
                return ImageFont.truetype(ruta, tam)
    return ImageFont.load_default(tam)


def _fmt(v):
    if isinstance(v, float) and not v.is_integer():
        return f"{v:,.2f}".replace(",", " ").replace(".", ",").replace(" ", ".")
    return f"{int(v):,}".replace(",", ".")


def _grafico_png(g, t, ruta):
    """Dibuja el gráfico (barras, líneas o circular) en un PNG de 1600x900."""
    import math
    from PIL import Image, ImageDraw
    W, H = 1600, 900
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    colores = ["#" + c for c in _colores_serie(t)]
    f_tit, f_txt, f_peq = _fuente_pil(48, True), _fuente_pil(34), _fuente_pil(30)
    arriba = 40
    if g["titulo"]:
        d.text((W / 2, 50), g["titulo"], fill="#" + t["oscuro"], font=f_tit, anchor="mm")
        arriba = 110
    etiquetas, series = g["etiquetas"], g["series"]

    if g["tipo"] == "circular":
        valores = [max(v, 0) for v in series[0][1]]
        total = sum(valores) or 1
        caja = (120, arriba + 20, 120 + H - arriba - 80, H - 60)
        inicio = -90.0
        for i, v in enumerate(valores):
            fin = inicio + 360 * v / total
            d.pieslice(caja, inicio, fin, fill=colores[i % len(colores)], outline="white", width=4)
            medio = math.radians((inicio + fin) / 2)
            cx, cy = (caja[0] + caja[2]) / 2, (caja[1] + caja[3]) / 2
            r = (caja[2] - caja[0]) / 2 * 0.65
            if v / total >= 0.05:
                d.text((cx + r * math.cos(medio), cy + r * math.sin(medio)),
                       f"{round(100 * v / total)} %", fill="white", font=f_txt, anchor="mm")
            inicio = fin
        y = arriba + 60
        for i, (e, v) in enumerate(zip(etiquetas, valores)):
            d.rounded_rectangle((caja[2] + 80, y, caja[2] + 110, y + 30), 6, fill=colores[i % len(colores)])
            d.text((caja[2] + 130, y + 15), f"{e}: {_fmt(v)}", fill="#" + TEXTO, font=f_txt, anchor="lm")
            y += 50
        img.save(ruta)
        return ruta

    maximo = max([max(v) for _, v in series] + [0]) or 1
    minimo = min([min(v) for _, v in series] + [0])
    izq, der, abajo = 190, W - 60, H - (140 if len(series) > 1 else 100)
    # Escala «redonda» y líneas de guía
    paso = 10 ** math.floor(math.log10((maximo - minimo) or 1))
    for m in (1, 2, 5, 10):
        if (maximo - minimo) / (paso * m) <= 6:
            paso *= m
            break
    tope = math.ceil(maximo / paso) * paso or paso
    base = math.floor(minimo / paso) * paso
    def y_de(v):
        return abajo - (v - base) / ((tope - base) or 1) * (abajo - arriba - 20)
    v = base
    while v <= tope + paso / 1000:
        d.line((izq, y_de(v), der, y_de(v)), fill="#E5E7EB", width=2)
        d.text((izq - 15, y_de(v)), _fmt(v), fill="#" + GRIS, font=f_peq, anchor="rm")
        v += paso
    n = len(etiquetas)
    hueco = (der - izq) / max(n, 1)
    for i, e in enumerate(etiquetas):
        d.text((izq + hueco * (i + 0.5), abajo + 35), e[:18], fill="#" + TEXTO, font=f_peq, anchor="mm")
    if g["tipo"] == "lineas":
        for si, (_, vals) in enumerate(series):
            puntos = [(izq + hueco * (i + 0.5), y_de(v)) for i, v in enumerate(vals)]
            if len(puntos) > 1:
                d.line(puntos, fill=colores[si % len(colores)], width=7, joint="curve")
            for x, y in puntos:
                d.ellipse((x - 10, y - 10, x + 10, y + 10), fill=colores[si % len(colores)], outline="white", width=3)
    else:
        ancho = hueco * 0.75 / len(series)
        for si, (_, vals) in enumerate(series):
            for i, v in enumerate(vals):
                x = izq + hueco * i + hueco * 0.125 + ancho * si
                y0, y1 = sorted((y_de(v), y_de(max(base, 0))))
                d.rounded_rectangle((x + 3, y0, x + ancho - 3, y1), 8, fill=colores[si % len(colores)])
                if len(series) * n <= 16:
                    d.text((x + ancho / 2, y0 - 22), _fmt(v), fill="#" + TEXTO, font=f_peq, anchor="mm")
    if len(series) > 1:
        x = izq
        for si, (nombre, _) in enumerate(series):
            d.rounded_rectangle((x, H - 55, x + 30, H - 25), 6, fill=colores[si % len(colores)])
            d.text((x + 42, H - 40), nombre, fill="#" + TEXTO, font=f_txt, anchor="lm")
            x += 70 + d.textlength(nombre, font=f_txt)
    img.save(ruta)
    return ruta


# ---------- presentación (.pptx) ----------

def crear_presentacion(titulo="Presentación", diapositivas=None, subtitulo="",
                       tema="", imagen="", **_):
    """diapositivas: lista de {"titulo", "puntos": [...], "imagen": "foto a
    buscar", "tabla": [[...]], "grafico": {...}, "cita": "...", "notas"}.
    Añade portada, índice, pie con número y diapositiva final."""
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.dml.color import RGBColor
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.oxml.ns import qn
    from pptx.util import Inches, Pt

    titulo = _txt(titulo) or "Presentación"
    lista = []
    for d in diapositivas or []:
        if isinstance(d, str):
            d = {"titulo": d}
        if isinstance(d, dict):
            lista.append(d)
    t = _tema(tema, titulo + " " + json.dumps(lista, ensure_ascii=False))
    fotos = _fotos([imagen] + [d.get("imagen") for d in lista], imagen)

    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    W, H = 13.333, 7.5
    vacia = prs.slide_layouts[6]
    rgb = RGBColor.from_string

    def forma(sl, x, y, w, h, color, tipo=MSO_SHAPE.RECTANGLE):
        s = sl.shapes.add_shape(tipo, Inches(x), Inches(y), Inches(w), Inches(h))
        s.fill.solid()
        s.fill.fore_color.rgb = rgb(color)
        s.line.fill.background()
        s.shadow.inherit = False
        return s

    def texto(sl, x, y, w, h, contenido, tam=18, color=TEXTO, negrita=False,
              alin=PP_ALIGN.LEFT, ancla=MSO_ANCHOR.TOP, cursiva=False):
        caja = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = caja.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = ancla
        for m in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
            setattr(tf, m, Inches(0.05))
        p = tf.paragraphs[0]
        p.alignment = alin
        r = p.add_run()
        r.text = contenido
        r.font.size, r.font.bold, r.font.italic = Pt(tam), negrita, cursiva
        r.font.name = FUENTE
        r.font.color.rgb = rgb(color)
        return caja

    def vinetas(sl, x, y, w, h, puntos, tam=22):
        caja = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = caja.text_frame
        tf.word_wrap = True
        for i, punto in enumerate(puntos):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.space_after = Pt(14)
            ppr = p._p.get_or_add_pPr()
            ppr.set("marL", str(Inches(0.35)))
            ppr.set("indent", str(-Inches(0.35)))
            color = ppr.makeelement(qn("a:buClr"), {})
            color.append(color.makeelement(qn("a:srgbClr"), {"val": t["acento"]}))
            ppr.append(color)
            ppr.append(ppr.makeelement(qn("a:buChar"), {"char": "●"}))
            r = p.add_run()
            r.text = punto
            r.font.size, r.font.name = Pt(tam), FUENTE
            r.font.color.rgb = rgb(TEXTO)
        return caja

    def foto(sl, clave, x, y, w, h, credito=True):
        f = fotos.get(_txt(clave))
        if not f:
            return False
        sl.shapes.add_picture(_recortar(f[0], w, h), Inches(x), Inches(y), Inches(w), Inches(h))
        if credito and f[1]:
            texto(sl, x, y + h + 0.03, w, 0.3, f[1], 9, GRIS, alin=PP_ALIGN.RIGHT)
        return True

    def cabecera(sl, tit, num):
        forma(sl, 0, 0, W, H, "FFFFFF")
        forma(sl, 0, 0, 0.18, H, t["acento"])
        texto(sl, 0.6, 0.35, W - 1.2, 0.95, tit, 30, t["oscuro"], True, ancla=MSO_ANCHOR.MIDDLE)
        forma(sl, 0.62, 1.32, 1.1, 0.07, t["extra"])
        texto(sl, 0.6, H - 0.5, 8, 0.35, titulo, 11, GRIS)
        texto(sl, W - 1.6, H - 0.5, 1.0, 0.35, str(num), 11, t["acento"], True, PP_ALIGN.RIGHT)

    def notas(sl, d):
        if d.get("notas"):
            sl.notes_slide.notes_text_frame.text = _txt(d["notas"])

    def grafico(sl, g, x, y, w, h):
        tipos = {"barras": XL_CHART_TYPE.COLUMN_CLUSTERED,
                 "lineas": XL_CHART_TYPE.LINE_MARKERS, "circular": XL_CHART_TYPE.DOUGHNUT}
        datos = CategoryChartData()
        datos.categories = g["etiquetas"]
        series = g["series"][:1] if g["tipo"] == "circular" else g["series"]
        for nombre, vals in series:
            datos.add_series(nombre, vals)
        gf = sl.shapes.add_chart(tipos[g["tipo"]], Inches(x), Inches(y), Inches(w), Inches(h), datos)
        ch = gf.chart
        ch.font.size, ch.font.name = Pt(13), FUENTE
        ch.font.color.rgb = rgb(TEXTO)
        if g["titulo"]:
            ch.has_title = True
            ch.chart_title.text_frame.text = g["titulo"]
            ch.chart_title.text_frame.paragraphs[0].runs[0].font.size = Pt(16)
            ch.chart_title.text_frame.paragraphs[0].runs[0].font.bold = True
        else:
            ch.has_title = False
        ch.has_legend = g["tipo"] == "circular" or len(series) > 1
        if ch.has_legend:
            ch.legend.position = XL_LEGEND_POSITION.BOTTOM
            ch.legend.include_in_layout = False
        plot = ch.plots[0]
        plot.has_data_labels = True
        plot.data_labels.font.size = Pt(12)
        colores = _colores_serie(t)
        if g["tipo"] == "circular":
            plot.data_labels.show_percentage = True
            plot.data_labels.show_value = False
            plot.data_labels.number_format = "0%"
            plot.data_labels.number_format_is_linked = False
            for i, punto in enumerate(plot.series[0].points):
                punto.format.fill.solid()
                punto.format.fill.fore_color.rgb = rgb(colores[i % len(colores)])
        else:
            if g["tipo"] == "barras":
                plot.gap_width = 60
                plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
            for i, s in enumerate(plot.series):
                c = rgb(colores[i % len(colores)])
                if g["tipo"] == "lineas":
                    s.format.line.color.rgb = c
                    s.format.line.width = Pt(3.5)
                    s.smooth = False
                    s.marker.format.fill.solid()
                    s.marker.format.fill.fore_color.rgb = c
                else:
                    s.format.fill.solid()
                    s.format.fill.fore_color.rgb = c
            ch.value_axis.major_gridlines.format.line.color.rgb = rgb("E5E7EB")
            ch.value_axis.format.line.fill.background()
            ch.value_axis.tick_labels.font.color.rgb = rgb(GRIS)

    def tabla(sl, filas, x, y, w, h):
        filas = filas[:12]
        nf, nc = len(filas), len(filas[0])
        alto = min(h, 0.62 * nf)
        tb = sl.shapes.add_table(nf, nc, Inches(x), Inches(y), Inches(w), Inches(alto)).table
        for i, fila in enumerate(filas):
            for j, valor in enumerate(fila):
                celda = tb.cell(i, j)
                celda.fill.solid()
                celda.fill.fore_color.rgb = rgb(t["oscuro"] if i == 0 else
                                                (t["claro"] if i % 2 == 0 else "FFFFFF"))
                celda.margin_left = celda.margin_right = Inches(0.12)
                celda.vertical_anchor = MSO_ANCHOR.MIDDLE
                p = celda.text_frame.paragraphs[0]
                p.text = str(valor)
                es_num = i > 0 and _num(valor) is not None
                p.alignment = PP_ALIGN.RIGHT if es_num else PP_ALIGN.LEFT
                for r in p.runs:
                    r.font.size, r.font.name = Pt(18 if nf <= 7 else 14), FUENTE
                    r.font.bold = i == 0
                    r.font.color.rgb = rgb("FFFFFF" if i == 0 else TEXTO)

    # --- Portada ---
    sl = prs.slides.add_slide(vacia)
    forma(sl, 0, 0, W, H, t["oscuro"])
    if foto(sl, imagen, 7.0, 0, W - 7.0, H, credito=False):
        forma(sl, 6.88, 0, 0.12, H, t["acento"])
        ancho_tit = 5.9
        credito = fotos[_txt(imagen)][1]
        if credito:
            texto(sl, 7.1, H - 0.4, W - 7.3, 0.3, credito, 9, "FFFFFF", alin=PP_ALIGN.RIGHT)
    else:
        forma(sl, 8.6, -1.6, 6.5, 6.5, t["acento"], MSO_SHAPE.OVAL)
        forma(sl, 10.9, 4.3, 3.6, 3.6, t["extra"], MSO_SHAPE.OVAL)
        forma(sl, 7.7, 4.9, 1.3, 1.3, t["claro"], MSO_SHAPE.OVAL)
        ancho_tit = 7.6
    texto(sl, 0.8, 1.9, ancho_tit, 2.6, titulo, 44, "FFFFFF", True, ancla=MSO_ANCHOR.BOTTOM)
    forma(sl, 0.85, 4.65, 1.4, 0.09, t["extra"])
    if subtitulo:
        texto(sl, 0.8, 4.9, ancho_tit, 1.2, _txt(subtitulo), 20, t["claro"])
    texto(sl, 0.8, H - 0.9, 5, 0.4, _hoy(), 12, t["claro"])

    # --- Índice (si hay bastantes diapositivas) ---
    num = 1
    titulos = [_txt(d.get("titulo")) for d in lista if _txt(d.get("titulo"))]
    if len(titulos) >= 4:
        num += 1
        sl = prs.slides.add_slide(vacia)
        cabecera(sl, "Contenido", num)
        columnas = 2 if len(titulos) > 5 else 1
        por_col = -(-len(titulos[:12]) // columnas)
        for i, tit in enumerate(titulos[:12]):
            col, fila = divmod(i, por_col)
            x, y = 0.8 + col * 6.1, 1.9 + fila * (4.6 / max(por_col, 4))
            circ = forma(sl, x, y, 0.62, 0.62, t["acento"], MSO_SHAPE.OVAL)
            circ.text_frame.text = str(i + 1)
            p = circ.text_frame.paragraphs[0]
            p.alignment = PP_ALIGN.CENTER
            p.runs[0].font.size, p.runs[0].font.bold = Pt(16), True
            p.runs[0].font.color.rgb = rgb("FFFFFF")
            texto(sl, x + 0.85, y, 5.0, 0.62, tit, 20, TEXTO, ancla=MSO_ANCHOR.MIDDLE)

    # --- Contenido ---
    for d in lista:
        num += 1
        sl = prs.slides.add_slide(vacia)
        tit = _txt(d.get("titulo"))
        puntos = _lista(d.get("puntos") or d.get("contenido") or d.get("texto"))
        g = _grafico(d.get("grafico"))
        filas = _tabla(d.get("tabla"))
        cita = _txt(d.get("cita"))
        if cita and not (puntos or g or filas):
            forma(sl, 0, 0, W, H, t["acento"])
            texto(sl, 0.9, 0.3, 2, 2, "“", 160, t["claro"], True)
            texto(sl, 1.5, 1.8, W - 3, 3.4, cita, 34, "FFFFFF", cursiva=True,
                  alin=PP_ALIGN.CENTER, ancla=MSO_ANCHOR.MIDDLE)
            if tit:
                texto(sl, 1.5, 5.4, W - 3, 0.6, "— " + tit, 20, t["claro"], alin=PP_ALIGN.CENTER)
            notas(sl, d)
            continue
        cabecera(sl, tit, num)
        x0, y0, ancho, alto = 0.8, 1.75, W - 1.6, H - 2.55
        if g or filas:
            if puntos:
                vinetas(sl, x0, y0, 4.3, alto, puntos, 18)
                x0, ancho = 5.4, W - 6.2
            if g:
                grafico(sl, g, x0, y0, ancho, alto)
            else:
                tabla(sl, filas, x0, y0 + 0.1, ancho, alto)
        elif fotos.get(_txt(d.get("imagen"))) and not puntos:
            foto(sl, d.get("imagen"), x0, y0, ancho, alto - 0.3)
        elif fotos.get(_txt(d.get("imagen"))):
            vinetas(sl, x0, y0 + 0.1, 6.0, alto, puntos, 22)
            foto(sl, d.get("imagen"), 7.2, y0, W - 8.0, alto - 0.3)
        elif 0 < len(puntos) <= 4 and all(len(p) <= 140 for p in puntos):
            # Tarjetas numeradas
            hueco = 0.3
            w = (ancho - hueco * (len(puntos) - 1)) / len(puntos)
            y0, alto = y0 + 0.3, min(alto, 4.2)
            for i, p in enumerate(puntos):
                x = x0 + i * (w + hueco)
                forma(sl, x, y0 + 0.2, w, alto - 0.4, t["claro"], MSO_SHAPE.ROUNDED_RECTANGLE).adjustments[0] = 0.06
                forma(sl, x, y0 + 0.2, w, 0.12, t["acento"])
                circ = forma(sl, x + 0.35, y0 + 0.6, 0.75, 0.75, t["acento"], MSO_SHAPE.OVAL)
                circ.text_frame.text = str(i + 1)
                q = circ.text_frame.paragraphs[0]
                q.alignment = PP_ALIGN.CENTER
                q.runs[0].font.size, q.runs[0].font.bold = Pt(20), True
                q.runs[0].font.color.rgb = rgb("FFFFFF")
                texto(sl, x + 0.3, y0 + 1.6, w - 0.6, alto - 2.2, p,
                      22 if len(puntos) <= 3 else 19, TEXTO)
        elif len(puntos) > 6:
            mitad = -(-len(puntos) // 2)
            vinetas(sl, x0, y0 + 0.1, ancho / 2 - 0.2, alto, puntos[:mitad], 22)
            vinetas(sl, x0 + ancho / 2 + 0.2, y0 + 0.1, ancho / 2 - 0.2, alto, puntos[mitad:], 22)
        else:
            vinetas(sl, x0, y0 + 0.1, ancho, alto, puntos, 26)
        if cita:
            forma(sl, x0, H - 1.35, 0.08, 0.6, t["extra"])
            texto(sl, x0 + 0.25, H - 1.4, ancho - 0.3, 0.7, cita, 16, t["oscuro"], cursiva=True,
                  ancla=MSO_ANCHOR.MIDDLE)
        notas(sl, d)

    # --- Cierre ---
    sl = prs.slides.add_slide(vacia)
    forma(sl, 0, 0, W, H, t["oscuro"])
    forma(sl, -1.5, 4.6, 4.5, 4.5, t["acento"], MSO_SHAPE.OVAL)
    forma(sl, W - 2.2, -1.2, 3.2, 3.2, t["extra"], MSO_SHAPE.OVAL)
    texto(sl, 1, 2.3, W - 2, 1.4, "¡Gracias!", 60, "FFFFFF", True, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE)
    forma(sl, W / 2 - 0.7, 3.85, 1.4, 0.09, t["extra"])
    texto(sl, 1, 4.15, W - 2, 0.8, titulo, 22, t["claro"], alin=PP_ALIGN.CENTER)

    ruta = _nombre_archivo(titulo, "pptx")
    prs.save(ruta)
    abrir_archivo(ruta)
    extra = f", {len(fotos)} foto(s)" if fotos else ""
    return True, f"Presentación creada ({num + 1} diapositivas{extra}): {ruta}"


# ---------- documento de Word (.docx) ----------

def _secciones_de_texto(contenido):
    """Convierte el texto antiguo («# Título» + párrafos) en secciones."""
    secciones, actual = [], None
    for linea in str(contenido or "").split("\n"):
        linea = linea.rstrip()
        if linea.startswith("#"):
            actual = {"titulo": linea.lstrip("# ").strip(), "parrafos": [], "puntos": []}
            secciones.append(actual)
        elif linea.strip():
            if actual is None:
                actual = {"titulo": "", "parrafos": [], "puntos": []}
                secciones.append(actual)
            if re.match(r"\s*[-•*·]\s", linea):
                actual["puntos"].append(linea.strip().lstrip("-•*· ").strip())
            else:
                actual["parrafos"].append(linea.strip())
    return secciones


def crear_documento(titulo="Documento", contenido="", secciones=None,
                    subtitulo="", tema="", tipo="", imagen="", **_):
    """secciones: lista de {"titulo", "parrafos": [...], "puntos": [...],
    "tabla": [[...]], "grafico": {...}, "imagen": "foto a buscar",
    "destacado": "texto en recuadro"}. tipo: informe (portada, índice y
    apartados numerados), carta o curriculum. También acepta «contenido»
    en texto con «# » para los apartados."""
    import docx
    from docx.enum.section import WD_SECTION
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor

    titulo = _txt(titulo) or "Documento"
    secs = [s for s in (secciones or []) if isinstance(s, dict)]
    if not secs:
        secs = _secciones_de_texto(contenido)
    elif contenido:
        secs = _secciones_de_texto(contenido) + secs
    tipo = _txt(tipo).lower()
    if not tipo:
        clave = titulo.lower()
        tipo = ("carta" if "carta" in clave or "solicitud" in clave else
                "curriculum" if "currículum" in clave or "curriculum" in clave or clave == "cv"
                else "informe")
    t = _tema(tema, titulo + " " + json.dumps(secs, ensure_ascii=False))
    fotos = _fotos([imagen] + [s.get("imagen") for s in secs], imagen) if tipo == "informe" else {}
    rgb = RGBColor.from_string

    doc = docx.Document()
    seccion = doc.sections[0]
    seccion.page_width, seccion.page_height = Cm(21), Cm(29.7)
    for m in ("left_margin", "right_margin"):
        setattr(seccion, m, Cm(2.3))
    seccion.top_margin, seccion.bottom_margin = Cm(2.2), Cm(2.0)
    ancho_util = 21 - 4.6

    def fuente(estilo, tam, color=TEXTO, negrita=False):
        estilo.font.name, estilo.font.size = FUENTE, Pt(tam)
        estilo.font.bold = negrita
        estilo.font.color.rgb = rgb(color)
        rfonts = estilo.element.get_or_add_rPr().find(qn("w:rFonts"))
        if rfonts is not None:
            for a in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
                rfonts.attrib.pop(qn(a), None)
            rfonts.set(qn("w:eastAsia"), FUENTE)

    normal = doc.styles["Normal"]
    fuente(normal, 11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.2
    for nombre, tam, color, antes in (("Heading 1", 17, t["oscuro"], 18),
                                      ("Heading 2", 13.5, t["acento"], 12)):
        est = doc.styles[nombre]
        fuente(est, tam, color, True)
        est.paragraph_format.space_before, est.paragraph_format.space_after = Pt(antes), Pt(6)
        est.paragraph_format.keep_with_next = True

    def sombrear(celda, color):
        tcpr = celda._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), color)
        tcpr.append(shd)

    def bordes(celda, **lados):
        tcpr = celda._tc.get_or_add_tcPr()
        b = OxmlElement("w:tcBorders")
        for lado in ("top", "left", "bottom", "right"):
            e = OxmlElement(f"w:{lado}")
            tam, color = lados.get(lado, (0, None))
            e.set(qn("w:val"), "single" if tam else "nil")
            if tam:
                e.set(qn("w:sz"), str(tam))
                e.set(qn("w:color"), color)
            b.append(e)
        tcpr.append(b)

    def margen_celda(celda, cm):
        tcpr = celda._tc.get_or_add_tcPr()
        mar = OxmlElement("w:tcMar")
        for lado in ("top", "left", "bottom", "right"):
            e = OxmlElement(f"w:{lado}")
            e.set(qn("w:w"), str(int(cm * 567)))
            e.set(qn("w:type"), "dxa")
            mar.append(e)
        tcpr.append(mar)

    def linea_inferior(parrafo, color, tam=12):
        ppr = parrafo._p.get_or_add_pPr()
        pbdr = OxmlElement("w:pBdr")
        e = OxmlElement("w:bottom")
        for k, v in (("w:val", "single"), ("w:sz", str(tam)), ("w:space", "4"), ("w:color", color)):
            e.set(qn(k), v)
        pbdr.append(e)
        ppr.append(pbdr)

    def campo(parrafo, instr):
        for tipo_f, texto_f in (("begin", None), (None, instr), ("separate", None), (None, "1"), ("end", None)):
            r = parrafo.add_run()
            if tipo_f:
                fc = OxmlElement("w:fldChar")
                fc.set(qn("w:fldCharType"), tipo_f)
                r._r.append(fc)
            elif texto_f == instr:
                it = OxmlElement("w:instrText")
                it.set(qn("xml:space"), "preserve")
                it.text = f" {instr} "
                r._r.append(it)
            else:
                r.text = texto_f
            r.font.size, r.font.color.rgb = Pt(9), rgb(GRIS)

    def parrafo(texto_p, tam=None, color=None, negrita=False, cursiva=False,
                alin=None, despues=None, estilo=None):
        p = doc.add_paragraph(style=estilo)
        if alin is not None:
            p.alignment = alin
        if despues is not None:
            p.paragraph_format.space_after = Pt(despues)
        r = p.add_run(texto_p)
        r.bold, r.italic = negrita, cursiva
        if tam:
            r.font.size = Pt(tam)
        if color:
            r.font.color.rgb = rgb(color)
        return p

    def banda(lineas, color, alto_cm=None):
        """Recuadro de color a todo el ancho con varias líneas de texto."""
        tb = doc.add_table(rows=1, cols=1)
        tb.alignment = WD_TABLE_ALIGNMENT.CENTER
        celda = tb.cell(0, 0)
        sombrear(celda, color)
        margen_celda(celda, 0.8)
        if alto_cm:
            tb.rows[0].height = Cm(alto_cm)
        celda.paragraphs[0].text = ""
        for i, (texto_b, tam, col, neg) in enumerate(lineas):
            p = celda.paragraphs[0] if i == 0 else celda.add_paragraph()
            p.paragraph_format.space_after = Pt(4)
            r = p.add_run(texto_b)
            r.font.size, r.bold = Pt(tam), neg
            r.font.color.rgb = rgb(col)
        return tb

    def figura(ruta_img, pie, credito=""):
        doc.add_picture(ruta_img, width=Cm(ancho_util))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        texto_pie = pie + (f" ({credito})" if credito else "")
        parrafo(texto_pie, 9, GRIS, cursiva=True, alin=WD_ALIGN_PARAGRAPH.CENTER, despues=12)

    def tabla_doc(filas):
        nc = len(filas[0])
        tb = doc.add_table(rows=len(filas), cols=nc)
        tb.alignment = WD_TABLE_ALIGNMENT.CENTER
        for i, fila in enumerate(filas):
            for j, valor in enumerate(fila):
                celda = tb.cell(i, j)
                celda.text = ""
                p = celda.paragraphs[0]
                p.paragraph_format.space_after = Pt(0)
                r = p.add_run(str(valor))
                r.font.size = Pt(10)
                if i == 0:
                    sombrear(celda, t["oscuro"])
                    r.bold, r.font.color.rgb = True, rgb("FFFFFF")
                else:
                    if i % 2 == 0:
                        sombrear(celda, t["claro"])
                    if j > 0 and _num(valor) is not None:
                        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                bordes(celda, bottom=(4, BORDE))
                margen_celda(celda, 0.15)
        doc.add_paragraph().paragraph_format.space_after = Pt(2)

    def destacado(texto_d):
        tb = doc.add_table(rows=1, cols=1)
        celda = tb.cell(0, 0)
        sombrear(celda, t["claro"])
        bordes(celda, left=(36, t["acento"]))
        margen_celda(celda, 0.35)
        celda.paragraphs[0].text = ""
        r = celda.paragraphs[0].add_run(texto_d)
        r.italic, r.font.color.rgb = True, rgb(t["oscuro"])
        celda.paragraphs[0].paragraph_format.space_after = Pt(0)
        doc.add_paragraph().paragraph_format.space_after = Pt(2)

    n_fig = 0

    def contenido_seccion(s):
        nonlocal n_fig
        for p in _lista(s.get("parrafos") or s.get("texto") or s.get("contenido")):
            parrafo(p, alin=WD_ALIGN_PARAGRAPH.JUSTIFY if tipo == "informe" else None)
        for p in _lista(s.get("puntos")):
            # Viñeta del color del tema (la de la plantilla sale como un
            # cuadrado si falta la fuente Symbol)
            q = doc.add_paragraph()
            q.paragraph_format.left_indent = Cm(0.7)
            q.paragraph_format.first_line_indent = Cm(-0.5)
            q.paragraph_format.space_after = Pt(3)
            v = q.add_run("●\t")
            v.font.size, v.font.color.rgb = Pt(8), rgb(t["acento"])
            q.paragraph_format.tab_stops.add_tab_stop(Cm(0.7))
            if ":" in p[:40] and tipo != "carta":
                # «Concepto: explicación» con el concepto en negrita
                cab, resto = p.split(":", 1)
                q.add_run(cab + ":").bold = True
                q.add_run(resto)
            else:
                q.add_run(p)
        filas = _tabla(s.get("tabla"))
        if filas:
            tabla_doc(filas)
        g = _grafico(s.get("grafico"))
        if g:
            n_fig += 1
            ruta_g = os.path.join(DIR_FOTOS, f"grafico-{os.getpid()}-{n_fig}.png")
            os.makedirs(DIR_FOTOS, exist_ok=True)
            figura(_grafico_png(g, t, ruta_g), f"Figura {n_fig}. {g['titulo'] or s.get('titulo', '')}")
            os.remove(ruta_g)
        f = fotos.get(_txt(s.get("imagen")))
        if f:
            n_fig += 1
            figura(_recortar(f[0], 16, 9), f"Figura {n_fig}. {s.get('titulo') or _txt(s.get('imagen'))}", f[1])
        if _txt(s.get("destacado")):
            destacado(_txt(s["destacado"]))

    if tipo == "carta":
        parrafo(_hoy(), alin=WD_ALIGN_PARAGRAPH.RIGHT, color=GRIS, despues=24)
        if titulo.lower() not in ("carta", "carta de presentación"):
            parrafo(titulo, 13, t["oscuro"], True, despues=12)
        for s in secs:
            if _txt(s.get("titulo")):
                parrafo(_txt(s["titulo"]), negrita=True)
            contenido_seccion(s)
    elif tipo == "curriculum":
        lineas = [(titulo, 26, "FFFFFF", True)]
        if subtitulo:
            lineas.append((_txt(subtitulo), 12, t["claro"], False))
        banda(lineas, t["oscuro"])
        doc.add_paragraph().paragraph_format.space_after = Pt(0)
        for s in secs:
            if _txt(s.get("titulo")):
                h = doc.add_heading(_txt(s["titulo"]).upper(), level=2)
                linea_inferior(h, t["acento"])
            contenido_seccion(s)
    else:
        # Portada
        lineas = [("INFORME", 11, t["extra"], True), (titulo, 30, "FFFFFF", True)]
        if subtitulo:
            lineas.append((_txt(subtitulo), 14, t["claro"], False))
        lineas.append((_hoy(), 11, t["claro"], False))
        banda(lineas, t["oscuro"], 7.5)
        f = fotos.get(_txt(imagen))
        if f:
            doc.add_paragraph().paragraph_format.space_after = Pt(6)
            doc.add_picture(_recortar(f[0], 16, 7), width=Cm(ancho_util))
            parrafo(f[1], 8, GRIS, cursiva=True, alin=WD_ALIGN_PARAGRAPH.RIGHT)
        titulos = [_txt(s.get("titulo")) for s in secs if _txt(s.get("titulo"))]
        if len(titulos) >= 3:
            doc.add_paragraph().paragraph_format.space_after = Pt(18)
            p = parrafo("Contenido", 14, t["oscuro"], True, despues=6)
            linea_inferior(p, t["acento"], 8)
            for i, tit in enumerate(titulos, 1):
                q = doc.add_paragraph()
                q.paragraph_format.space_after = Pt(3)
                r = q.add_run(f"{i}.  ")
                r.bold, r.font.color.rgb = True, rgb(t["acento"])
                q.add_run(tit)
        # El contenido empieza en página nueva, con encabezado y número de página
        nueva = doc.add_section(WD_SECTION.NEW_PAGE)
        nueva.header.is_linked_to_previous = False
        nueva.footer.is_linked_to_previous = False
        cab = nueva.header.paragraphs[0]
        cab.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        r = cab.add_run(titulo)
        r.font.size, r.font.color.rgb = Pt(9), rgb(GRIS)
        linea_inferior(cab, t["acento"], 6)
        pie = nueva.footer.paragraphs[0]
        pie.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = pie.add_run("Página ")
        r.font.size, r.font.color.rgb = Pt(9), rgb(GRIS)
        campo(pie, "PAGE")
        r = pie.add_run(" de ")
        r.font.size, r.font.color.rgb = Pt(9), rgb(GRIS)
        campo(pie, "NUMPAGES")
        # La portada no lleva encabezado ni pie
        doc.sections[0].header.is_linked_to_previous = False
        n = 0
        for s in secs:
            if _txt(s.get("titulo")):
                n += 1
                doc.add_heading(f"{n}. {_txt(s['titulo'])}", level=1)
            contenido_seccion(s)

    doc.core_properties.title = titulo
    doc.core_properties.author = os.environ.get("USER", "")
    ruta = _nombre_archivo(titulo, "docx")
    doc.save(ruta)
    abrir_archivo(ruta)
    extra = f", {len(fotos)} foto(s)" if fotos else ""
    return True, f"Documento creado ({len(secs)} apartados{extra}): {ruta}"


# ---------- hoja de cálculo (.xlsx) ----------

# Columnas numéricas que no tiene sentido sumar (se comparan palabras enteras)
NO_SUMAR = {"precio", "precios", "año", "id", "nº", "número", "numero", "codigo",
            "código", "tasa", "media", "promedio", "nota", "notas", "edad",
            "teléfono", "telefono", "cp", "unitario", "porcentaje", "ref"}
# Categorías que son una evolución en el tiempo: gráfico de líneas
ES_TIEMPO = {"mes", "meses", "año", "años", "fecha", "trimestre", "periodo", "período"}


def _palabras(texto):
    return set(re.findall(r"\w+", str(texto).lower()))


FUNCIONES_ES = {"SUMA": "SUM", "PROMEDIO": "AVERAGE", "REDONDEAR": "ROUND",
                "MIN": "MIN", "MAX": "MAX", "SUM": "SUM", "AVERAGE": "AVERAGE",
                "ROUND": "ROUND"}


def _formula(valor, fila, desplazamiento):
    """Fórmula segura o None. Solo se aceptan cuentas con celdas de su propia
    fila (p. ej. «=B2*C2» o «=SUMA(B2:D2)»): un modelo pequeño a veces se
    inventa fórmulas sin sentido, y así no aparecen errores en la hoja."""
    f = valor[1:].strip().upper().replace(";", ",")
    f = re.sub(r"\b([A-Z]+)\(", lambda m: FUNCIONES_ES.get(m.group(1), "?") + "(", f)
    if "?" in f or not re.fullmatch(r"[A-Z0-9:+\-*/(),. ]+", f):
        return None
    refs = re.findall(r"\b[A-Z]{1,2}(\d+)\b", f)
    if not refs or any(int(r) != fila for r in refs):
        return None
    return "=" + re.sub(r"\b([A-Z]{1,2})(\d+)\b",
                        lambda m: f"{m.group(1)}{int(m.group(2)) + desplazamiento}", f)


def crear_hoja(titulo="Hoja", datos=None, subtitulo="", tema="", grafico=None,
               totales=None, **_):
    """datos: lista de filas; la primera son los encabezados. Convierte los
    números (con € o %), da formato de tabla, añade fila de totales, barras de
    datos y un gráfico automático (o el pedido en «grafico»: {"tipo"})."""
    import openpyxl
    from openpyxl.chart import BarChart, LineChart, PieChart, Reference
    from openpyxl.chart.label import DataLabelList
    from openpyxl.formatting.rule import DataBarRule
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    titulo = _txt(titulo) or "Hoja"
    filas = _tabla(datos)
    t = _tema(tema, titulo + " " + json.dumps(filas, ensure_ascii=False))
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\[\]:*?/\\]", "", titulo)[:31] or "Hoja"
    ws.sheet_view.showGridLines = False
    if not filas:
        filas = [["Concepto", "Valor"]]
    cab, cuerpo = [str(c) for c in filas[0]], filas[1:]
    nc = len(cab)

    # Tipo de cada columna: texto, número, moneda o porcentaje
    tipos = []
    for j, nombre in enumerate(cab):
        valores = [f[j] for f in cuerpo if str(f[j]).strip()]
        numeros = [v for v in valores if _num(v) is not None or str(v).startswith("=")]
        es_num = valores and len(numeros) >= 0.8 * len(valores)
        texto_col = (nombre + " " + " ".join(map(str, valores))).lower()
        if not es_num:
            tipos.append("texto")
        elif "%" in texto_col:
            tipos.append("porcentaje")
        elif "€" in texto_col or "eur" in texto_col or any(
                p in nombre.lower() for p in ("importe", "precio", "coste", "gasto", "salario",
                                              "sueldo", "ingreso", "pago", "presupuesto")):
            tipos.append("moneda")
        else:
            tipos.append("numero")
    moneda = "$" if any("$" in str(c) for f in filas for c in f) else "€"
    formatos = {"moneda": f'#,##0.00 "{moneda}"', "porcentaje": "0.0%",
                "numero": "#,##0.##"}

    fila_cab = 4
    ultima_col = get_column_letter(max(nc, 3))
    ws.merge_cells(f"A1:{ultima_col}1")
    ws["A1"] = titulo
    ws["A1"].font = Font(name=FUENTE, size=18, bold=True, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=t["oscuro"])
    ws["A1"].alignment = Alignment(vertical="center", indent=1)
    ws.row_dimensions[1].height = 36
    ws.merge_cells(f"A2:{ultima_col}2")
    ws["A2"] = _txt(subtitulo) or f"Creado el {_hoy()}"
    ws["A2"].font = Font(name=FUENTE, size=10, italic=True, color=GRIS)
    ws["A2"].alignment = Alignment(indent=1)

    descartadas = 0
    fino = Side(style="thin", color=BORDE)
    for j, nombre in enumerate(cab, 1):
        c = ws.cell(row=fila_cab, column=j, value=nombre)
        c.font = Font(name=FUENTE, bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=t["acento"])
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = Border(bottom=fino)
    ws.row_dimensions[fila_cab].height = 24

    for i, fila in enumerate(cuerpo, fila_cab + 1):
        for j, valor in enumerate(fila, 1):
            tipo = tipos[j - 1]
            v = valor
            if isinstance(valor, str) and valor.startswith("="):
                # Fórmula escrita con la tabla empezando en la fila 1: se
                # desplaza a donde está de verdad (debajo del título)
                v = _formula(valor, i - fila_cab + 1, fila_cab - 1)
                if v is None:
                    descartadas += 1
            elif tipo != "texto" and _num(valor) is not None:
                v = _num(valor)
                if tipo == "porcentaje" and ("%" in str(valor) or abs(v) > 1):
                    v = v / 100
            c = ws.cell(row=i, column=j, value=v)
            c.font = Font(name=FUENTE, color=TEXTO)
            c.border = Border(bottom=fino)
            if tipo != "texto":
                c.number_format = formatos[tipo]
                c.alignment = Alignment(horizontal="right")
            if (i - fila_cab) % 2 == 0:
                c.fill = PatternFill("solid", fgColor=t["claro"])
    ultima = fila_cab + len(cuerpo)

    sumables = [j for j, tp in enumerate(tipos, 1)
                if tp in ("moneda", "numero") and j > 1
                and not _palabras(cab[j - 1]) & NO_SUMAR]
    if totales is None:
        totales = bool(sumables) and len(cuerpo) >= 2
    if totales and sumables and cuerpo:
        ft = ultima + 1
        ws.cell(row=ft, column=1, value="Total")
        for j in range(1, nc + 1):
            c = ws.cell(row=ft, column=j)
            if j in sumables:
                letra = get_column_letter(j)
                c.value = f"=SUM({letra}{fila_cab + 1}:{letra}{ultima})"
                c.number_format = formatos[tipos[j - 1]]
                c.alignment = Alignment(horizontal="right")
            c.font = Font(name=FUENTE, bold=True, color=t["oscuro"])
            c.fill = PatternFill("solid", fgColor=t["claro"])
            c.border = Border(top=Side(style="medium", color=t["oscuro"]))

    # Barras de datos en la primera columna que se suma
    if sumables and len(cuerpo) >= 2:
        letra = get_column_letter(sumables[0])
        ws.conditional_formatting.add(
            f"{letra}{fila_cab + 1}:{letra}{ultima}",
            DataBarRule(start_type="num", start_value=0, end_type="max", color=t["acento"]))

    # Anchos de columna, filtros, paneles fijos e impresión
    for j, nombre in enumerate(cab, 1):
        largo = max([len(str(nombre))] + [len(str(f[j - 1])) for f in cuerpo])
        ws.column_dimensions[get_column_letter(j)].width = min(max(largo + 4, 11), 50)
    if cuerpo:
        ws.auto_filter.ref = f"A{fila_cab}:{get_column_letter(nc)}{ultima}"
    ws.freeze_panes = ws.cell(row=fila_cab + 1, column=1)
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.oddFooter.center.text = "Página &P de &N"
    ws.oddHeader.right.text = titulo

    # Gráfico: el pedido o uno automático con las columnas numéricas
    # Mejor no mezclar escalas: si hay importes, solo los importes
    numericas = ([j for j in sumables if tipos[j - 1] == "moneda"] or sumables or
                 [j for j, tp in enumerate(tipos, 1) if tp != "texto" and j > 1])
    pedido = grafico if isinstance(grafico, dict) else {}
    if numericas and 2 <= len(cuerpo) <= 60 and pedido.get("tipo") != "ninguno":
        cat = next((j for j, tp in enumerate(tipos, 1) if tp == "texto"), 1)
        tipo_g = _txt(pedido.get("tipo")).lower()
        if any(p in tipo_g for p in ("circ", "pie", "tarta", "sector", "quesito")):
            ch = PieChart()
            numericas = numericas[:1]
        elif "line" in tipo_g or (not tipo_g and _palabras(cab[cat - 1]) & ES_TIEMPO
                                  and len(cuerpo) > 4):
            ch = LineChart()
        else:
            ch = BarChart()
            ch.type, ch.gapWidth = "col", 60
            numericas = numericas[:3]
        ch.title = _txt(pedido.get("titulo")) or (
            cab[numericas[0] - 1] if len(numericas) == 1 else titulo)
        ch.style, ch.width, ch.height = 10, 18, 9.5
        for j in numericas:
            ch.add_data(Reference(ws, min_col=j, min_row=fila_cab, max_row=ultima),
                        titles_from_data=True)
        ch.set_categories(Reference(ws, min_col=cat, min_row=fila_cab + 1, max_row=ultima))
        colores = _colores_serie(t)
        if isinstance(ch, PieChart):
            from openpyxl.chart.series import DataPoint
            serie = ch.series[0]
            for i in range(len(cuerpo)):
                punto = DataPoint(idx=i)
                punto.graphicalProperties.solidFill = colores[i % len(colores)]
                serie.dPt.append(punto)
            ch.dataLabels = DataLabelList()
            ch.dataLabels.showPercent = True
        else:
            for i, s in enumerate(ch.series):
                if isinstance(ch, LineChart):
                    s.graphicalProperties.line.solidFill = colores[i % len(colores)]
                    s.graphicalProperties.line.width = 38000
                    s.smooth = False
                else:
                    s.graphicalProperties.solidFill = colores[i % len(colores)]
                    s.graphicalProperties.line.noFill = True
            ch.x_axis.delete = False
            ch.y_axis.delete = False
            ch.y_axis.majorGridlines.spPr = None
            if len(numericas) == 1:
                ch.legend = None
        ws.add_chart(ch, f"{get_column_letter(nc + 2)}{fila_cab}")

    ruta = _nombre_archivo(titulo, "xlsx")
    wb.save(ruta)
    abrir_archivo(ruta)
    aviso = (f"; {descartadas} fórmula(s) no válidas se dejaron en blanco"
             if descartadas else "")
    return True, f"Hoja de cálculo creada ({len(cuerpo)} filas{aviso}): {ruta}"


# ---------- despachador ----------

HERRAMIENTAS = {
    "crear_presentacion": crear_presentacion,
    "crear_documento": crear_documento,
    "crear_hoja": crear_hoja,
}


def ejecutar(nombre, args):
    """Ejecuta una herramienta. Devuelve (ok, mensaje)."""
    fn = HERRAMIENTAS.get(nombre)
    if not fn:
        return False, f"Herramienta desconocida: {nombre}"
    if not isinstance(args, dict):
        args = {}
    try:
        return fn(**args)
    except Exception as e:  # noqa: BLE001
        return False, f"No se pudo completar «{nombre}»: {e}"
