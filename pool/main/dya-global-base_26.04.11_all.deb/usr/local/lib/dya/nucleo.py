"""
nucleo — infraestructura común de los asistentes de D&A Global OS.

Lo usan tanto `ia` (asistente general) como `ciber` (ciberseguridad). Los dos
hablan con un único llama-server local (mismo modelo, cargado una sola vez),
así que tener los dos abiertos no duplica la memoria.

Con internet y la cuenta gratis de Ollama conectada (un clic, ver
conectar_nube), las consultas van a un modelo en línea mucho más potente
(DeepSeek, Kimi, GLM... en Ollama Cloud, ver CONFIG_NUBE) y el modelo local ni se arranca; si se pierde la conexión, se acaba
el cupo gratis o falla la nube, se vuelve solo al modelo local (Qwen3.5 2B),
que funciona sin internet.

Aquí vive todo lo que comparten: arranque del servidor, consulta al modelo,
ejecución de comandos con corrección de errores, apertura de aplicaciones y
comprobación de paquetes apt. Lo específico (instrucciones, ejemplos y el
ciclo de cada asistente) está en cada script.
"""
import datetime
import getpass
import glob
import hashlib
import json
import os
import platform
import re
import readline  # al importarse, activa flechas/edición/historial en input()
import shlex
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request

# ---------- servidor compartido ----------

# Motor de IA: llama-swap sirve varios modelos pequeños especializados y carga
# en memoria SOLO UNO a la vez (poca RAM), intercambiándolos según el "modelo"
# que pida cada consulta. Cada rol es un modelo distinto definido en el YAML.
MOTOR = os.environ.get("DYA_MOTOR", "llama-swap")
CONFIG_MOTOR = os.environ.get("DYA_CONFIG_MOTOR", "/etc/dya/llama-swap.yaml")
PUERTO = int(os.environ.get("DYA_PUERTO", "8765"))
URL = f"http://127.0.0.1:{PUERTO}"

# Un solo modelo sirve todo (comandos, apps, programación y ofimática). Se deja
# la distinción de roles por si en el futuro se añaden modelos especializados,
# pero ambos apuntan al mismo modelo 'sistema'.
MODELO_SISTEMA = "sistema"   # general, comandos, apps, programación, ofimática
MODELO_CODIGO = "sistema"
CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME",
                                    os.path.expanduser("~/.cache")), "dya-ia")
PIDFILE = os.path.join(CACHE, "servidor.pid")
REGISTRO = os.path.join(CACHE, "servidor.log")

# Caché en disco del prefijo fijo (instrucciones + ejemplos few-shot): en CPU
# procesarlo cuesta ~100 s; restaurarlo del disco, menos de 1 s. Cada
# asistente la activa fijando PREFIJO = nº de mensajes fijos del historial.
DIR_SLOTS = "/var/cache/dya-ia"
PREFIJO = None
_restaurado = False


def activar_historial(nombre="dya"):
    """Historial persistente para los asistentes (flechas ↑/↓).

    Importar readline ya hace que las flechas muevan el cursor en input();
    esto además recuerda lo escrito entre sesiones. Es tolerante a fallos.
    """
    try:
        os.makedirs(CACHE, exist_ok=True)
        hist = os.path.join(CACHE, f"historial-{nombre}")
        try:
            readline.read_history_file(hist)
        except OSError:
            pass
        readline.set_history_length(1000)
        import atexit
        atexit.register(lambda: _guardar_historial(hist))
    except Exception:
        pass


def _guardar_historial(ruta):
    try:
        readline.write_history_file(ruta)
    except Exception:
        pass

# ---------- colores ----------

AZUL, VERDE, AMARILLO, ROJO, MORADO, TENUE, NEGRITA, FIN = (
    "\033[1;36m", "\033[1;32m", "\033[1;33m", "\033[1;31m",
    "\033[1;35m", "\033[2m", "\033[1m", "\033[0m")
if not sys.stdout.isatty():
    AZUL = VERDE = AMARILLO = ROJO = MORADO = TENUE = NEGRITA = FIN = ""


# ---------- servidor de IA ----------

def servidor_activo():
    """True si el proxy llama-swap responde (aún sin modelo cargado)."""
    for ruta in ("/health", "/v1/models"):
        try:
            with urllib.request.urlopen(URL + ruta, timeout=2) as r:
                if r.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            continue
    return False


def arrancar_servidor():
    """Prepara la IA al abrir un asistente. Si se va a usar el modelo en línea
    no arranca nada local (no gasta memoria); si no, arranca llama-swap."""
    if nube_disponible():
        return
    _arrancar_local()


def _arrancar_local():
    """Arranca el proxy llama-swap. Es rápido: los modelos se cargan bajo
    demanda en la primera consulta de cada rol (y se liberan por inactividad),
    de modo que solo hay un modelo en memoria a la vez."""
    if servidor_activo():
        return
    if not shutil.which(MOTOR):
        sys.exit(f"{ROJO}No está instalado el motor de IA (llama-swap).{FIN}")
    if not os.path.exists(CONFIG_MOTOR):
        sys.exit(f"{ROJO}Falta la configuración de IA:{FIN} {CONFIG_MOTOR}")
    os.makedirs(CACHE, exist_ok=True)
    with open(REGISTRO, "w") as log:
        proc = subprocess.Popen(
            [MOTOR, "--config", CONFIG_MOTOR,
             "--listen", f"127.0.0.1:{PUERTO}"],
            stdout=log, stderr=log, stdin=subprocess.DEVNULL,
            start_new_session=True)
    with open(PIDFILE, "w") as f:
        f.write(str(proc.pid))
    for _ in range(60):
        if proc.poll() is not None:
            with open(REGISTRO) as f:
                cola = f.read()[-1500:]
            sys.exit(f"{ROJO}El motor de IA no pudo arrancar:{FIN}\n{cola}")
        if servidor_activo():
            return
        time.sleep(0.5)
    sys.exit(f"\n{ROJO}El motor de IA tarda demasiado.{FIN} Mira {REGISTRO}")


# Alias descriptivo (el motor sirve varios modelos)
arrancar_motor = arrancar_servidor


def parar_servidor():
    try:
        with open(PID_NUBE) as f:
            os.kill(int(f.read().strip()), signal.SIGTERM)
        os.remove(PID_NUBE)
    except (OSError, ValueError, NameError):
        pass
    try:
        with open(PIDFILE) as f:
            os.kill(int(f.read().strip()), signal.SIGTERM)
        os.remove(PIDFILE)
        print("IA detenida; memoria liberada.")
    except (OSError, ValueError):
        print("La IA no estaba en marcha.")


def _archivo_prefijo(historial, modelo):
    if not PREFIJO or not os.access(DIR_SLOTS, os.W_OK):
        return None
    clave = json.dumps([modelo] + historial[:PREFIJO], ensure_ascii=False)
    return f"dya-{modelo}-{hashlib.sha1(clave.encode()).hexdigest()[:12]}.bin"


def _modelo_cargado(modelo):
    try:
        with urllib.request.urlopen(URL + "/running", timeout=2) as r:
            return any(m.get("model") == modelo and m.get("state") == "ready"
                       for m in json.load(r).get("running", []))
    except (urllib.error.URLError, OSError, ValueError):
        return False


def _prefijo_anterior(modelo):
    """La caché de prefijo más reciente de este modelo (otra versión)."""
    viejos = glob.glob(os.path.join(DIR_SLOTS, f"dya-{modelo}-*.bin"))
    return os.path.basename(max(viejos, key=os.path.getmtime)) if viejos else None


def _guardar_prefijo(modelo, archivo):
    """Guarda la caché del prefijo en disco (dura entre reinicios) y borra las
    versiones anteriores de este modelo."""
    if not _slot(modelo, "save", archivo):
        return False
    for viejo in glob.glob(os.path.join(DIR_SLOTS, f"dya-{modelo}-*.bin")):
        if os.path.basename(viejo) != archivo:
            try:
                os.remove(viejo)
            except OSError:
                pass
    return True


MARCA_PRECALENTAR = os.path.join(DIR_SLOTS, "precalentando.pid")


def _precalentando():
    """True si otro proceso está preparando la caché ahora mismo."""
    try:
        with open(MARCA_PRECALENTAR) as f:
            os.kill(int(f.read().strip()), 0)
        return True
    except (OSError, ValueError):
        return False


def _ram_mb():
    try:
        with open("/proc/meminfo") as f:
            for linea in f:
                if linea.startswith("MemTotal:"):
                    return int(linea.split()[1]) // 1024
    except (OSError, ValueError, IndexError):
        pass
    return 0


def _en_vivo():
    try:
        with open("/proc/cmdline") as f:
            return "boot=casper" in f.read().split()
    except OSError:
        return False


def precalentar(historial, modelo=MODELO_SISTEMA):
    """Calcula y guarda en disco la caché del prefijo (instrucciones, ejemplos
    y aplicaciones) para que la primera consulta no tarde. Si ya está, no hace
    nada. Pensado para lanzarse en segundo plano y con prioridad mínima."""
    global _restaurado
    # Con poca RAM, cargar el modelo al iniciar sesión deja el equipo lento; y
    # en el sistema en vivo la caché iría a la RAM (no hay disco donde guardarla).
    if _ram_mb() < 6144 or _en_vivo():
        print("En este equipo la caché de la IA local se prepara al usarla.")
        return
    archivo = _archivo_prefijo(historial, modelo)
    if not archivo:
        print("La caché de la IA no está disponible (sin carpeta de caché).")
        return
    if os.path.exists(os.path.join(DIR_SLOTS, archivo)):
        print("La caché de la IA local ya está lista.")
        return
    if _precalentando():
        print("Ya se está preparando la caché de la IA local.")
        return
    try:
        with open(MARCA_PRECALENTAR, "w") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass
    try:
        _precalentar(historial, modelo, archivo)
    finally:
        try:
            os.remove(MARCA_PRECALENTAR)
        except OSError:
            pass


def _precalentar(historial, modelo, archivo):
    _arrancar_local()
    previo = _prefijo_anterior(modelo)
    if previo:
        _slot(modelo, "restore", previo)
    cuerpo = {"model": modelo, "messages": historial, "max_tokens": 1}
    peticion = urllib.request.Request(
        URL + "/v1/chat/completions", data=json.dumps(cuerpo).encode(),
        headers={"Content-Type": "application/json"})
    try:
        urllib.request.urlopen(peticion, timeout=3600).close()
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        print(f"No se pudo preparar la caché de la IA: {e}")
        return
    ok = _guardar_prefijo(modelo, archivo)
    # Libera la RAM: el modelo se vuelve a cargar (y la caché del disco) al usarlo.
    try:
        urllib.request.urlopen(URL + "/unload", timeout=5).close()
    except (urllib.error.URLError, OSError):
        pass
    print("Caché de la IA local guardada." if ok else
          "No se pudo guardar la caché de la IA.")


def _slot(modelo, accion, archivo):
    """Guarda o restaura la caché KV del servidor (llama-server, slot 0)."""
    peticion = urllib.request.Request(
        f"{URL}/upstream/{modelo}/slots/0?action={accion}",
        data=json.dumps({"filename": archivo}).encode(),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(peticion, timeout=600):
            return True
    except (urllib.error.URLError, OSError):
        return False


def consultar(historial, esquema, modelo=MODELO_SISTEMA, timeout=600):
    """Pregunta a un modelo (rol) y devuelve (texto_crudo, dict_json_o_None).
    Con internet usa el modelo en línea; si no hay o falla, el local (llama-swap
    carga el modelo pedido si no está ya en memoria)."""
    if nube_disponible():
        try:
            texto = _consultar_nube(historial, esquema, timeout)
            _avisar_modo("nube")
            _liberar_local()
            try:
                return texto, json.loads(texto)
            except (json.JSONDecodeError, TypeError):
                return texto, None
        except _FalloNube as e:
            _nube["hasta"] = time.time() + 120   # no reintentar en 2 min
            print(f"{TENUE}La IA en línea no respondió ({e}); "
                  f"sigo con la local.{FIN}", file=sys.stderr)
    _avisar_modo("local")
    _arrancar_local()
    return _consultar_local(historial, esquema, modelo, timeout)


def _consultar_local(historial, esquema, modelo, timeout):
    global _restaurado
    archivo = _archivo_prefijo(historial, modelo)
    guardar = False
    if archivo:
        guardar = not os.path.exists(os.path.join(DIR_SLOTS, archivo))
        # Restaurar al empezar la sesión (el servidor puede tener en caché el
        # prefijo de otro asistente) o si el modelo se descargó por inactividad.
        # Si el prefijo cambió (p. ej. se instaló un programa), se restaura la
        # caché anterior: llama.cpp reaprovecha la parte común y solo calcula
        # lo nuevo; luego se guarda la caché nueva.
        if not _restaurado or not _modelo_cargado(modelo):
            previo = archivo if not guardar else _prefijo_anterior(modelo)
            if previo:
                _restaurado = _slot(modelo, "restore", previo)
    cuerpo = {
        "model": modelo,
        "messages": historial,
        "temperature": 0.2,
        "response_format": {
            "type": "json_schema",
            "json_schema": {"name": "accion", "schema": esquema},
        },
    }
    peticion = urllib.request.Request(
        URL + "/v1/chat/completions",
        data=json.dumps(cuerpo).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(peticion, timeout=timeout) as r:
        texto = json.load(r)["choices"][0]["message"]["content"]
    if guardar:
        _guardar_prefijo(modelo, archivo)
    try:
        return texto, json.loads(texto)
    except (json.JSONDecodeError, TypeError):
        return texto, None


# ---------- IA en línea (Ollama Cloud, gratis) cuando hay internet ----------

# Se usa el programa de Ollama del sistema solo como pasarela a su nube: no
# descarga modelos ni usa RAM para ellos. La persona conecta su cuenta GRATIS
# con un clic (enlace que da Ollama; ver conectar_nube). Configuración en
# /etc/dya/ia-nube.conf (líneas CLAVE=valor):
#   ACTIVA=si|no
#   MODELOS=gpt-oss:120b-cloud,gemma4:cloud  (se prueban en orden; se usa el
#            primero que responda; con el plan Pro se pueden añadir más)
CONFIG_NUBE = os.environ.get("DYA_CONFIG_NUBE", "/etc/dya/ia-nube.conf")
OLLAMA = os.environ.get("DYA_OLLAMA", "/usr/local/lib/dya/ollama/ollama")
# Un puerto por usuario: cada uno usa SU pasarela y SU cuenta de Ollama.
PUERTO_NUBE = int(os.environ.get("DYA_PUERTO_NUBE", str(20000 + os.getuid() % 10000)))
URL_NUBE = f"http://127.0.0.1:{PUERTO_NUBE}"
PID_NUBE = os.path.join(CACHE, "ollama.pid")
REGISTRO_NUBE = os.path.join(CACHE, "ollama.log")
AVISO_NUBE = os.path.join(CACHE, "aviso-conectar")   # para no avisar más de 1 vez al día
MODELOS_NUBE = "gpt-oss:120b-cloud,gemma4:cloud"   # los del plan gratis
NOMBRES = {"nube": "IA en línea", "local": "IA local"}
# Nombre visible según el archivo que usa este equipo (dya-ia-config elige el
# que haya: los instalados con una ISO anterior tienen Gemma).
MODELOS_LOCALES = {"qwen3.5-2b": "Qwen3.5 2B", "gemma-4-e2b": "Gemma 4 E2B",
                   "gemma-2-2b": "Gemma 2 2B"}


def _modelo_local():
    try:
        with open(CONFIG_MOTOR, encoding="utf-8") as f:
            archivo = re.search(r"-m\s+(\S+\.gguf)", f.read()).group(1)
    except (OSError, AttributeError):
        return "modelo local"
    archivo = os.path.basename(archivo).lower()
    return next((v for k, v in MODELOS_LOCALES.items() if archivo.startswith(k)),
                archivo.removesuffix(".gguf"))


_nube = {"conf": None, "hasta": 0.0, "red": None, "red_ts": 0.0,
         "cuenta": None, "cuenta_ts": 0.0, "enlace": None,
         "modo": None, "liberado": False, "descartados": set(), "usado": None}


class _FalloNube(Exception):
    pass


def _conf_nube():
    if _nube["conf"] is None:
        conf = {"ACTIVA": "si", "MODELOS": MODELOS_NUBE}
        try:
            with open(CONFIG_NUBE) as f:
                for linea in f:
                    linea = linea.split("#", 1)[0].strip()
                    if "=" in linea:
                        k, v = linea.split("=", 1)
                        conf[k.strip().upper()] = v.strip().strip('"')
        except OSError:
            pass
        _nube["conf"] = conf
    return _nube["conf"]


def _modelos_nube():
    lista = [m.strip() for m in _conf_nube()["MODELOS"].split(",") if m.strip()]
    return [m for m in lista if m not in _nube["descartados"]]


def _pedir_ollama(ruta, cuerpo=None, timeout=10):
    peticion = urllib.request.Request(
        URL_NUBE + ruta, data=json.dumps(cuerpo or {}).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(peticion, timeout=timeout) as r:
        return json.load(r)


def _arrancar_ollama():
    """Arranca la pasarela de Ollama del usuario (ligera: sin modelos locales)."""
    try:
        urllib.request.urlopen(URL_NUBE + "/api/version", timeout=1).close()
        return True
    except (urllib.error.URLError, OSError):
        pass
    if not os.access(OLLAMA, os.X_OK):
        return False
    os.makedirs(CACHE, exist_ok=True)
    with open(REGISTRO_NUBE, "w") as log:
        proc = subprocess.Popen(
            [OLLAMA, "serve"], stdout=log, stderr=log, stdin=subprocess.DEVNULL,
            env={**os.environ, "OLLAMA_HOST": f"127.0.0.1:{PUERTO_NUBE}"},
            start_new_session=True)
    with open(PID_NUBE, "w") as f:
        f.write(str(proc.pid))
    for _ in range(40):
        try:
            urllib.request.urlopen(URL_NUBE + "/api/version", timeout=1).close()
            return True
        except (urllib.error.URLError, OSError):
            if proc.poll() is not None:
                return False
            time.sleep(0.25)
    return False


def _cuenta_conectada():
    """True si este usuario ya conectó su cuenta de Ollama. Si no, guarda el
    enlace para conectarla. Se vuelve a mirar cada 60 s (así, en cuanto se pulsa
    «Conectar» en la web, la siguiente consulta ya va a la nube)."""
    if time.time() - _nube["cuenta_ts"] < 60:
        return _nube["cuenta"]
    _nube["cuenta_ts"] = time.time()
    try:
        _pedir_ollama("/api/me")
        _nube["cuenta"] = True
    except urllib.error.HTTPError as e:
        try:
            _nube["enlace"] = json.load(e).get("signin_url")
        except (ValueError, OSError):
            pass
        _nube["cuenta"] = False
    except (urllib.error.URLError, OSError, ValueError):
        _nube["cuenta"] = False
    return _nube["cuenta"]


def _invitar_a_conectar():
    """Muestra (y abre en el navegador) el enlace para conectar la cuenta gratis,
    como mucho una vez al día y solo en una terminal."""
    if not _nube["enlace"] or not sys.stdout.isatty():
        return
    try:
        if time.time() - os.path.getmtime(AVISO_NUBE) < 86400:
            return
    except OSError:
        pass
    conectar_nube(abrir_navegador=True)
    try:
        os.makedirs(CACHE, exist_ok=True)
        open(AVISO_NUBE, "w").close()
    except OSError:
        pass


def conectar_nube(abrir_navegador=True):
    """`ia --conectar`: enlace para conectar la cuenta gratis de Ollama."""
    if not _arrancar_ollama():
        print(f"{AMARILLO}No está la pasarela de Ollama ({OLLAMA}).{FIN}")
        return False
    _nube["cuenta_ts"] = 0
    if _cuenta_conectada():
        print(f"{VERDE}Tu cuenta de Ollama ya está conectada:{FIN} con internet "
              f"respondo con la IA en línea.")
        return True
    if not _nube["enlace"]:
        print(f"{AMARILLO}No pude pedir el enlace a Ollama (¿hay internet?).{FIN}")
        return False
    print(f"{AZUL}Conecta tu cuenta GRATIS de Ollama para usar la IA en línea "
          f"(mucho más potente) cuando haya internet:{FIN}\n"
          f"   {NEGRITA}{_nube['enlace']}{FIN}\n"
          f"{TENUE}Entra con tu cuenta (o créala gratis) y pulsa «Connect». "
          f"Sin conectarla sigo con la IA local.{FIN}")
    if abrir_navegador and shutil.which("xdg-open") and (
            os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        subprocess.Popen(["xdg-open", _nube["enlace"]], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    return False


def nube_disponible():
    """True si toca usar la IA en línea: activada, con internet (se recuerda
    30 s), con la pasarela de Ollama y con la cuenta conectada."""
    if _conf_nube().get("ACTIVA", "si").lower() in ("no", "0", "false"):
        return False
    if time.time() < _nube["hasta"] or not _modelos_nube():
        return False
    if time.time() - _nube["red_ts"] > 30:
        _nube["red"], _nube["red_ts"] = hay_internet(timeout=1.5), time.time()
    if not _nube["red"] or not _arrancar_ollama():
        return False
    if not _cuenta_conectada():
        _invitar_a_conectar()
        return False
    return True


def _pedir_nube(modelo, historial, esquema, timeout):
    cuerpo = {"model": modelo, "messages": historial, "stream": False,
              "format": esquema, "options": {"temperature": 0.2}}
    try:
        return _pedir_ollama("/api/chat", cuerpo, timeout)["message"]["content"]
    except urllib.error.HTTPError as e:
        if e.code == 404:   # falta el «puntero» del modelo: se baja (~300 bytes)
            _pedir_ollama("/api/pull", {"model": modelo, "stream": False}, 120)
            return _pedir_ollama("/api/chat", cuerpo, timeout)["message"]["content"]
        raise


def _consultar_nube(historial, esquema, timeout):
    """Prueba los modelos en orden. Uno que el plan gratis no permite (o que ya
    no existe) se descarta para el resto de la sesión y se pasa al siguiente."""
    for modelo in _modelos_nube():
        try:
            texto = _pedir_nube(modelo, historial, esquema, min(timeout, 180))
        except urllib.error.HTTPError as e:
            if e.code == 401:
                _nube["cuenta"], _nube["cuenta_ts"] = False, time.time()
                raise _FalloNube("la cuenta de Ollama no está conectada")
            if e.code == 429:
                raise _FalloNube("se acabó el cupo gratis por ahora")
            if e.code in (402, 403, 404):
                _nube["descartados"].add(modelo)
                continue
            raise _FalloNube(f"error {e.code}")
        except (urllib.error.URLError, OSError, TimeoutError, ValueError, KeyError):
            raise _FalloNube("sin conexión")
        if texto:
            _nube["usado"] = modelo
            return texto
    raise _FalloNube("ningún modelo en línea disponible con esta cuenta")


def _avisar_modo(modo):
    """Una línea discreta cada vez que cambia la IA que responde."""
    clave = (modo, _nube["usado"])
    if _nube["modo"] != clave:
        nombre = (f"{NOMBRES['nube']} ({_nube['usado']})" if modo == "nube"
                  else f"{NOMBRES['local']} ({_modelo_local()})")
        print(f"{TENUE}[{nombre}]{FIN}", file=sys.stderr)
        _nube["modo"] = clave


def _liberar_local():
    """Al pasar a la IA en línea, descarga el modelo local si estaba cargado
    (libera la RAM sin esperar al ttl de llama-swap)."""
    if _nube["liberado"] or _precalentando():
        return   # no cortar la preparación de la caché que corre en segundo plano
    _nube["liberado"] = True
    if servidor_activo():
        try:
            urllib.request.urlopen(URL + "/unload", timeout=5).close()
        except (urllib.error.URLError, OSError):
            pass


def preguntar_json(sistema, peticion, esquema, modelo=MODELO_SISTEMA,
                   intentos=2, timeout=600):
    """Consulta puntual a un rol: arranca el motor si hace falta y devuelve el
    dict JSON (o None). Para tareas automáticas (sin conversación)."""
    arrancar_servidor()
    historial = [{"role": "system", "content": sistema},
                 {"role": "user", "content": peticion}]
    for _ in range(intentos):
        try:
            _, datos = consultar(historial, esquema, modelo=modelo,
                                 timeout=timeout)
        except (urllib.error.URLError, OSError, TimeoutError):
            return None
        if isinstance(datos, dict):
            return datos
    return None


# ---------- búsqueda en internet (opcional, solo si hay conexión) ----------

def hay_internet(timeout=2):
    """True si se puede abrir una conexión TCP a un servidor de confianza.
    No depende de DNS y es rápida; si no hay red, la IA trabaja sin buscar."""
    import socket
    for host in ("1.1.1.1", "8.8.8.8", "9.9.9.9"):
        try:
            socket.create_connection((host, 443), timeout).close()
            return True
        except OSError:
            continue
    return False


_UA = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"


def _limpiar_html(s):
    import html as _html
    return _html.unescape(re.sub(r"<[^>]+>", " ", s)).strip()


def _pedir_json(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def _ddg_instant(consulta, timeout):
    """Respuesta instantánea de DuckDuckGo (definiciones, resúmenes). Sin clave."""
    import urllib.parse
    q = urllib.parse.urlencode({"q": consulta, "format": "json",
                                "no_html": "1", "skip_disambig": "1"})
    try:
        d = _pedir_json("https://api.duckduckgo.com/?" + q, timeout)
    except (urllib.error.URLError, OSError, TimeoutError, ValueError, json.JSONDecodeError):
        return []
    salida = []
    if d.get("AbstractText"):
        salida.append(f"- {d.get('Heading', '')}: {d['AbstractText']}".strip(" -:"))
    for rt in d.get("RelatedTopics", [])[:4]:
        if isinstance(rt, dict) and rt.get("Text"):
            salida.append(f"- {rt['Text']}")
    return salida


def _wikipedia(consulta, n_result, timeout, idioma="es"):
    """Búsqueda en Wikipedia (sin clave): devuelve títulos y resúmenes."""
    import urllib.parse
    q = urllib.parse.urlencode({"action": "query", "list": "search",
                                "srsearch": consulta, "srlimit": n_result,
                                "format": "json", "utf8": "1"})
    try:
        d = _pedir_json(f"https://{idioma}.wikipedia.org/w/api.php?{q}", timeout)
    except (urllib.error.URLError, OSError, TimeoutError, ValueError, json.JSONDecodeError):
        return []
    salida = []
    for it in d.get("query", {}).get("search", []):
        titulo = it.get("title", "")
        frag = _limpiar_html(it.get("snippet", ""))
        if titulo:
            salida.append(f"- {titulo}: {frag}")
    return salida


def buscar_web(consulta, n_result=5, timeout=8):
    """Busca información en internet SIN clave ni cuenta, combinando la respuesta
    instantánea de DuckDuckGo y Wikipedia (español y, si hace falta, inglés).
    Devuelve texto con los primeros resultados, o "" si no encuentra nada.
    Es la forma en que la IA se informa antes de actuar cuando hay conexión."""
    salida = _ddg_instant(consulta, timeout)
    if len(salida) < n_result:
        salida += _wikipedia(consulta, n_result - len(salida), timeout, "es")
    if len(salida) < n_result:
        salida += _wikipedia(consulta, n_result - len(salida), timeout, "en")
    # quitar duplicados conservando el orden
    vistos, limpio = set(), []
    for s in salida:
        if s and s not in vistos:
            vistos.add(s)
            limpio.append(s)
    return "\n".join(limpio[:n_result])


def buscar_varias(consultas, max_consultas=3, por_consulta=5):
    """Hace varias búsquedas y junta los resultados en un texto compacto."""
    partes = []
    for c in list(consultas)[:max_consultas]:
        c = c.strip()
        if not c:
            continue
        res = buscar_web(c, n_result=por_consulta)
        partes.append(f"Búsqueda: {c}\n" + (res or "(sin resultados)"))
    return "\n\n".join(partes)


_RE_CODIGO = re.compile(
    r"\b(script|programa(r|me)?|programaci[oó]n|c[oó]digo|code|funci[oó]n|"
    r"bash|shell|python|javascript|typescript|java\b|c\+\+|golang|\bgo\b|"
    r"rust|php|html|css|sql|json|yaml|regex|git\b|docker|compilar|depurar|"
    r"algoritmo|api\b|clase\b|m[eé]todo|variable|bucle)\b", re.I)
_RE_OFIMATICA = re.compile(
    r"\b(presentaci[oó]n|diapositiva|documento|carta|informe|redacta|"
    r"curr[ií]culum|curriculum|cv\b|hoja de c[aá]lculo|tabla\b|acta\b|"
    r"ensayo|resumen escrito|correo|email|powerpoint|word|excel|impress)\b",
    re.I)


def clasificar(peticion):
    """Decide a qué especialista enviar la tarea, por reglas (instantáneo, sin
    gastar un modelo). Devuelve (dominio, dificultad).
    - 'codigo' para programar/scripts  -> modelo de código
    - 'ofimatica' para crear documentos -> lo sirve el modelo 'sistema' + herramientas
    - 'sistema' para el resto.
    Las pistas de código mandan sobre las de ofimática ("escribe un script")."""
    if _RE_CODIGO.search(peticion):
        return ("codigo", "simple")
    if _RE_OFIMATICA.search(peticion):
        return ("ofimatica", "simple")
    return ("sistema", "simple")


# ---------- aplicaciones ----------

DIRS_APPS = ["/usr/share/applications", "/usr/local/share/applications",
             os.path.expanduser("~/.local/share/applications"),
             "/var/lib/flatpak/exports/share/applications"]


def _leer_desktop(ruta):
    datos = {}
    try:
        with open(ruta, encoding="utf-8", errors="replace") as f:
            seccion = None
            for linea in f:
                linea = linea.strip()
                if linea.startswith("["):
                    seccion = linea
                elif seccion == "[Desktop Entry]" and "=" in linea:
                    k, v = linea.split("=", 1)
                    datos.setdefault(k, v)
    except OSError:
        pass
    return datos


def aplicaciones():
    """{identificador: (nombre, orden, descripción)} de las apps gráficas."""
    apps = {}
    for d in DIRS_APPS:
        for ruta in glob.glob(os.path.join(d, "*.desktop")):
            e = _leer_desktop(ruta)
            if (e.get("Type") != "Application" or e.get("NoDisplay") == "true"
                    or e.get("Terminal") == "true" or "Exec" not in e):
                continue
            ident = os.path.basename(ruta)[:-len(".desktop")]
            nombre = e.get("Name[es]") or e.get("Name", ident)
            tipo = (e.get("GenericName[es]") or e.get("GenericName")
                    or e.get("Comment[es]") or e.get("Comment") or "")
            apps[ident] = (nombre, e["Exec"], tipo[:60])
    return apps


def lista_aplicaciones():
    apps = aplicaciones()
    return "; ".join(f"{i} ({n}: {t})" if t else f"{i} ({n})"
                     for i, (n, _, t) in sorted(apps.items()))


def orden_de(objetivo):
    """Convierte un identificador, nombre o comando en la orden a ejecutar."""
    apps = aplicaciones()
    obj = objetivo.strip()
    if re.match(r"(sudo\s+)?apt(-get)?\s", obj):
        obj = obj.split()[-1]
    clave = obj[:-len(".desktop")] if obj.endswith(".desktop") else obj
    exacto = apps.get(clave) or next(
        (a for i, a in apps.items() if i.lower() == clave.lower()
         or a[0].lower() == clave.lower()), None)
    if exacto is None:
        parciales = [a for i, a in apps.items()
                     if clave.lower() in i.lower() or clave.lower() in a[0].lower()]
        if len(parciales) == 1 and not shutil.which(clave.split()[0]):
            exacto = parciales[0]
    if exacto:
        return re.sub(r"\s%[a-zA-Z]", "", exacto[1]).strip(), exacto[0]
    primero = obj.split()[0] if obj.split() else ""
    if shutil.which(os.path.expanduser(primero)):
        return obj, obj
    return None, obj


def abrir(objetivos):
    for obj in objetivos:
        orden, nombre = orden_de(obj)
        if not orden:
            print(f"{AMARILLO}No encuentro la aplicación «{obj}».{FIN}")
            continue
        print(f"{AZUL}↗{FIN} Abriendo {NEGRITA}{nombre}{FIN}")
        subprocess.Popen(["bash", "-c", orden], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True, cwd=os.path.expanduser("~"))


# ---------- paquetes apt ----------

def listas_apt_vacias():
    d = "/var/lib/apt/lists"
    return not any(n.endswith("_Packages") or n.endswith("Packages.lz4")
                   for n in os.listdir(d)) if os.path.isdir(d) else True


def paquetes_a_instalar(comando):
    try:
        partes = shlex.split(comando)
    except ValueError:
        return []
    if "install" not in partes or not any(
            p in ("apt", "apt-get") for p in partes):
        return []
    resto = partes[partes.index("install") + 1:]
    return [p for p in resto
            if not p.startswith("-") and not p.endswith(".deb")
            and "/" not in p and p not in ("&&", ";", "|")]


def existe_paquete(nombre):
    salida = subprocess.run(["apt-cache", "policy", nombre],
                            capture_output=True, text=True,
                            env={**os.environ, "LANG": "C"}).stdout
    m = re.search(r"Candidate:\s*(\S+)", salida)
    return bool(m and m.group(1) != "(none)")


def _parecidos(nombre):
    salida = subprocess.run(
        ["apt-cache", "search", "--names-only", nombre.split("-")[0]],
        capture_output=True, text=True).stdout
    return [l.split(" - ")[0] for l in salida.splitlines()][:8]


def revisar_paquetes(comandos):
    """Mensaje para la IA si algún paquete a instalar no existe; None si todo bien."""
    faltan = []
    for c in comandos:
        for p in paquetes_a_instalar(c):
            if not existe_paquete(p):
                faltan.append((p, _parecidos(p)))
    if not faltan:
        return None
    lineas = [f"- '{p}' no existe. Paquetes reales parecidos: "
              f"{', '.join(s) if s else 'ninguno'}" for p, s in faltan]
    return ("Algunos paquetes no existen en los repositorios:\n"
            + "\n".join(lineas)
            + "\nCorrige los comandos usando un nombre real de la lista, "
              "o explica que no está disponible.")


# ---------- ejecución ----------

# Comandos que siempre exigen escribir "sí" completo antes de ejecutarse
PELIGROSOS = [
    r"\brm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s+)+(/|/\*|~|\$HOME)(\s|$)",
    r"\bmkfs(\.\w+)?\b", r"\bdd\b.*\bof=/dev/", r"\bwipefs\b",
    r"\b(fdisk|parted|sfdisk|gdisk)\b", r">\s*/dev/sd[a-z]",
    r":\(\)\s*\{", r"\bchmod\s+(-R\s+)?[0-7]*\s+/(\s|$)",
    r"\bapt(-get)?\s+(remove|purge)\b.*\b(apt|dpkg|sudo|systemd|linux-image\S*|xfce4\S*|lightdm)\b",
]


def es_peligroso(comando):
    return any(re.search(p, comando) for p in PELIGROSOS)


def confirmar(comandos, automatico):
    peligro = any(es_peligroso(c) for c in comandos)
    for c in comandos:
        marca = f"{ROJO}⚠{FIN}" if es_peligroso(c) else f"{AZUL}→{FIN}"
        print(f"   {marca} {NEGRITA}{c}{FIN}")
    try:
        if peligro:
            r = input(f"{ROJO}Hay comandos peligrosos.{FIN} "
                      "Escribe 'sí' para ejecutarlos: ")
            return r.strip().lower() in ("sí", "si")
        if automatico:
            return True
        r = input(f"¿Ejecutar? [{VERDE}S{FIN}/n] ")
        return r.strip().lower() in ("", "s", "si", "sí", "y", "yes")
    except EOFError:
        return False


def preparar_sudo(comandos):
    """Pide la contraseña de sudo una sola vez, antes de empezar."""
    if not any(re.search(r"\bsudo\b", c) for c in comandos):
        return True
    if subprocess.run(["sudo", "-n", "true"], capture_output=True).returncode == 0:
        return True
    print(f"{TENUE}Hacen falta permisos de administrador.{FIN}")
    return subprocess.run(["sudo", "-v"]).returncode == 0


def pista_comando(salida):
    """Si falta un comando, pregunta a command-not-found qué paquete lo trae."""
    m = re.search(r"([\w.+-]+): (?:orden no encontrada|command not found)",
                  salida)
    if not m or not os.path.exists("/usr/lib/command-not-found"):
        return ""
    r = subprocess.run(["/usr/lib/command-not-found", m.group(1)],
                       capture_output=True, text=True,
                       env={**os.environ, "LANG": "C"})
    paquetes = re.findall(r"sudo apt install (\S+)", r.stdout + r.stderr)
    if not paquetes:
        return ""
    return (f"El comando '{m.group(1)}' no está instalado; lo trae el "
            f"paquete '{paquetes[0]}'. Hay que instalarlo primero con: "
            f"sudo apt-get install -y {paquetes[0]}")


def ejecutar(comandos):
    """Ejecuta en orden; se detiene al primer fallo.
    Devuelve (todo_bien, resumen para la IA)."""
    resumen = []
    entorno = {**os.environ, "DEBIAN_FRONTEND": "noninteractive"}
    for c in comandos:
        print(f"{TENUE}$ {c}{FIN}")
        proc = subprocess.Popen(["bash", "-c", c], stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True,
                                env=entorno)
        cola = []
        for linea in proc.stdout:
            print(linea, end="", flush=True)
            cola = (cola + [linea.rstrip()])[-25:]
        proc.wait()
        resumen.append(f"$ {c}\n(código {proc.returncode})\n" + "\n".join(cola))
        if proc.returncode != 0:
            print(f"{ROJO}✗ Falló (código {proc.returncode}).{FIN}")
            if proc.returncode == 127:
                pista = pista_comando("\n".join(cola))
                if pista:
                    print(f"{AMARILLO}Pista:{FIN} {pista}")
                    resumen.append(pista)
            return False, "\n\n".join(resumen)
    print(f"{VERDE}✓ Hecho.{FIN}")
    return True, "\n\n".join(resumen)


# ---------- contexto ----------

def carpetas_usuario():
    """Rutas reales de Escritorio, Documentos, Descargas... (xdg-user-dirs)."""
    nombres = {"DESKTOP": "Escritorio", "DOCUMENTS": "Documentos",
               "DOWNLOAD": "Descargas", "MUSIC": "Música",
               "PICTURES": "Imágenes", "VIDEOS": "Vídeos"}
    rutas = {}
    try:
        with open(os.path.expanduser("~/.config/user-dirs.dirs")) as f:
            for linea in f:
                m = re.match(r'XDG_(\w+)_DIR="(.*)"', linea.strip())
                if m and m.group(1) in nombres:
                    rutas[nombres[m.group(1)]] = m.group(2).replace(
                        "$HOME", os.path.expanduser("~"))
    except OSError:
        pass
    for n in nombres.values():
        rutas.setdefault(n, os.path.join(os.path.expanduser("~"), n))
    return ", ".join(f"{n}={r}" for n, r in rutas.items())


def contexto_sistema():
    try:
        sistema = platform.freedesktop_os_release()["PRETTY_NAME"]
    except (OSError, KeyError):
        sistema = "D&A Global OS"
    return (f"Sistema: {sistema}. "
            f"Fecha: {datetime.date.today():%d/%m/%Y}. "
            f"Usuario: {getpass.getuser()}. "
            f"Carpeta personal: {os.path.expanduser('~')}. "
            f"Directorio actual: {os.getcwd()}.")
