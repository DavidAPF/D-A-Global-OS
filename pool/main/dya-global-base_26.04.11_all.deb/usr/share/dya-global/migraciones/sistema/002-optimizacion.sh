# Temporizadores que un escritorio no necesita y servicios que solo hacen falta al usarlos
for s in lynis.timer phpsessionclean.timer motd-news.timer update-notifier-download.timer \
	update-notifier-motd.timer xfs_scrub_all.timer cups-browsed.service e2scrub_reap.service \
	tor.service tor@default.service openvpn.service lxc.service lxc-net.service; do
	systemctl disable "$s" 2>/dev/null || true
done
# Android: solo si no se ha preparado todavía; dya-apk lo arranca al usarlo
if [ ! -e /var/lib/waydroid/waydroid.cfg ]; then
	systemctl disable waydroid-container.service lxc-monitord.service 2>/dev/null || true
fi
# Controladores y firmware en Discover
systemctl enable dya-controladores.timer fwupd-refresh.timer 2>/dev/null || true
systemctl enable dya-zram-ram.service 2>/dev/null || true
