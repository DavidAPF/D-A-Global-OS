# D&A Desktop: «widgets» en el menú del escritorio y pantalla de inicio de sesión propia
/usr/local/sbin/dya-traducciones || true
for f in /etc/sddm.conf /etc/sddm.conf.d/kde_settings.conf; do
	[ -f "$f" ] && sed -i 's/^Current=\(breeze\|ubuntu-theme\)$/Current=dya/' "$f"
done
if ! grep -qs '^Current=' /etc/sddm.conf /etc/sddm.conf.d/*.conf; then
	mkdir -p /etc/sddm.conf.d
	printf '[Theme]\nCurrent=dya\n' > /etc/sddm.conf.d/dya-tema.conf
fi
