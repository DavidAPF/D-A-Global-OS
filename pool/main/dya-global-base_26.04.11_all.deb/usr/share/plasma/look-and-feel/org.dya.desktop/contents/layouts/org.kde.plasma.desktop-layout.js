// D&A Desktop: distribución del escritorio (la aplica «Tema global» o dya-desktop).
// Barra flotante abajo con el globo D&A, programas fijados en el centro y la
// bandeja a la derecha; en el escritorio, widgets que el usuario puede quitar,
// mover o ampliar con «Añadir widgets» (clic derecho en el escritorio).

function probar(f) { try { f(); } catch (e) { print("dya-desktop: " + e); } }

// ---------- barra ----------
var panel = new Panel;
panel.location = "bottom";
panel.height = 2 * Math.ceil(gridUnit * 2.75 / 2);
probar(function () { panel.floating = true; });
probar(function () { panel.opacity = "translucent"; });

var inicio = panel.addWidget("org.dya.menu");
inicio.globalShortcut = "Alt+F1";   // la tecla Meta abre el menú

panel.addWidget("org.kde.plasma.panelspacer");

var tareas = panel.addWidget("org.kde.plasma.icontasks");
tareas.currentConfigGroup = ["General"];
tareas.writeConfig("launchers", [
    "applications:firefox.desktop",
    "applications:org.kde.dolphin.desktop",
    "applications:libreoffice-writer.desktop",
    "applications:org.kde.discover.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:vlc.desktop"
]);

panel.addWidget("org.kde.plasma.panelspacer");
panel.addWidget("org.kde.plasma.systemtray");
var reloj = panel.addWidget("org.kde.plasma.digitalclock");
reloj.currentConfigGroup = ["Appearance"];
reloj.writeConfig("showDate", true);
reloj.writeConfig("dateFormat", "shortDate");

// ---------- escritorio ----------
var escritorios = desktopsForActivity(currentActivity());
for (var i = 0; i < escritorios.length; i++) {
    var d = escritorios[i];
    d.wallpaperPlugin = "org.kde.image";
    d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    d.writeConfig("Image", "file:///usr/share/backgrounds/dya-global/fondo.png");
    d.writeConfig("FillMode", 2);   // recortar para llenar

    if (i > 0) continue;   // widgets solo en la pantalla principal
    var geo = screenGeometry(d.screen);
    var ancho = 22 * gridUnit;
    var x = geo.width - ancho - 2 * gridUnit;
    var y = 2 * gridUnit;
    var widgets = [
        ["org.dya.fecha", 7.5 * gridUnit],
        ["org.dya.recursos", 8.5 * gridUnit],
        ["org.dya.musica", 7 * gridUnit]
    ];
    for (var w = 0; w < widgets.length; w++) {
        probar(function () {
            d.addWidget(widgets[w][0], x, y, ancho, widgets[w][1]);
        });
        y += widgets[w][1] + gridUnit;
    }
}
