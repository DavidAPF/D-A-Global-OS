// Tarjeta de cristal de D&A Desktop (mismo aspecto en todos los widgets).
import QtQuick

Rectangle {
    radius: 20
    border.width: 1
    border.color: Qt.rgba(1, 1, 1, 0.14)
    gradient: Gradient {
        GradientStop { position: 0; color: Qt.rgba(36 / 255, 62 / 255, 118 / 255, 0.62) }
        GradientStop { position: 1; color: Qt.rgba(12 / 255, 24 / 255, 52 / 255, 0.78) }
    }
    // brillo fino en el borde superior
    Rectangle {
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: parent.radius / 2 }
        height: 1
        color: Qt.rgba(1, 1, 1, 0.10)
    }
}
