// Fecha y tiempo (D&A): fecha grande y el tiempo de la ciudad que elija el
// usuario (Open-Meteo, sin cuenta ni clave). Sin internet solo muestra la fecha.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: raiz
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    property date ahora: new Date()
    property real grados: NaN
    property string estado: ""
    property string icono: "weather-none-available"
    property bool editandoCiudad: false

    readonly property color t1: "#eef3fb"
    readonly property color t2: "#a9b7cc"
    readonly property color dorado: "#f2c14e"

    Timer { interval: 20000; running: true; repeat: true; onTriggered: raiz.ahora = new Date() }
    Timer { interval: 30 * 60 * 1000; running: true; repeat: true; triggeredOnStart: true; onTriggered: raiz.actualizarTiempo() }

    function pedir(url, hecho) {
        const x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            if (x.status === 200) { try { hecho(JSON.parse(x.responseText)) } catch (e) {} }
        }
        x.open("GET", url)
        x.send()
    }

    // Códigos WMO de Open-Meteo -> icono de Breeze y texto
    function describir(c) {
        if (c === 0) return ["weather-clear", "Despejado"]
        if (c <= 2) return ["weather-few-clouds", "Parcialmente nublado"]
        if (c === 3) return ["weather-clouds", "Nublado"]
        if (c <= 48) return ["weather-fog", "Niebla"]
        if (c <= 67 || (c >= 80 && c <= 82)) return ["weather-showers", "Lluvia"]
        if (c <= 77 || c === 85 || c === 86) return ["weather-snow", "Nieve"]
        return ["weather-storm", "Tormenta"]
    }

    function actualizarTiempo() {
        const cfg = Plasmoid.configuration
        if (!cfg.ciudad) return
        pedir("https://api.open-meteo.com/v1/forecast?latitude=" + cfg.latitud + "&longitude=" + cfg.longitud
              + "&current=temperature_2m,weather_code&timezone=auto", function (d) {
            raiz.grados = Math.round(d.current.temperature_2m)
            const r = raiz.describir(d.current.weather_code)
            raiz.icono = r[0]; raiz.estado = r[1]
        })
    }

    function elegirCiudad(nombre) {
        if (!nombre.trim()) return
        pedir("https://geocoding-api.open-meteo.com/v1/search?count=1&language=es&name=" + encodeURIComponent(nombre.trim()), function (d) {
            if (!d.results || !d.results.length) return
            const c = d.results[0]
            Plasmoid.configuration.ciudad = c.name
            Plasmoid.configuration.latitud = c.latitude
            Plasmoid.configuration.longitud = c.longitude
            raiz.editandoCiudad = false
            raiz.actualizarTiempo()
        })
    }

    fullRepresentation: Vidrio {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 21
        Layout.preferredHeight: Kirigami.Units.gridUnit * 7.5
        Layout.minimumWidth: Kirigami.Units.gridUnit * 14
        Layout.minimumHeight: Kirigami.Units.gridUnit * 6

        RowLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.gridUnit
            spacing: Kirigami.Units.gridUnit

            ColumnLayout {
                spacing: 0
                Layout.alignment: Qt.AlignBottom
                PC3.Label { text: Qt.locale().standaloneDayName(raiz.ahora.getDay(), Locale.LongFormat).replace(/^./, s => s.toUpperCase()); color: raiz.t2; font.pixelSize: 13 }
                PC3.Label { text: Qt.locale().toString(raiz.ahora, "d MMM").replace(".", ""); color: raiz.t1; font.pixelSize: 44; font.weight: Font.Light }
                PC3.Label { text: Qt.locale().toString(raiz.ahora, "MMMM 'de' yyyy").replace(/^./, s => s.toUpperCase()); color: raiz.t2; font.pixelSize: 14 }
            }

            Item { Layout.fillWidth: true }

            // Tiempo: ciudad elegida, o campo para elegirla
            ColumnLayout {
                Layout.alignment: Qt.AlignBottom | Qt.AlignRight
                spacing: 2
                visible: !raiz.editandoCiudad && Plasmoid.configuration.ciudad !== ""
                RowLayout {
                    Layout.alignment: Qt.AlignRight
                    spacing: 8
                    Kirigami.Icon { source: raiz.icono; implicitWidth: 34; implicitHeight: 34 }
                    PC3.Label { text: isNaN(raiz.grados) ? "—" : raiz.grados + "°"; color: raiz.t1; font.pixelSize: 32; font.weight: Font.Light }
                }
                PC3.Label {
                    Layout.alignment: Qt.AlignRight
                    text: Plasmoid.configuration.ciudad + (raiz.estado ? " · " + raiz.estado : "")
                    color: raiz.t2; font.pixelSize: 12
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: raiz.editandoCiudad = true }
                }
            }
            ColumnLayout {
                Layout.alignment: Qt.AlignVCenter | Qt.AlignRight
                visible: raiz.editandoCiudad || Plasmoid.configuration.ciudad === ""
                PC3.Label { text: "¿De qué ciudad quieres el tiempo?"; color: raiz.t2; font.pixelSize: 12 }
                PC3.TextField {
                    id: campoCiudad
                    Layout.preferredWidth: Kirigami.Units.gridUnit * 9
                    placeholderText: "Escribe tu ciudad"
                    onAccepted: raiz.elegirCiudad(text)
                }
            }
        }
    }
}
