// Música (D&A): carátula, título y controles del reproductor que esté sonando
// (cualquiera compatible con MPRIS: VLC, Firefox, Spotify, mpv...).
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.mpris as Mpris

PlasmoidItem {
    id: raiz
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    readonly property color t1: "#eef3fb"
    readonly property color t2: "#a9b7cc"
    readonly property color t3: "#6f819e"

    Mpris.Mpris2Model { id: mpris }
    readonly property var jugador: mpris.currentPlayer
    readonly property bool hay: jugador !== null && jugador !== undefined
    readonly property bool sonando: hay && jugador.playbackStatus === Mpris.PlaybackStatus.Playing

    // La posición del reproductor solo cambia al consultarla: se pide cada segundo
    Timer { interval: 1000; repeat: true; running: raiz.sonando; onTriggered: raiz.jugador.updatePosition() }

    function minutos(us) {
        const s = Math.max(0, Math.floor(us / 1000000))
        return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0")
    }

    component Boton: Rectangle {
        property string icono
        property bool principal: false
        signal pulsado()
        implicitWidth: principal ? 36 : 30; implicitHeight: implicitWidth
        radius: width / 2
        color: principal ? raiz.t1 : (zona.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : "transparent")
        Kirigami.Icon {
            anchors.centerIn: parent
            source: icono
            implicitWidth: 16; implicitHeight: 16
            color: principal ? "#0b1730" : raiz.t1
            isMask: true
        }
        MouseArea { id: zona; anchors.fill: parent; hoverEnabled: true; onClicked: parent.pulsado() }
    }

    fullRepresentation: Vidrio {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 21
        Layout.preferredHeight: Kirigami.Units.gridUnit * 7
        Layout.minimumWidth: Kirigami.Units.gridUnit * 15
        Layout.minimumHeight: Kirigami.Units.gridUnit * 5.5

        RowLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.gridUnit
            spacing: 14

            Rectangle {
                implicitWidth: 64; implicitHeight: 64; radius: 12; color: "#050c1d"
                border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.09)
                clip: true
                Image {
                    anchors.fill: parent; anchors.margins: 1
                    fillMode: Image.PreserveAspectCrop
                    source: raiz.hay && raiz.jugador.artUrl ? raiz.jugador.artUrl : "file:///usr/share/dya-global/escritorio/inicio.png"
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                PC3.Label {
                    Layout.fillWidth: true; elide: Text.ElideRight
                    text: raiz.hay && raiz.jugador.track ? raiz.jugador.track : "Nada sonando"
                    color: raiz.t1; font.pixelSize: 14; font.weight: Font.DemiBold
                }
                PC3.Label {
                    Layout.fillWidth: true; elide: Text.ElideRight
                    text: raiz.hay ? (raiz.jugador.artist || raiz.jugador.identity) : "Pon música en VLC o en el navegador"
                    color: raiz.t2; font.pixelSize: 12
                }
                RowLayout {
                    visible: raiz.hay
                    spacing: 4
                    Layout.topMargin: 4
                    Boton { icono: "media-skip-backward"; enabled: raiz.hay && raiz.jugador.canGoPrevious; onPulsado: raiz.jugador.Previous() }
                    Boton { icono: raiz.sonando ? "media-playback-pause" : "media-playback-start"; principal: true; onPulsado: raiz.jugador.PlayPause() }
                    Boton { icono: "media-skip-forward"; enabled: raiz.hay && raiz.jugador.canGoNext; onPulsado: raiz.jugador.Next() }
                }
                Rectangle {
                    visible: raiz.hay && raiz.jugador.length > 0
                    Layout.fillWidth: true; Layout.topMargin: 6; height: 4; radius: 2; color: Qt.rgba(1, 1, 1, 0.08)
                    Rectangle {
                        height: parent.height; radius: 2; color: raiz.t1
                        width: raiz.hay && raiz.jugador.length > 0 ? parent.width * Math.min(1, raiz.jugador.position / raiz.jugador.length) : 0
                    }
                }
                RowLayout {
                    visible: raiz.hay && raiz.jugador.length > 0
                    PC3.Label { text: raiz.hay ? raiz.minutos(raiz.jugador.position) : ""; color: raiz.t3; font.pixelSize: 11 }
                    Item { Layout.fillWidth: true }
                    PC3.Label { text: raiz.hay ? raiz.minutos(raiz.jugador.length) : ""; color: raiz.t3; font.pixelSize: 11 }
                }
            }
        }
    }
}
