// Recursos del equipo (D&A): procesador en un anillo, y memoria, disco y
// batería en barras. Datos de los sensores de KDE (los mismos del Monitor del sistema).
import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami
import org.kde.ksysguard.sensors as Sensors

PlasmoidItem {
    id: raiz
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    readonly property color t1: "#eef3fb"
    readonly property color t2: "#a9b7cc"
    readonly property color t3: "#6f819e"
    readonly property color azul: "#2f7bff"
    readonly property color verde: "#5ad13b"

    Sensors.Sensor { id: cpu; sensorId: "cpu/all/usage"; updateRateLimit: 2000 }
    Sensors.Sensor { id: memUsada; sensorId: "memory/physical/used"; updateRateLimit: 4000 }
    Sensors.Sensor { id: memTotal; sensorId: "memory/physical/total" }
    Sensors.Sensor { id: discoUsado; sensorId: "disk/all/used"; updateRateLimit: 30000 }
    Sensors.Sensor { id: discoTotal; sensorId: "disk/all/total" }

    P5Support.DataSource {
        id: energia
        engine: "powermanagement"
        connectedSources: ["Battery"]
        interval: 60000
    }
    readonly property bool hayBateria: energia.data["Battery"] ? energia.data["Battery"]["Has Battery"] === true : false
    readonly property int bateria: energia.data["Battery"] ? energia.data["Battery"]["Percent"] || 0 : 0

    function gb(bytes) { return (bytes / 1073741824).toLocaleString(Qt.locale(), "f", bytes >= 10 * 1073741824 ? 0 : 1) }
    function fraccion(a, b) { return b > 0 ? Math.min(1, a / b) : 0 }

    component Medida: ColumnLayout {
        property string nombre
        property string valor
        property real parte
        property color color: raiz.azul
        spacing: 5
        Layout.fillWidth: true
        RowLayout {
            PC3.Label { text: nombre; color: raiz.t1; font.pixelSize: 13 }
            Item { Layout.fillWidth: true }
            PC3.Label { text: valor; color: raiz.t2; font.pixelSize: 13 }
        }
        Rectangle {
            Layout.fillWidth: true; height: 4; radius: 2; color: Qt.rgba(1, 1, 1, 0.08)
            Rectangle { width: parent.width * parte; height: parent.height; radius: 2; color: parent.parent.color }
        }
    }

    fullRepresentation: Vidrio {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 21
        Layout.preferredHeight: Kirigami.Units.gridUnit * 8.5
        Layout.minimumWidth: Kirigami.Units.gridUnit * 15
        Layout.minimumHeight: Kirigami.Units.gridUnit * 7

        RowLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.gridUnit
            spacing: Kirigami.Units.gridUnit * 1.1

            // Anillo del procesador
            Item {
                id: anillo
                implicitWidth: 86; implicitHeight: 86
                readonly property real uso: Math.max(0, Math.min(100, cpu.value || 0))
                Shape {
                    anchors.fill: parent
                    preferredRendererType: Shape.CurveRenderer
                    ShapePath {
                        strokeColor: Qt.rgba(1, 1, 1, 0.08); strokeWidth: 7; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                        PathAngleArc { centerX: 43; centerY: 43; radiusX: 39; radiusY: 39; startAngle: 0; sweepAngle: 360 }
                    }
                    ShapePath {
                        strokeColor: raiz.azul; strokeWidth: 7; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                        PathAngleArc { centerX: 43; centerY: 43; radiusX: 39; radiusY: 39; startAngle: -90; sweepAngle: 3.6 * anillo.uso }
                    }
                }
                ColumnLayout {
                    anchors.centerIn: parent
                    spacing: 0
                    PC3.Label { Layout.alignment: Qt.AlignHCenter; text: Math.round(anillo.uso) + "%"; color: raiz.t1; font.pixelSize: 20; font.weight: Font.Medium }
                    PC3.Label { Layout.alignment: Qt.AlignHCenter; text: "CPU"; color: raiz.t3; font.pixelSize: 10; font.letterSpacing: 1 }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 10
                Medida { nombre: "Memoria"; valor: raiz.gb(memUsada.value || 0) + " de " + raiz.gb(memTotal.value || 0) + " GB"; parte: raiz.fraccion(memUsada.value, memTotal.value) }
                Medida { nombre: "Disco"; valor: raiz.gb(discoUsado.value || 0) + " de " + raiz.gb(discoTotal.value || 0) + " GB"; parte: raiz.fraccion(discoUsado.value, discoTotal.value) }
                Medida { visible: raiz.hayBateria; nombre: "Batería"; valor: raiz.bateria + " %"; parte: raiz.bateria / 100; color: raiz.bateria <= 15 ? "#f2c14e" : raiz.verde }
            }
        }
    }
}
