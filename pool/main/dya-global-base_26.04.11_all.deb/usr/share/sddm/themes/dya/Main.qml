// Inicio de sesión de D&A Global OS (tema de SDDM «dya»).
// Fondo de D&A desenfocado y oscurecido, hora grande, foto del usuario con aro
// dorado, contraseña en cristal y, abajo a la derecha, teclado en pantalla,
// sesión, suspender, reiniciar y apagar.
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import QtQuick.Effects
import QtQuick.VirtualKeyboard

Rectangle {
    id: raiz
    width: 1920; height: 1080
    color: "#01040d"

    readonly property color t1: "#eef3fb"
    readonly property color t2: "#a9b7cc"
    readonly property color azul: "#2f7bff"
    readonly property color dorado: "#f2c14e"
    readonly property real escala: Math.max(0.6, Math.min(width / 1920, height / 1080))

    property int usuarioActual: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    property int sesionActual: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
    property string mensaje: ""
    property date ahora: new Date()

    Timer { interval: 1000; running: true; repeat: true; onTriggered: raiz.ahora = new Date() }

    Connections {
        target: sddm
        function onLoginFailed() {
            raiz.mensaje = "Contraseña incorrecta. Inténtalo de nuevo."
            clave.text = ""
            clave.forceActiveFocus()
            sacudida.start()
        }
        function onLoginSucceeded() { raiz.mensaje = "" }
    }

    // Datos del usuario elegido (userModel no permite leer filas directamente)
    property string nombreUsuario: ""
    property string nombreVisible: ""
    property string fotoUsuario: ""
    Repeater {
        model: userModel
        delegate: Item {
            visible: false
            Component.onCompleted: if (index === raiz.usuarioActual) actualizar()
            Connections { target: raiz; function onUsuarioActualChanged() { if (index === raiz.usuarioActual) actualizar() } }
            function actualizar() {
                raiz.nombreUsuario = model.name
                raiz.nombreVisible = model.realName || model.name
                raiz.fotoUsuario = model.icon || ""
            }
        }
    }

    // ---------- fondo ----------
    Image {
        id: fondo
        anchors.fill: parent
        source: config.background || "/usr/share/backgrounds/dya-global/fondo.png"
        fillMode: Image.PreserveAspectCrop
        visible: false
    }
    MultiEffect {
        anchors.fill: parent
        source: fondo
        autoPaddingEnabled: false
        blurEnabled: true
        blurMax: 64
        blur: 1.0
        blurMultiplier: 1.3
        brightness: -0.28
        saturation: 0.25
        scale: 1.08
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: Qt.rgba(1 / 255, 4 / 255, 13 / 255, 0.35) }
            GradientStop { position: 0.55; color: Qt.rgba(5 / 255, 14 / 255, 36 / 255, 0.05) }
            GradientStop { position: 1; color: Qt.rgba(1 / 255, 4 / 255, 13 / 255, 0.55) }
        }
    }

    // ---------- hora ----------
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: 150 * raiz.escala
        spacing: 4
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatTime(raiz.ahora, "HH:mm")
            color: raiz.t1
            font.pixelSize: 112 * raiz.escala
            font.weight: Font.ExtraLight
            font.letterSpacing: -2
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.locale("es_ES").toString(raiz.ahora, "dddd, d 'de' MMMM")
            color: raiz.t2
            font.pixelSize: 20 * raiz.escala
        }
    }

    // ---------- tarjeta de acceso ----------
    ColumnLayout {
        id: acceso
        anchors.horizontalCenter: parent.horizontalCenter
        y: 470 * raiz.escala
        width: 340 * raiz.escala
        spacing: 0

        // Foto con aro dorado
        Item {
            Layout.alignment: Qt.AlignHCenter
            implicitWidth: 102 * raiz.escala; implicitHeight: implicitWidth
            Rectangle {
                anchors.fill: parent; radius: width / 2
                color: "transparent"; border.width: 3; border.color: raiz.dorado
            }
            Rectangle {
                id: circulo
                anchors.fill: parent; anchors.margins: 3; radius: width / 2
                gradient: Gradient {
                    GradientStop { position: 0; color: "#3b86ff" }
                    GradientStop { position: 1; color: "#173a8a" }
                }
                Text {
                    anchors.centerIn: parent
                    visible: !foto.visible
                    text: raiz.nombreVisible.charAt(0).toUpperCase()
                    color: "white"; font.pixelSize: parent.height * 0.42; font.weight: Font.DemiBold
                }
            }
            Image {
                id: foto
                anchors.fill: circulo
                source: raiz.fotoUsuario
                fillMode: Image.PreserveAspectCrop
                visible: false
            }
            MultiEffect {
                anchors.fill: circulo
                source: foto
                visible: foto.status === Image.Ready && raiz.fotoUsuario.indexOf("/usr/share/sddm/faces") < 0
                maskEnabled: true
                maskSource: mascara
            }
            Item {
                id: mascara
                anchors.fill: circulo; visible: false; layer.enabled: true
                Rectangle { anchors.fill: parent; radius: width / 2; color: "black" }
            }
        }

        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 16 * raiz.escala
            text: raiz.nombreVisible
            color: raiz.t1
            font.pixelSize: 22 * raiz.escala
            font.weight: Font.Medium
        }

        // Otros usuarios (si hay más de uno)
        Row {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 8 * raiz.escala
            visible: userModel.count > 1
            spacing: 8
            Repeater {
                model: userModel
                delegate: Rectangle {
                    width: 30 * raiz.escala; height: width; radius: width / 2
                    color: index === raiz.usuarioActual ? raiz.azul : Qt.rgba(1, 1, 1, 0.12)
                    Text { anchors.centerIn: parent; text: (model.realName || model.name).charAt(0).toUpperCase(); color: "white"; font.pixelSize: parent.height * 0.45 }
                    MouseArea { anchors.fill: parent; onClicked: { raiz.usuarioActual = index; clave.forceActiveFocus() } }
                }
            }
        }

        // Contraseña
        Rectangle {
            id: campo
            Layout.fillWidth: true
            Layout.topMargin: 20 * raiz.escala
            implicitHeight: 46 * raiz.escala
            radius: 12 * raiz.escala
            color: Qt.rgba(10 / 255, 20 / 255, 40 / 255, 0.58)
            border.width: 1
            border.color: clave.activeFocus ? raiz.azul : Qt.rgba(1, 1, 1, 0.16)
            Rectangle {   // halo de foco
                anchors.fill: parent; anchors.margins: -3; radius: parent.radius + 3
                color: "transparent"; border.width: 3
                border.color: Qt.rgba(47 / 255, 123 / 255, 255 / 255, 0.25)
                visible: clave.activeFocus
            }
            TextField {
                id: clave
                anchors { left: parent.left; right: entrar.left; verticalCenter: parent.verticalCenter; leftMargin: 14 * raiz.escala; rightMargin: 6 }
                echoMode: TextInput.Password
                passwordCharacter: "●"
                placeholderText: "Contraseña"
                placeholderTextColor: raiz.t2
                color: raiz.t1
                font.pixelSize: 15 * raiz.escala
                background: null
                focus: true
                Keys.onReturnPressed: raiz.entrar()
                Keys.onEnterPressed: raiz.entrar()
            }
            Rectangle {
                id: entrar
                anchors { right: parent.right; verticalCenter: parent.verticalCenter; rightMargin: 6 * raiz.escala }
                width: 34 * raiz.escala; height: width; radius: 9 * raiz.escala
                color: zonaEntrar.containsMouse ? "#4a8dff" : raiz.azul
                Canvas {   // flecha →
                    anchors.centerIn: parent; width: 16; height: 16
                    onPaint: {
                        const c = getContext("2d"); c.strokeStyle = "white"; c.lineWidth = 2; c.lineCap = "round"; c.lineJoin = "round"
                        c.beginPath(); c.moveTo(2, 8); c.lineTo(14, 8); c.moveTo(9, 3); c.lineTo(14, 8); c.lineTo(9, 13); c.stroke()
                    }
                }
                MouseArea { id: zonaEntrar; anchors.fill: parent; hoverEnabled: true; onClicked: raiz.entrar() }
            }
            SequentialAnimation {
                id: sacudida
                NumberAnimation { target: campo; property: "anchors.horizontalCenterOffset"; to: -10; duration: 50 }
                NumberAnimation { target: campo; property: "anchors.horizontalCenterOffset"; to: 10; duration: 50 }
                NumberAnimation { target: campo; property: "anchors.horizontalCenterOffset"; to: 0; duration: 50 }
            }
        }

        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 16 * raiz.escala
            text: raiz.mensaje !== "" ? raiz.mensaje
                : (keyboard.capsLock ? "Mayúsculas activadas" : "Escribe tu contraseña y pulsa Intro")
            color: raiz.mensaje !== "" || keyboard.capsLock ? raiz.dorado : raiz.t2
            font.pixelSize: 13 * raiz.escala
        }
    }

    function entrar() {
        raiz.mensaje = ""
        sddm.login(raiz.nombreUsuario, clave.text, raiz.sesionActual)
    }

    // ---------- botones de abajo a la derecha ----------
    component Boton: Rectangle {
        id: b
        property string icono
        property string texto: ""
        property string ayuda
        signal pulsado()
        height: 40 * raiz.escala
        width: fila.implicitWidth + 20 * raiz.escala
        radius: 12 * raiz.escala
        color: zona.containsMouse ? Qt.rgba(30 / 255, 50 / 255, 90 / 255, 0.7) : Qt.rgba(10 / 255, 20 / 255, 40 / 255, 0.5)
        border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.09)
        Row {
            id: fila
            anchors.centerIn: parent
            spacing: 6
            Image {
                anchors.verticalCenter: parent.verticalCenter
                source: "/usr/share/icons/breeze-dark/" + b.icono + ".svg"
                sourceSize.width: 18 * raiz.escala; sourceSize.height: 18 * raiz.escala
            }
            Text { visible: b.texto !== ""; anchors.verticalCenter: parent.verticalCenter; text: b.texto; color: raiz.t1; font.pixelSize: 13 * raiz.escala }
        }
        MouseArea { id: zona; anchors.fill: parent; hoverEnabled: true; onClicked: b.pulsado() }
        ToolTip.visible: zona.containsMouse && ayuda !== ""
        ToolTip.text: ayuda
    }

    Row {
        anchors { right: parent.right; bottom: parent.bottom; margins: 24 * raiz.escala }
        spacing: 4
        Boton {
            icono: "devices/22/input-keyboard-virtual"; ayuda: "Teclado en pantalla"
            onPulsado: { panelTeclado.activo = !panelTeclado.activo; clave.forceActiveFocus() }
        }
        Boton {
            visible: sessionModel.rowCount() > 1
            icono: "actions/22/view-list-details"
            texto: nombreSesion.text
            ayuda: "Cambiar el tipo de sesión"
            onPulsado: raiz.sesionActual = (raiz.sesionActual + 1) % sessionModel.rowCount()
            Text { id: nombreSesion; visible: false; text: "" }
            Repeater {
                model: sessionModel
                delegate: Item {
                    visible: false
                    Component.onCompleted: if (index === raiz.sesionActual) nombreSesion.text = model.name.replace("Plasma ", "").replace(/[()]/g, "")
                    Connections { target: raiz; function onSesionActualChanged() { if (index === raiz.sesionActual) nombreSesion.text = model.name.replace("Plasma ", "").replace(/[()]/g, "") } }
                }
            }
        }
        Boton { visible: sddm.canSuspend; icono: "actions/22/system-suspend"; ayuda: "Suspender"; onPulsado: sddm.suspend() }
        Boton { visible: sddm.canReboot; icono: "actions/22/system-reboot"; ayuda: "Reiniciar"; onPulsado: sddm.reboot() }
        Boton { visible: sddm.canPowerOff; icono: "actions/22/system-shutdown"; ayuda: "Apagar"; onPulsado: sddm.powerOff() }
    }

    // ---------- teclado en pantalla ----------
    InputPanel {
        id: panelTeclado
        property bool activo: false
        z: 10
        width: parent.width
        y: activo || Qt.inputMethod.visible ? parent.height - height : parent.height
        Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
    }

    Component.onCompleted: clave.forceActiveFocus()
}
