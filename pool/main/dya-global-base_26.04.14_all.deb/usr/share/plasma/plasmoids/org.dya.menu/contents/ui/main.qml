// Menú D&A: menú de inicio de D&A Desktop. Buscador arriba; programas fijados
// en cuadrícula, documentos recientes y carpetas; usuario, ajustes y apagar abajo.
// Usa los modelos de Kicker (los del menú de KDE): favoritos, todas las
// aplicaciones, documentos recientes y la búsqueda de KRunner.
import QtQuick
import QtQuick.Layouts
import QtCore
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami
import org.kde.coreaddons as KCoreAddons
import org.kde.plasma.private.kicker as Kicker

PlasmoidItem {
    id: kicker

    readonly property color t1: Kirigami.Theme.textColor
    readonly property color t2: Qt.alpha(Kirigami.Theme.textColor, 0.72)
    readonly property color t3: Qt.alpha(Kirigami.Theme.textColor, 0.55)
    readonly property color azul: "#2f7bff"
    readonly property color dorado: "#f2c14e"
    readonly property color relleno: Qt.alpha(Kirigami.Theme.textColor, 0.05)
    readonly property color relleno2: Qt.alpha(Kirigami.Theme.textColor, 0.09)
    readonly property color linea: Qt.alpha(Kirigami.Theme.textColor, 0.09)

    property bool verTodos: false
    property string consulta: ""
    signal abierto()

    preferredRepresentation: compactRepresentation
    switchWidth: 0; switchHeight: 0
    toolTipMainText: "Menú D&A"
    toolTipSubText: "Programas, archivos y búsqueda"

    onExpandedChanged: function () {
        if (expanded) {
            verTodos = false
            recientes.refresh()
            abierto()
        }
    }

    // ---------- datos ----------
    Kicker.RootModel {
        id: rootModel
        autoPopulate: false
        appletInterface: kicker
        flat: true
        sorted: true
        showSeparators: false
        showAllApps: true
        showRecentApps: false
        showRecentDocs: false
        showPowerSession: false
        Component.onCompleted: {
            favoritesModel.initForClient("org.dya.menu.favorites.instance-" + Plasmoid.id)
            if (!Plasmoid.configuration.favoritosIniciados) {
                favoritesModel.portOldFavorites(Plasmoid.configuration.favoritos)
                Plasmoid.configuration.favoritosIniciados = true
            }
            rootModel.refresh()
        }
    }
    readonly property var favoritos: rootModel.favoritesModel
    readonly property var todos: rootModel.count > 0 ? rootModel.modelForRow(0) : null

    Kicker.RecentUsageModel {
        id: recientes
        shownItems: Kicker.RecentUsageModel.OnlyDocs
        ordering: Kicker.RecentUsageModel.Recent
    }

    Kicker.RunnerModel {
        id: busqueda
        appletInterface: kicker
        favoritesModel: rootModel.favoritesModel
        mergeResults: true
        query: kicker.consulta
    }
    readonly property var resultados: busqueda.count > 0 ? busqueda.modelForRow(0) : null

    P5Support.DataSource {
        id: ejecutar
        engine: "executable"
        onNewData: (fuente) => disconnectSource(fuente)
        function orden(cmd) { connectSource(cmd); kicker.expanded = false }
    }

    KCoreAddons.KUser { id: usuario }

    function lanzar(modelo, fila) {
        if (!modelo) return
        modelo.trigger(fila, "", null)
        kicker.expanded = false
    }
    function abrirCarpeta(url) { Qt.openUrlExternally(url); kicker.expanded = false }

    // ---------- botón de la barra ----------
    compactRepresentation: MouseArea {
        id: boton
        hoverEnabled: true
        Layout.minimumWidth: height
        onClicked: kicker.expanded = !kicker.expanded
        Rectangle {
            anchors.fill: parent
            anchors.margins: 2
            radius: 10
            color: kicker.expanded ? kicker.relleno2 : (boton.containsMouse ? kicker.relleno : "transparent")
        }
        Image {
            anchors.centerIn: parent
            width: Math.min(parent.width, parent.height) * 0.78; height: width
            source: "file:///usr/share/dya-global/escritorio/inicio.png"
            smooth: true; mipmap: true
        }
    }

    // ---------- piezas ----------
    component Etiqueta: PC3.Label {
        color: kicker.t3; font.pixelSize: 12; font.weight: Font.DemiBold; font.letterSpacing: 1
        font.capitalization: Font.AllUppercase
    }

    component Celda: Rectangle {
        id: celda
        property string nombre
        property var icono
        signal pulsada()
        implicitWidth: 108; implicitHeight: 92
        radius: 12
        color: zona.containsMouse ? kicker.relleno2 : "transparent"
        ColumnLayout {
            anchors.centerIn: parent
            spacing: 8
            width: parent.width - 8
            Kirigami.Icon { Layout.alignment: Qt.AlignHCenter; source: celda.icono; implicitWidth: 38; implicitHeight: 38 }
            PC3.Label {
                Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter
                text: celda.nombre; elide: Text.ElideRight; wrapMode: Text.Wrap; maximumLineCount: 2
                color: kicker.t1; font.pixelSize: 12; lineHeight: 0.95
            }
        }
        MouseArea { id: zona; anchors.fill: parent; hoverEnabled: true; onClicked: celda.pulsada() }
    }

    component Fila: Rectangle {
        id: fila
        property string nombre
        property string detalle
        property var icono
        property int tamIcono: 28
        signal pulsada()
        Layout.fillWidth: true
        implicitHeight: detalle ? 50 : 42
        radius: 10
        color: zona2.containsMouse ? kicker.relleno2 : "transparent"
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10; anchors.rightMargin: 10
            spacing: 12
            Kirigami.Icon { source: fila.icono; implicitWidth: fila.tamIcono; implicitHeight: fila.tamIcono }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0
                PC3.Label { Layout.fillWidth: true; text: fila.nombre; elide: Text.ElideRight; color: kicker.t1; font.pixelSize: 14 }
                PC3.Label { Layout.fillWidth: true; visible: fila.detalle !== ""; text: fila.detalle; elide: Text.ElideRight; color: kicker.t3; font.pixelSize: 12 }
            }
        }
        MouseArea { id: zona2; anchors.fill: parent; hoverEnabled: true; onClicked: fila.pulsada() }
    }

    component BotonRedondo: Rectangle {
        property string icono
        property string ayuda
        signal pulsado()
        implicitWidth: 38; implicitHeight: 38; radius: 10
        color: zona3.containsMouse ? kicker.relleno2 : kicker.relleno
        Kirigami.Icon { anchors.centerIn: parent; source: icono; implicitWidth: 20; implicitHeight: 20 }
        MouseArea { id: zona3; anchors.fill: parent; hoverEnabled: true; onClicked: parent.pulsado() }
        PC3.ToolTip.text: ayuda
        PC3.ToolTip.visible: zona3.containsMouse && ayuda !== ""
    }

    // ---------- menú ----------
    fullRepresentation: Item {
        Layout.preferredWidth: 800
        Layout.preferredHeight: 590
        Layout.minimumWidth: 640
        Layout.minimumHeight: 520

        Keys.onEscapePressed: kicker.expanded = false
        Connections {
            target: kicker
            function onAbierto() { buscador.text = ""; buscador.forceActiveFocus() }
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 6
            spacing: 18

            // Buscador
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 46; radius: 12
                color: Qt.alpha(Kirigami.Theme.textColor, 0.066)
                border.width: 1
                border.color: buscador.activeFocus ? kicker.azul : Qt.alpha(Kirigami.Theme.textColor, 0.14)
                RowLayout {
                    anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 14; spacing: 10
                    Kirigami.Icon { source: "search"; implicitWidth: 18; implicitHeight: 18; color: kicker.t2 }
                    PC3.TextField {
                        id: buscador
                        Layout.fillWidth: true
                        placeholderText: "Busca programas, archivos o pregunta a la IA"
                        background: null
                        font.pixelSize: 15
                        onTextChanged: kicker.consulta = text
                        Keys.onReturnPressed: {
                            if (kicker.resultados && kicker.resultados.count > 0) kicker.lanzar(kicker.resultados, 0)
                            else if (text) ejecutar.orden("dya-asistente " + JSON.stringify(text))
                        }
                    }
                }
            }

            // Resultados de búsqueda
            ListView {
                visible: buscador.text !== ""
                Layout.fillWidth: true; Layout.fillHeight: true
                clip: true; spacing: 2
                model: kicker.resultados
                delegate: Fila {
                    width: ListView.view.width
                    nombre: model.display || ""
                    detalle: model.description || ""
                    icono: model.decoration
                    onPulsada: kicker.lanzar(kicker.resultados, index)
                }
                footer: Fila {
                    width: ListView.view.width
                    visible: buscador.text !== ""
                    nombre: "Preguntar a la IA: «" + buscador.text + "»"
                    icono: "dya-global"
                    onPulsada: ejecutar.orden("dya-asistente " + JSON.stringify(buscador.text))
                }
            }

            // Inicio: fijados + recientes | lugares
            RowLayout {
                visible: buscador.text === ""
                Layout.fillWidth: true; Layout.fillHeight: true
                spacing: 20

                ColumnLayout {
                    Layout.fillWidth: true; Layout.fillHeight: true
                    spacing: 10

                    RowLayout {
                        Layout.fillWidth: true
                        Etiqueta { text: kicker.verTodos ? "Todos los programas" : "Fijados" }
                        Item { Layout.fillWidth: true }
                        Rectangle {
                            implicitWidth: textoTodos.implicitWidth + 24; implicitHeight: 26; radius: 8
                            color: zonaTodos.containsMouse ? kicker.relleno2 : kicker.relleno
                            PC3.Label { id: textoTodos; anchors.centerIn: parent; text: kicker.verTodos ? "‹  Volver" : "Todos los programas  ›"; color: kicker.t2; font.pixelSize: 13 }
                            MouseArea { id: zonaTodos; anchors.fill: parent; hoverEnabled: true; onClicked: kicker.verTodos = !kicker.verTodos }
                        }
                    }

                    GridView {
                        visible: !kicker.verTodos
                        Layout.fillWidth: true
                        Layout.preferredHeight: cellHeight * 2
                        interactive: false
                        clip: true
                        cellWidth: Math.floor(width / 5); cellHeight: 100
                        model: kicker.favoritos
                        delegate: Item {
                            width: GridView.view.cellWidth; height: GridView.view.cellHeight
                            Celda {
                                anchors.centerIn: parent
                                width: parent.width - 4; height: parent.height - 4
                                nombre: model.display || ""
                                icono: model.decoration
                                onPulsada: kicker.lanzar(kicker.favoritos, index)
                            }
                        }
                    }

                    Etiqueta { visible: !kicker.verTodos; text: "Recientes"; Layout.topMargin: 8 }
                    Repeater {
                        model: kicker.verTodos ? 0 : recientes
                        delegate: Fila {
                            visible: index < 3
                            nombre: model.display || ""
                            detalle: "Abierto recientemente"
                            icono: model.decoration
                            onPulsada: kicker.lanzar(recientes, index)
                        }
                    }
                    PC3.Label {
                        visible: !kicker.verTodos && recientes.count === 0
                        text: "Aquí aparecerán los últimos archivos que abras."
                        color: kicker.t3; font.pixelSize: 13; Layout.leftMargin: 10
                    }
                    Item { visible: !kicker.verTodos; Layout.fillHeight: true }

                    ListView {
                        visible: kicker.verTodos
                        Layout.fillWidth: true; Layout.fillHeight: true
                        clip: true; spacing: 1
                        model: kicker.verTodos ? kicker.todos : null
                        delegate: Fila {
                            width: ListView.view.width
                            nombre: model.display || ""
                            icono: model.decoration
                            tamIcono: 24
                            onPulsada: kicker.lanzar(kicker.todos, index)
                        }
                        PC3.ScrollBar.vertical: PC3.ScrollBar {}
                    }
                }

                Rectangle { Layout.fillHeight: true; implicitWidth: 1; color: kicker.linea }

                ColumnLayout {
                    Layout.preferredWidth: 190; Layout.fillHeight: true
                    spacing: 2
                    Etiqueta { text: "Lugares"; Layout.leftMargin: 10; Layout.bottomMargin: 8 }
                    Fila { nombre: "Documentos"; icono: "folder-documents"; tamIcono: 24; onPulsada: kicker.abrirCarpeta(StandardPaths.writableLocation(StandardPaths.DocumentsLocation)) }
                    Fila { nombre: "Descargas"; icono: "folder-download"; tamIcono: 24; onPulsada: kicker.abrirCarpeta(StandardPaths.writableLocation(StandardPaths.DownloadLocation)) }
                    Fila { nombre: "Imágenes"; icono: "folder-pictures"; tamIcono: 24; onPulsada: kicker.abrirCarpeta(StandardPaths.writableLocation(StandardPaths.PicturesLocation)) }
                    Fila { nombre: "Música"; icono: "folder-music"; tamIcono: 24; onPulsada: kicker.abrirCarpeta(StandardPaths.writableLocation(StandardPaths.MusicLocation)) }
                    Fila { nombre: "Vídeos"; icono: "folder-videos"; tamIcono: 24; onPulsada: kicker.abrirCarpeta(StandardPaths.writableLocation(StandardPaths.MoviesLocation)) }
                    Fila { nombre: "Equipo"; icono: "computer"; tamIcono: 24; onPulsada: kicker.abrirCarpeta("file:///") }
                    Fila { nombre: "Papelera"; icono: "user-trash"; tamIcono: 24; onPulsada: kicker.abrirCarpeta("trash:/") }
                    Item { Layout.fillHeight: true }
                }
            }

            // Pie: usuario, ajustes y apagar
            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: kicker.linea }
            RowLayout {
                Layout.fillWidth: true
                spacing: 12
                Rectangle {
                    implicitWidth: 38; implicitHeight: 38; radius: 19
                    border.width: 2; border.color: kicker.dorado
                    gradient: Gradient {
                        GradientStop { position: 0; color: "#3b86ff" }
                        GradientStop { position: 1; color: "#173a8a" }
                    }
                    clip: true
                    PC3.Label {
                        anchors.centerIn: parent
                        visible: !foto.visible
                        text: (usuario.fullName || usuario.loginName).charAt(0).toUpperCase()
                        color: "white"; font.weight: Font.DemiBold
                    }
                    Image {
                        id: foto
                        anchors.fill: parent; anchors.margins: 2
                        source: usuario.faceIconUrl
                        visible: status === Image.Ready
                        fillMode: Image.PreserveAspectCrop
                    }
                }
                ColumnLayout {
                    spacing: 0
                    PC3.Label { text: usuario.fullName || usuario.loginName; color: kicker.t1; font.pixelSize: 14 }
                    PC3.Label { text: usuario.loginName; color: kicker.t3; font.pixelSize: 12 }
                }
                Item { Layout.fillWidth: true }
                BotonRedondo { icono: "configure"; ayuda: "Configuración"; onPulsado: ejecutar.orden("systemsettings") }
                BotonRedondo { icono: "system-lock-screen"; ayuda: "Bloquear"; onPulsado: ejecutar.orden("loginctl lock-session") }
                BotonRedondo { icono: "system-shutdown"; ayuda: "Apagar o reiniciar"; onPulsado: ejecutar.orden("qdbus6 org.kde.LogoutPrompt /LogoutPrompt promptAll") }
            }
        }
    }
}
