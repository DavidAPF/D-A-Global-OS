/*
    Pantalla de bloqueo de D&A Global OS (sustituye a la de Plasma; el original
    queda en LockScreen.qml.ubuntu por dpkg-divert). Mismo diseño que el inicio
    de sesión (tema SDDM «dya»): fondo desenfocado, hora grande, foto con aro
    dorado, contraseña en cristal y botones abajo a la derecha.
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Effects
import QtQuick.VirtualKeyboard
import org.kde.plasma.private.keyboardindicator as KeyboardIndicator
import org.kde.plasma.private.sessions

Item {
    id: root
    property bool debug: false
    property string notification
    signal clearPassword()
    signal notificationRepeated()

    // Propiedades y señales que kscreenlocker busca
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false
    signal suspendToDisk()
    signal suspendToRam()

    implicitWidth: 800
    implicitHeight: 600

    readonly property color t1: "#eef3fb"
    readonly property color t2: "#a9b7cc"
    readonly property color azul: "#2f7bff"
    readonly property color dorado: "#f2c14e"
    readonly property real escala: Math.max(0.6, Math.min(width / 1920, height / 1080))
    property date ahora: new Date()
    property bool esperando: false
    property bool sinClave: false   // la cuenta se desbloquea sin contraseña
    property bool comprobando: false  // contraseña enviada, esperando respuesta
    property bool enReposo: true      // sin tocar desde hace un rato (como Plasma)

    // Como hace Plasma: la autenticación se (re)inicia cada vez que el usuario
    // vuelve a tocar la pantalla o el teclado tras un rato sin hacerlo. Así, si
    // el sistema de contraseñas se quedó esperando (p. ej. a un lector de
    // huellas que no responde), al volver se empieza de nuevo.
    function despertar() {
        reposo.restart()
        if (!enReposo || comprobando || esperando) return
        enReposo = false
        authenticator.startAuthenticating()
    }
    Timer { id: reposo; interval: 10000; running: true; onTriggered: root.enReposo = true }

    // Si tras pulsar Intro no hay respuesta en 30 s, se reinicia y se vuelve a
    // enviar. (Con un lector de huellas que falla, el sistema de contraseñas
    // tarda unos 25 s en descartarlo: no hay que cortarlo antes.)
    Timer {
        id: vigilante
        interval: 30000
        property int reintentos: 0
        onTriggered: {
            if (!root.comprobando) return
            if (reintentos < 1) {
                reintentos++
                root.notification = "Comprobando la contraseña…"
                authenticator.startAuthenticating()
                reenviar.restart()
            } else {
                root.comprobando = false
                root.notification = "El sistema no responde. Espera unos segundos y pulsa Intro otra vez."
            }
        }
    }
    Timer {
        id: reenviar
        interval: 600
        onTriggered: { authenticator.respond(clave.text); vigilante.restart() }
    }
    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
        z: -1
        onPositionChanged: root.despertar()
    }
    Keys.onPressed: (e) => { root.despertar(); e.accepted = false }

    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.ahora = new Date() }

    onClearPassword: clave.text = ""

    Connections {
        target: authenticator
        function onFailed(kind) {
            if (kind != 0) return   // huella o tarjeta: no es la contraseña
            root.comprobando = false
            root.notification = "Contraseña incorrecta. Inténtalo de nuevo."
            root.esperando = true
            espera.restart()
            sacudida.start()
        }
        function onSucceeded() {
            root.comprobando = false
            // Con contraseña ya escrita se sale; si se desbloqueó sin pedirla
            // (cuenta sin contraseña), se muestra un botón «Desbloquear» como hace Plasma
            if (authenticator.hadPrompt) Qt.quit()
            else root.sinClave = true
        }
        function onInfoMessageChanged() { if (authenticator.infoMessage) root.notification = authenticator.infoMessage }
        function onErrorMessageChanged() { if (authenticator.errorMessage) root.notification = authenticator.errorMessage }
        function onPromptForSecretChanged() { clave.forceActiveFocus() }
    }
    // Tras un fallo, 3 segundos de espera antes de volver a intentar (como Plasma)
    Timer {
        id: espera
        interval: 3000
        onTriggered: { root.esperando = false; clave.text = ""; clave.forceActiveFocus(); authenticator.startAuthenticating() }
    }

    SessionManagement { id: sesion }
    Connections { target: sesion; function onAboutToSuspend() { clave.text = "" } }
    KeyboardIndicator.KeyState { id: mayusculas; key: Qt.Key_CapsLock }

    // ---------- fondo ----------
    Image {
        id: fondo
        anchors.fill: parent
        source: "/usr/share/backgrounds/dya-global/fondo.png"
        fillMode: Image.PreserveAspectCrop
        visible: false
    }
    MultiEffect {
        anchors.fill: parent
        source: fondo
        autoPaddingEnabled: false
        blurEnabled: true
        blurMax: 64
        blur: 1.0
        blurMultiplier: 1.3
        brightness: -0.28
        saturation: 0.25
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: Qt.rgba(1 / 255, 4 / 255, 13 / 255, 0.35) }
            GradientStop { position: 0.55; color: Qt.rgba(5 / 255, 14 / 255, 36 / 255, 0.05) }
            GradientStop { position: 1; color: Qt.rgba(1 / 255, 4 / 255, 13 / 255, 0.55) }
        }
    }

    // ---------- hora ----------
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: 150 * root.escala
        spacing: 4
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatTime(root.ahora, "HH:mm")
            color: root.t1; font.pixelSize: 112 * root.escala; font.weight: Font.ExtraLight; font.letterSpacing: -2
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.locale().toString(root.ahora, "dddd, d 'de' MMMM")
            color: root.t2; font.pixelSize: 20 * root.escala
        }
    }

    // ---------- acceso ----------
    ColumnLayout {
        anchors.horizontalCenter: parent.horizontalCenter
        y: 470 * root.escala
        width: 340 * root.escala
        spacing: 0

        Item {
            Layout.alignment: Qt.AlignHCenter
            implicitWidth: 102 * root.escala; implicitHeight: implicitWidth
            Rectangle { anchors.fill: parent; radius: width / 2; color: "transparent"; border.width: 3; border.color: root.dorado }
            Rectangle {
                id: circulo
                anchors.fill: parent; anchors.margins: 3; radius: width / 2
                gradient: Gradient {
                    GradientStop { position: 0; color: "#3b86ff" }
                    GradientStop { position: 1; color: "#173a8a" }
                }
                Text {
                    anchors.centerIn: parent
                    visible: foto.status !== Image.Ready
                    text: kscreenlocker_userName.charAt(0).toUpperCase()
                    color: "white"; font.pixelSize: parent.height * 0.42; font.weight: Font.DemiBold
                }
            }
            Image {
                id: foto
                anchors.fill: circulo
                source: kscreenlocker_userImage !== "" ? "file://" + kscreenlocker_userImage.split("/").map(encodeURIComponent).join("/") : ""
                fillMode: Image.PreserveAspectCrop
                visible: false
            }
            MultiEffect {
                anchors.fill: circulo
                source: foto
                visible: foto.status === Image.Ready
                maskEnabled: true
                maskSource: mascara
            }
            Item {
                id: mascara
                anchors.fill: circulo; visible: false; layer.enabled: true
                Rectangle { anchors.fill: parent; radius: width / 2; color: "black" }
            }
        }

        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 16 * root.escala
            text: kscreenlocker_userName
            color: root.t1; font.pixelSize: 22 * root.escala; font.weight: Font.Medium
        }

        Rectangle {
            visible: root.sinClave
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 20 * root.escala
            implicitWidth: 180 * root.escala; implicitHeight: 44 * root.escala
            radius: 12 * root.escala
            color: zonaSinClave.containsMouse ? "#4a8dff" : root.azul
            Text { anchors.centerIn: parent; text: "Desbloquear"; color: "white"; font.pixelSize: 15 * root.escala; font.weight: Font.Medium }
            MouseArea { id: zonaSinClave; anchors.fill: parent; hoverEnabled: true; onClicked: Qt.quit() }
        }

        Rectangle {
            id: campo
            visible: !root.sinClave
            Layout.fillWidth: true
            Layout.topMargin: 20 * root.escala
            implicitHeight: 46 * root.escala
            radius: 12 * root.escala
            color: Qt.rgba(10 / 255, 20 / 255, 40 / 255, 0.58)
            border.width: 1
            border.color: clave.activeFocus ? root.azul : Qt.rgba(1, 1, 1, 0.16)
            opacity: root.esperando ? 0.6 : 1
            Rectangle {
                anchors.fill: parent; anchors.margins: -3; radius: parent.radius + 3
                color: "transparent"; border.width: 3; border.color: Qt.rgba(47 / 255, 123 / 255, 1, 0.25)
                visible: clave.activeFocus
            }
            TextField {
                id: clave
                anchors { left: parent.left; right: entrar.left; verticalCenter: parent.verticalCenter; leftMargin: 14 * root.escala; rightMargin: 6 }
                enabled: !root.esperando
                echoMode: TextInput.Password
                passwordCharacter: "●"
                placeholderText: "Contraseña"
                placeholderTextColor: root.t2
                color: root.t1
                font.pixelSize: 15 * root.escala
                background: null
                focus: true
                Keys.onReturnPressed: root.desbloquear()
                onTextEdited: root.despertar()
                Keys.onEnterPressed: root.desbloquear()
                Keys.onEscapePressed: text = ""
            }
            Rectangle {
                id: entrar
                anchors { right: parent.right; verticalCenter: parent.verticalCenter; rightMargin: 6 * root.escala }
                width: 34 * root.escala; height: width; radius: 9 * root.escala
                color: zonaEntrar.containsMouse ? "#4a8dff" : root.azul
                Canvas {
                    anchors.centerIn: parent; width: 16; height: 16
                    onPaint: {
                        const c = getContext("2d"); c.strokeStyle = "white"; c.lineWidth = 2; c.lineCap = "round"; c.lineJoin = "round"
                        c.beginPath(); c.moveTo(2, 8); c.lineTo(14, 8); c.moveTo(9, 3); c.lineTo(14, 8); c.lineTo(9, 13); c.stroke()
                    }
                }
                MouseArea { id: zonaEntrar; anchors.fill: parent; hoverEnabled: true; onClicked: root.desbloquear() }
            }
            SequentialAnimation {
                id: sacudida
                NumberAnimation { target: campo; property: "Layout.leftMargin"; to: -20; duration: 50 }
                NumberAnimation { target: campo; property: "Layout.leftMargin"; to: 20; duration: 50 }
                NumberAnimation { target: campo; property: "Layout.leftMargin"; to: 0; duration: 50 }
            }
        }

        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 16 * root.escala
            text: root.notification !== "" ? root.notification
                : root.comprobando ? "Comprobando… puede tardar unos segundos si el lector de huellas no responde"
                : (root.sinClave ? "Pulsa «Desbloquear» para continuar" : (mayusculas.locked ? "Mayúsculas activadas" : "Sesión bloqueada · escribe tu contraseña"))
            color: root.notification !== "" || mayusculas.locked ? root.dorado : root.t2
            font.pixelSize: 13 * root.escala
        }
    }

    function desbloquear() {
        if (root.esperando || clave.text === "") return
        root.notification = ""
        root.comprobando = true
        vigilante.reintentos = 0
        vigilante.restart()
        authenticator.respond(clave.text)
    }

    // ---------- botones ----------
    component Boton: Rectangle {
        id: b
        property string icono
        property string ayuda
        signal pulsado()
        height: 40 * root.escala; width: height
        radius: 12 * root.escala
        color: zona.containsMouse ? Qt.rgba(30 / 255, 50 / 255, 90 / 255, 0.7) : Qt.rgba(10 / 255, 20 / 255, 40 / 255, 0.5)
        border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.09)
        Image {
            anchors.centerIn: parent
            source: "/usr/share/icons/breeze-dark/" + b.icono + ".svg"
            sourceSize.width: 18 * root.escala; sourceSize.height: 18 * root.escala
        }
        MouseArea { id: zona; anchors.fill: parent; hoverEnabled: true; onClicked: b.pulsado() }
        ToolTip.visible: zona.containsMouse
        ToolTip.text: ayuda
    }
    Row {
        anchors { right: parent.right; bottom: parent.bottom; margins: 24 * root.escala }
        spacing: 4
        Boton { icono: "devices/22/input-keyboard-virtual"; ayuda: "Teclado en pantalla"; onPulsado: { teclado.activo = !teclado.activo; clave.forceActiveFocus() } }
        Boton { visible: sesion.canSwitchUser; icono: "actions/22/system-switch-user"; ayuda: "Cambiar de usuario"; onPulsado: sesion.switchUser() }
        Boton { visible: root.suspendToRamSupported; icono: "actions/22/system-suspend"; ayuda: "Suspender"; onPulsado: root.suspendToRam() }
    }

    InputPanel {
        id: teclado
        property bool activo: false
        z: 10
        width: parent.width
        y: activo || Qt.inputMethod.visible ? parent.height - height : parent.height
        Behavior on y { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
    }

    Component.onCompleted: {
        root.enReposo = false
        authenticator.startAuthenticating()
        clave.forceActiveFocus()
    }
}
