"""Servidor local del asistente gráfico de D&A Global OS.

La ventana (usr/share/dya-global/asistente/Asistente.qml) le habla por HTTP en
127.0.0.1 con una clave aleatoria que solo conoce la ventana; aquí se reutiliza
el motor del asistente de terminal (/usr/local/bin/ia): la IA propone, los
documentos se crean al momento y los comandos esperan a que el usuario pulse
«Ejecutar». Las órdenes con sudo se ejecutan con pkexec (pide la contraseña en
una ventana).

Rutas (POST con JSON, cabecera X-Clave):
    /info                      -> modo de la IA (local o en línea)
    /preguntar {texto}         -> respuesta, documento creado, comandos propuestos
    /ejecutar  {id}            -> resultado; si falla, la IA propone el arreglo
    /cancelar  {id}
    /nuevo                     -> empieza la conversación de cero
"""
import importlib.machinery
import importlib.util
import json
import os
import re
import shlex
import subprocess
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

_cargador = importlib.machinery.SourceFileLoader("ia", "/usr/local/bin/ia")
_spec = importlib.util.spec_from_loader("ia", _cargador)
ia = importlib.util.module_from_spec(_spec)
_cargador.exec_module(ia)
n = ia.n
h = ia.h

CLAVE = uuid.uuid4().hex
candado = threading.Lock()
estado = {"historial": None, "base": 0, "pendientes": {}, "peticiones": {}}


def preparar():
    n.arrancar_servidor()
    historial = ia.prefijo()
    estado["base"] = n.PREFIJO = len(historial)
    estado["historial"] = historial


def con_pkexec(comando):
    """Las órdenes con sudo se ejecutan enteras como administrador con pkexec."""
    if not re.search(r"\bsudo\b", comando):
        return comando
    sin_sudo = re.sub(r"\bsudo\s+(-\S+\s+)*", "", comando)
    return "pkexec env DEBIAN_FRONTEND=noninteractive bash -c " + shlex.quote(sin_sudo)


def plan_a_respuesta(plan, peticion):
    if plan is None:
        return {"respuesta": "No he podido responder. Inténtalo de nuevo o dilo de otra forma."}
    respuesta, comandos, apps, herr = plan
    salida = {"respuesta": respuesta}
    if herr:
        args = {k: v for k, v in herr.items() if k != "nombre"}
        ok, msg = h.ejecutar(herr.get("nombre"), args)
        ruta = msg.rsplit(": ", 1)[-1] if ok and ": /" in msg else ""
        tam = ""
        if ruta and os.path.exists(ruta):
            b = os.path.getsize(ruta)
            tam = f"{b / 1048576:.1f} MB".replace(".", ",") if b >= 1048576 else f"{max(1, b // 1024)} KB"
        salida["archivo"] = {"ok": ok, "mensaje": msg, "ruta": ruta, "nombre": os.path.basename(ruta),
                             "carpeta": os.path.basename(os.path.dirname(ruta)), "tam": tam}
    if comandos:
        ident = uuid.uuid4().hex[:12]
        estado["pendientes"][ident] = {"comandos": comandos, "apps": apps, "peticion": peticion, "intentos": 0}
        salida["comandos"] = comandos
        salida["peligroso"] = any(n.es_peligroso(c) for c in comandos)
        salida["id"] = ident
    elif apps:
        n.abrir(apps)
        salida["abiertas"] = apps
    return salida


def preguntar(texto):
    historial = estado["historial"]
    dominio, _ = n.clasificar(texto)
    modelo = n.MODELO_CODIGO if dominio == "codigo" else n.MODELO_SISTEMA
    plan = ia.proponer(historial, texto, modelo)
    return plan_a_respuesta(plan, texto)


def ejecutar(ident):
    p = estado["pendientes"].pop(ident, None)
    if not p:
        return {"ok": False, "salida": "Esa propuesta ya no está disponible."}
    bien, resultado = n.ejecutar([con_pkexec(c) for c in p["comandos"]])
    historial = estado["historial"]
    cola = resultado[-1500:]
    if bien:
        historial.append({"role": "user", "content": "[Resultado de los comandos]\n" + resultado[-3000:]})
        if p["apps"]:
            n.abrir(p["apps"])
        return {"ok": True, "salida": cola}
    # Como en la terminal: la IA ve el error y propone cómo arreglarlo (2 veces como mucho)
    if p["intentos"] >= 2:
        historial.append({"role": "user", "content": "[Resultado]\n" + resultado[-3000:]})
        return {"ok": False, "salida": cola, "respuesta": "No he conseguido arreglarlo. Cuéntame más o prueba otra cosa."}
    arreglo = ia.proponer(historial, "[El comando falló. Resultado:]\n" + resultado[-3000:]
                          + "\nCorrígelo con nuevos comandos para cumplir lo que pedí.")
    siguiente = plan_a_respuesta(arreglo, p["peticion"])
    if "id" in siguiente:
        estado["pendientes"][siguiente["id"]]["intentos"] = p["intentos"] + 1
    siguiente.update({"ok": False, "salida": cola})
    return siguiente


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def responder(self, datos, codigo=200):
        cuerpo = json.dumps(datos, ensure_ascii=False).encode()
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_POST(self):
        if self.headers.get("X-Clave") != CLAVE:
            return self.responder({"error": "no autorizado"}, 403)
        largo = int(self.headers.get("Content-Length") or 0)
        try:
            datos = json.loads(self.rfile.read(largo) or b"{}")
        except ValueError:
            datos = {}
        try:
            with candado:
                if estado["historial"] is None:
                    preparar()
                if self.path == "/info":
                    return self.responder({"nube": n.nube_disponible(), "modelo_local": n._modelo_local()})
                if self.path == "/preguntar":
                    return self.responder(preguntar(str(datos.get("texto", "")).strip()))
                if self.path == "/ejecutar":
                    return self.responder(ejecutar(str(datos.get("id", ""))))
                if self.path == "/cancelar":
                    estado["pendientes"].pop(str(datos.get("id", "")), None)
                    estado["historial"].append({"role": "user", "content": "[No quise ejecutar esos comandos]"})
                    return self.responder({"ok": True})
                if self.path == "/nuevo":
                    estado["historial"] = estado["historial"][:estado["base"]]
                    estado["pendientes"].clear()
                    return self.responder({"ok": True})
        except Exception as e:   # que la ventana vea el error en vez de colgarse
            return self.responder({"respuesta": f"Ha ocurrido un error: {e}"})
        self.responder({"error": "ruta desconocida"}, 404)


def iniciar():
    """Arranca en un puerto libre de 127.0.0.1 y devuelve (puerto, clave)."""
    servidor = ThreadingHTTPServer(("127.0.0.1", 0), Manejador)
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    return servidor.server_address[1], CLAVE
