// Asistente de D&A Global OS (ventana). Habla con asistente_servidor.py por
// HTTP en 127.0.0.1; el puerto y la clave llegan como argumentos.
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import org.kde.kirigami as Kirigami

Window {
    id: ventana
    width: 820; height: 720
    minimumWidth: 560; minimumHeight: 460
    visible: true
    title: "Asistente de D&A Global OS"
    color: "transparent"
    flags: Qt.Window | Qt.FramelessWindowHint

    readonly property color t1: Kirigami.Theme.textColor
    readonly property color t2: Qt.alpha(Kirigami.Theme.textColor, 0.72)
    readonly property color t3: Qt.alpha(Kirigami.Theme.textColor, 0.55)
    readonly property color azul: "#2f7bff"
    readonly property color verde: "#5ad13b"
    readonly property color dorado: "#f2c14e"
    readonly property color linea: Qt.alpha(Kirigami.Theme.textColor, 0.09)

    readonly property var args: Qt.application.arguments
    readonly property int ia: args.indexOf("--")
    readonly property string puerto: ia >= 0 ? args[ia + 1] : ""
    readonly property string clave: ia >= 0 ? args[ia + 2] : ""
    readonly property string primeraPregunta: ia >= 0 && args.length > ia + 3 ? args.slice(ia + 3).join(" ") : ""

    property bool pensando: false
    property bool nube: false

    function llamar(ruta, datos, hecho) {
        const x = new XMLHttpRequest()
        x.onreadystatechange = function () {
            if (x.readyState !== XMLHttpRequest.DONE) return
            let r = {}
            try { r = JSON.parse(x.responseText) } catch (e) { r = { respuesta: "No puedo hablar con la IA ahora mismo." } }
            hecho(r)
        }
        x.open("POST", "http://127.0.0.1:" + puerto + ruta)
        x.setRequestHeader("Content-Type", "application/json")
        x.setRequestHeader("X-Clave", clave)
        x.send(JSON.stringify(datos || {}))
    }

    function anadirRespuesta(r) {
        mensajes.append({
            yo: false, texto: r.respuesta || "",
            archivo: r.archivo && r.archivo.ok ? r.archivo.nombre : "",
            ruta: r.archivo && r.archivo.ok ? r.archivo.ruta : "",
            detalle: r.archivo && r.archivo.ok ? (r.archivo.carpeta + " · " + r.archivo.tam) : "",
            comandos: (r.comandos || []).join("\n"),
            ident: r.id || "", peligroso: r.peligroso === true,
            estado: r.comandos ? "pendiente" : "", salida: ""
        })
        lista.positionViewAtEnd()
    }

    function enviar(texto) {
        texto = texto.trim()
        if (!texto || pensando) return
        mensajes.append({ yo: true, texto: texto, archivo: "", ruta: "", detalle: "", comandos: "", ident: "", peligroso: false, estado: "", salida: "" })
        campo.text = ""
        pensando = true
        lista.positionViewAtEnd()
        llamar("/preguntar", { texto: texto }, function (r) { pensando = false; anadirRespuesta(r) })
    }

    function ejecutar(fila) {
        const m = mensajes.get(fila)
        mensajes.setProperty(fila, "estado", "ejecutando")
        pensando = true
        llamar("/ejecutar", { id: m.ident }, function (r) {
            pensando = false
            mensajes.setProperty(fila, "estado", r.ok ? "hecho" : "fallo")
            mensajes.setProperty(fila, "salida", r.ok ? "" : (r.salida || "").split("\n").slice(-4).join("\n"))
            if (!r.ok && (r.respuesta || r.comandos)) anadirRespuesta(r)
        })
    }

    function cancelar(fila) {
        mensajes.setProperty(fila, "estado", "cancelado")
        llamar("/cancelar", { id: mensajes.get(fila).ident }, function () {})
    }

    Component.onCompleted: {
        llamar("/info", {}, function (r) { nube = r.nube === true })
        if (primeraPregunta) enviar(primeraPregunta)
        campo.forceActiveFocus()
    }

    ListModel { id: mensajes }

    Shortcut { sequence: "Escape"; onActivated: Qt.quit() }

    // ---------- tarjeta de cristal ----------
    Rectangle {
        anchors.fill: parent
        anchors.margins: 12
        radius: 20
        border.width: 1
        border.color: Qt.alpha(Kirigami.Theme.textColor, 0.14)
        // Cristal azul marino en modo oscuro; claro y azulado en modo claro
        id: tarjeta
        readonly property bool oscuro: Kirigami.ColorUtils.brightnessForColor(Kirigami.Theme.backgroundColor) === Kirigami.ColorUtils.Dark
        gradient: Gradient {
            GradientStop { position: 0; color: tarjeta.oscuro ? Qt.rgba(28 / 255, 48 / 255, 92 / 255, 0.98) : Qt.rgba(250 / 255, 252 / 255, 1, 0.98) }
            GradientStop { position: 1; color: tarjeta.oscuro ? Qt.rgba(10 / 255, 20 / 255, 44 / 255, 0.99) : Qt.rgba(232 / 255, 239 / 255, 250 / 255, 0.99) }
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 22
            spacing: 0

            // Cabecera (arrastrable)
            Item {
                Layout.fillWidth: true
                implicitHeight: 60
                DragHandler { target: null; onActiveChanged: if (active) ventana.startSystemMove() }
                RowLayout {
                    anchors.fill: parent
                    spacing: 14
                    Rectangle {
                        implicitWidth: 42; implicitHeight: 42; radius: 10
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0; color: ventana.verde }
                            GradientStop { position: 1; color: ventana.azul }
                        }
                        Text { anchors.centerIn: parent; text: "✦"; color: "white"; font.pixelSize: 22 }
                    }
                    ColumnLayout {
                        spacing: 1
                        Text { text: "Asistente de D&A Global OS"; color: ventana.t1; font.pixelSize: 16; font.weight: Font.DemiBold }
                        RowLayout {
                            spacing: 6
                            Rectangle { implicitWidth: 7; implicitHeight: 7; radius: 3.5; color: ventana.verde }
                            Text { text: ventana.nube ? "IA en línea" : "Funciona sin internet"; color: ventana.t2; font.pixelSize: 13 }
                        }
                    }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        implicitWidth: 34; implicitHeight: 34; radius: 10
                        color: zonaNuevo.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.08) : "transparent"
                        visible: mensajes.count > 0
                        Text { anchors.centerIn: parent; text: "↺"; color: ventana.t2; font.pixelSize: 18 }
                        MouseArea { id: zonaNuevo; anchors.fill: parent; hoverEnabled: true; onClicked: { mensajes.clear(); ventana.llamar("/nuevo", {}, function () {}) } }
                        ToolTip.visible: zonaNuevo.containsMouse; ToolTip.text: "Conversación nueva"
                    }
                    Rectangle {
                        implicitWidth: 34; implicitHeight: 34; radius: 10
                        color: zonaCerrar.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.08) : "transparent"
                        Text { anchors.centerIn: parent; text: "✕"; color: ventana.t2; font.pixelSize: 16 }
                        MouseArea { id: zonaCerrar; anchors.fill: parent; hoverEnabled: true; onClicked: Qt.quit() }
                    }
                }
            }
            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: ventana.linea }

            // Conversación
            ListView {
                id: lista
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.topMargin: 18
                Layout.bottomMargin: 14
                clip: true
                spacing: 14
                model: mensajes
                ScrollBar.vertical: ScrollBar {}

                header: Item {
                    width: lista.width
                    height: mensajes.count === 0 ? lista.height - 20 : 0
                    visible: mensajes.count === 0
                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 8
                        Text { Layout.alignment: Qt.AlignHCenter; text: "¿En qué te ayudo?"; color: ventana.t1; font.pixelSize: 24; font.weight: Font.Light }
                        Text { Layout.alignment: Qt.AlignHCenter; text: "Instalo programas, creo documentos, reviso tu equipo y respondo preguntas."; color: ventana.t2; font.pixelSize: 14 }
                    }
                }

                delegate: Item {
                    id: fila
                    width: lista.width
                    height: burbuja.height
                    required property int index
                    required property bool yo
                    required property string texto
                    required property string archivo
                    required property string ruta
                    required property string detalle
                    required property string comandos
                    required property bool peligroso
                    required property string estado
                    required property string salida

                    Rectangle {
                        id: burbuja
                        anchors.right: fila.yo ? parent.right : undefined
                        anchors.left: fila.yo ? undefined : parent.left
                        width: Math.min(fila.width * 0.8, contenido.implicitWidth + 32)
                        height: contenido.implicitHeight + 24
                        radius: 16
                        color: fila.yo ? ventana.azul : Qt.alpha(Kirigami.Theme.textColor, 0.06)
                        border.width: fila.yo ? 0 : 1
                        border.color: ventana.linea
                        // esquina «de bocadillo»
                        Rectangle {
                            width: 16; height: 16; color: parent.color
                            anchors.bottom: parent.bottom
                            anchors.right: fila.yo ? parent.right : undefined
                            anchors.left: fila.yo ? undefined : parent.left
                            radius: 5
                            visible: true
                            z: -1
                        }

                        ColumnLayout {
                            id: contenido
                            x: 16; y: 12
                            width: Math.min(fila.width * 0.8 - 32, implicitWidth)
                            spacing: 10

                            Text {
                                Layout.fillWidth: true
                                Layout.maximumWidth: fila.width * 0.8 - 32
                                text: fila.texto
                                visible: fila.texto !== ""
                                color: ventana.t1; font.pixelSize: 15; lineHeight: 1.2
                                wrapMode: Text.Wrap
                                textFormat: Text.MarkdownText
                            }

                            // Documento creado
                            Rectangle {
                                visible: fila.archivo !== ""
                                Layout.fillWidth: true
                                Layout.minimumWidth: 420
                                implicitHeight: 60; radius: 12
                                color: Qt.alpha(Kirigami.Theme.textColor, 0.06); border.width: 1; border.color: ventana.linea
                                RowLayout {
                                    anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 10
                                    spacing: 12
                                    Image {
                                        source: fila.archivo.endsWith(".pptx") ? "file:///usr/share/icons/hicolor/128x128/apps/libreoffice-impress.png"
                                              : fila.archivo.endsWith(".xlsx") ? "file:///usr/share/icons/hicolor/128x128/apps/libreoffice-calc.png"
                                              : "file:///usr/share/icons/hicolor/128x128/apps/libreoffice-writer.png"
                                        sourceSize.width: 34; sourceSize.height: 34
                                    }
                                    ColumnLayout {
                                        Layout.fillWidth: true; spacing: 0
                                        Text { Layout.fillWidth: true; text: fila.archivo; color: ventana.t1; font.pixelSize: 14; font.weight: Font.Medium; elide: Text.ElideMiddle }
                                        Text { text: fila.detalle; color: ventana.t3; font.pixelSize: 12 }
                                    }
                                    Boton { texto: "Abrir"; fondo: ventana.azul; onPulsado: Qt.openUrlExternally("file://" + fila.ruta) }
                                }
                            }

                            // Comandos propuestos
                            Rectangle {
                                visible: fila.comandos !== ""
                                Layout.fillWidth: true
                                Layout.minimumWidth: 360
                                implicitHeight: codigo.implicitHeight + 20; radius: 10
                                color: Qt.alpha(Kirigami.Theme.textColor, 0.105)
                                Text {
                                    id: codigo
                                    x: 12; y: 10; width: parent.width - 24
                                    text: fila.comandos
                                    color: fila.peligroso ? ventana.dorado : "#b8f5a6"
                                    font.family: "Noto Sans Mono"; font.pixelSize: 13
                                    wrapMode: Text.WrapAnywhere
                                }
                            }
                            Text {
                                visible: fila.peligroso && fila.estado === "pendiente"
                                text: "⚠ Estos comandos pueden borrar datos o cambiar el sistema. Revísalos antes."
                                color: ventana.dorado; font.pixelSize: 13; wrapMode: Text.Wrap
                                Layout.maximumWidth: fila.width * 0.8 - 32
                            }
                            RowLayout {
                                visible: fila.comandos !== ""
                                spacing: 8
                                Boton {
                                    visible: fila.estado === "pendiente"
                                    texto: /apt(-get)? install|flatpak install/.test(fila.comandos) ? "Instalar" : "Ejecutar"
                                    fondo: ventana.verde; tinta: "#08240b"
                                    onPulsado: ventana.ejecutar(fila.index)
                                }
                                Boton {
                                    visible: fila.estado === "pendiente"
                                    texto: "Cancelar"; fondo: Qt.alpha(Kirigami.Theme.textColor, 0.08); borde: true
                                    onPulsado: ventana.cancelar(fila.index)
                                }
                                Text {
                                    visible: fila.estado !== "pendiente"
                                    text: fila.estado === "ejecutando" ? "Ejecutando…" : fila.estado === "hecho" ? "✓ Hecho"
                                        : fila.estado === "cancelado" ? "Cancelado" : "✗ Ha fallado"
                                    color: fila.estado === "hecho" ? ventana.verde : fila.estado === "fallo" ? ventana.dorado : ventana.t2
                                    font.pixelSize: 13
                                }
                            }
                            Text {
                                visible: fila.salida !== ""
                                text: fila.salida
                                color: ventana.t3; font.family: "Noto Sans Mono"; font.pixelSize: 12
                                wrapMode: Text.WrapAnywhere
                                Layout.maximumWidth: fila.width * 0.8 - 32
                            }
                        }
                    }
                }

                footer: Item {
                    width: lista.width
                    height: ventana.pensando ? 44 : 0
                    visible: ventana.pensando
                    Rectangle {
                        y: 14
                        width: 74; height: 36; radius: 16
                        color: Qt.alpha(Kirigami.Theme.textColor, 0.06); border.width: 1; border.color: ventana.linea
                        Row {
                            anchors.centerIn: parent
                            spacing: 6
                            Repeater {
                                model: 3
                                Rectangle {
                                    required property int index
                                    width: 7; height: 7; radius: 3.5; color: ventana.t2
                                    SequentialAnimation on opacity {
                                        loops: Animation.Infinite
                                        PauseAnimation { duration: index * 160 }
                                        NumberAnimation { from: 0.25; to: 1; duration: 320 }
                                        NumberAnimation { from: 1; to: 0.25; duration: 320 }
                                        PauseAnimation { duration: (2 - index) * 160 }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Entrada
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 52; radius: 12
                color: Qt.alpha(Kirigami.Theme.textColor, 0.066)
                border.width: 1
                border.color: campo.activeFocus ? ventana.azul : Qt.alpha(Kirigami.Theme.textColor, 0.14)
                Rectangle {
                    anchors.fill: parent; anchors.margins: -3; radius: parent.radius + 3
                    color: "transparent"; border.width: 3; border.color: Qt.rgba(47 / 255, 123 / 255, 1, 0.25)
                    visible: campo.activeFocus
                }
                RowLayout {
                    anchors.fill: parent; anchors.leftMargin: 16; anchors.rightMargin: 8
                    spacing: 10
                    Text { text: "✦"; color: ventana.azul; font.pixelSize: 18 }
                    TextField {
                        id: campo
                        Layout.fillWidth: true
                        placeholderText: "Pídeme lo que necesites…"
                        placeholderTextColor: ventana.t2
                        color: ventana.t1
                        font.pixelSize: 15
                        background: null
                        enabled: !ventana.pensando
                        onAccepted: ventana.enviar(text)
                    }
                    Rectangle {
                        implicitWidth: 36; implicitHeight: 36; radius: 10
                        color: zonaEnviar.containsMouse ? "#4a8dff" : ventana.azul
                        opacity: campo.text.trim() ? 1 : 0.5
                        Text { anchors.centerIn: parent; text: "→"; color: "white"; font.pixelSize: 18 }
                        MouseArea { id: zonaEnviar; anchors.fill: parent; hoverEnabled: true; onClicked: ventana.enviar(campo.text) }
                    }
                }
            }

            // Sugerencias
            Flow {
                Layout.fillWidth: true
                Layout.topMargin: 12
                spacing: 8
                Repeater {
                    model: ["Libera espacio", "Revisa la conexión", "Crea una hoja de gastos", "Haz una captura"]
                    Rectangle {
                        required property string modelData
                        width: chip.implicitWidth + 24; height: 30; radius: 15
                        color: zonaChip.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.09) : Qt.alpha(Kirigami.Theme.textColor, 0.05)
                        border.width: 1; border.color: ventana.linea
                        Text { id: chip; anchors.centerIn: parent; text: modelData; color: ventana.t2; font.pixelSize: 13 }
                        MouseArea { id: zonaChip; anchors.fill: parent; hoverEnabled: true; onClicked: ventana.enviar(modelData) }
                    }
                }
            }
        }
    }

    component Boton: Rectangle {
        id: b
        property string texto
        property color fondo
        property color tinta: "white"
        property bool borde: false
        signal pulsado()
        implicitWidth: et.implicitWidth + 32; implicitHeight: 36; radius: 10
        color: zonaB.containsMouse ? Qt.lighter(fondo, 1.12) : fondo
        border.width: borde ? 1 : 0; border.color: Qt.alpha(Kirigami.Theme.textColor, 0.14)
        Text { id: et; anchors.centerIn: parent; text: b.texto; color: b.tinta; font.pixelSize: 14; font.weight: Font.Medium }
        MouseArea { id: zonaB; anchors.fill: parent; hoverEnabled: true; onClicked: b.pulsado() }
    }
}
