// Centro de control (D&A): en la barra, los iconos de wifi, volumen, batería y
// notificaciones; al pulsarlos, el panel de la maqueta: notificaciones arriba y,
// debajo, wifi, Bluetooth, modo oscuro, luz nocturna, no molestar, modo avión,
// brillo, volumen, batería y perfil de energía.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami
import org.kde.plasma.networkmanagement as PlasmaNM
import org.kde.bluezqt as BluezQt
import org.kde.notificationmanager as NotificationManager

PlasmoidItem {
    id: raiz

    readonly property color t1: Kirigami.Theme.textColor
    readonly property color t2: Qt.alpha(Kirigami.Theme.textColor, 0.72)
    readonly property color t3: Qt.alpha(Kirigami.Theme.textColor, 0.55)
    readonly property color azul: "#2f7bff"
    readonly property color verde: "#5ad13b"
    readonly property color dorado: "#f2c14e"
    readonly property color relleno: Qt.alpha(Kirigami.Theme.textColor, 0.05)
    readonly property color linea: Qt.alpha(Kirigami.Theme.textColor, 0.09)

    preferredRepresentation: compactRepresentation
    switchWidth: 0; switchHeight: 0
    toolTipMainText: "Centro de control"
    toolTipSubText: (wifiActivo ? redActual : "Sin conexión") + " · Volumen " + volumen + " %" + (hayBateria ? " · Batería " + bateria + " %" : "")

    // ---------- estado ----------
    PlasmaNM.EnabledConnections { id: conexiones }
    PlasmaNM.NetworkStatus { id: estadoRed }
    PlasmaNM.Handler { id: red }
    readonly property bool wifiActivo: conexiones.wirelessEnabled
    readonly property string redActual: {
        // Plasma lo da como «Wifi: Conectado a NOMBRE»
        const t = (estadoRed.activeConnections || "").split("\n")[0]
        const c = t.indexOf("Conectado a ")
        if (c >= 0) return t.substring(c + 12)
        const i = t.indexOf(":")
        return i > 0 ? t.substring(i + 1).trim() : (t || "Sin conexión")
    }
    readonly property bool avion: PlasmaNM.Configuration.airplaneModeEnabled

    readonly property var bt: BluezQt.Manager
    readonly property bool btActivo: bt.operational && !bt.bluetoothBlocked
    readonly property string btDispositivo: bt.connectedDevices && bt.connectedDevices.length ? bt.connectedDevices[0].name : ""

    NotificationManager.Settings { id: ajustesAvisos }
    readonly property bool noMolestar: ajustesAvisos.notificationsInhibitedUntil > new Date()
    NotificationManager.Notifications {
        id: avisos
        showNotifications: true
        showJobs: false
        showExpired: true
        groupMode: NotificationManager.Notifications.GroupDisabled
        sortMode: NotificationManager.Notifications.SortByDate
        limit: 3
    }
    readonly property bool hayAvisosNuevos: avisos.unreadNotificationsCount > 0

    P5Support.DataSource {
        id: energia
        engine: "powermanagement"
        connectedSources: ["Battery", "AC Adapter"]
    }
    readonly property bool hayBateria: energia.data["Battery"] ? energia.data["Battery"]["Has Battery"] === true : false
    readonly property int bateria: energia.data["Battery"] ? energia.data["Battery"]["Percent"] || 0 : 0
    readonly property bool cargando: energia.data["AC Adapter"] ? energia.data["AC Adapter"]["Plugged in"] === true : false
    readonly property real restanteMs: energia.data["Battery"] ? energia.data["Battery"]["Remaining msec"] || 0 : 0

    property int volumen: 0
    property bool silencio: false
    property int brillo: 0
    property int brilloMax: 0
    property bool oscuro: true
    property bool luzNocturna: false
    property string perfil: "balanced"

    // Órdenes del sistema (lectura y cambios)
    P5Support.DataSource {
        id: orden
        engine: "executable"
        property var avisar: ({})
        onNewData: (fuente, datos) => {
            const f = avisar[fuente]
            disconnectSource(fuente)
            delete avisar[fuente]
            if (f) f((datos["stdout"] || "").trim())
        }
        function ejecutar(cmd, hecho) { if (hecho) avisar[cmd] = hecho; connectSource(cmd) }
    }
    function leer() {
        orden.ejecutar("wpctl get-volume @DEFAULT_AUDIO_SINK@", function (s) {
            const m = s.match(/([0-9.]+)/)
            raiz.volumen = m ? Math.round(parseFloat(m[1]) * 100) : 0
            raiz.silencio = s.indexOf("MUTED") >= 0
        })
        orden.ejecutar("qdbus6 org.kde.ScreenBrightness /org/kde/ScreenBrightness/display0 org.kde.ScreenBrightness.Display.MaxBrightness", function (s) { raiz.brilloMax = parseInt(s) || 0 })
        orden.ejecutar("qdbus6 org.kde.ScreenBrightness /org/kde/ScreenBrightness/display0 org.kde.ScreenBrightness.Display.Brightness", function (s) { raiz.brillo = parseInt(s) || 0 })
        orden.ejecutar("kreadconfig6 --file kdeglobals --group General --key ColorScheme", function (s) { raiz.oscuro = !/Light|Claro/.test(s) })
        orden.ejecutar("kreadconfig6 --file kwinrc --group NightColor --key Active", function (s) { raiz.luzNocturna = s === "true" })
        orden.ejecutar("powerprofilesctl get", function (s) { raiz.perfil = s || "balanced" })
    }
    Timer { interval: 5000; repeat: true; running: true; triggeredOnStart: true; onTriggered: raiz.leer() }
    onExpandedChanged: function () { if (expanded) { leer(); avisos.lastRead = new Date() } }

    // ---------- acciones ----------
    function cambiarWifi() { red.enableWireless(!wifiActivo) }
    function cambiarBt() {
        const activar = !btActivo
        bt.bluetoothBlocked = !activar
        for (let i = 0; i < bt.adapters.length; i++) bt.adapters[i].powered = activar
    }
    function cambiarOscuro() {
        const a = !oscuro
        // Las dos versiones de D&A Desktop; con poca RAM, el cristal sólido
        orden.ejecutar("dya-desktop " + (a ? "oscuro" : "claro"))
        oscuro = a
    }
    function cambiarLuz() {
        const a = !luzNocturna
        orden.ejecutar("sh -c 'kwriteconfig6 --file kwinrc --group NightColor --key Active " + a + "; qdbus6 org.kde.KWin /KWin reconfigure'")
        luzNocturna = a
    }
    function cambiarMolestar() {
        ajustesAvisos.notificationsInhibitedUntil = noMolestar ? new Date(0) : new Date(Date.now() + 10 * 365 * 86400000)
        if (noMolestar) ajustesAvisos.revokeApplicationInhibitions()
        ajustesAvisos.save()
    }
    function cambiarAvion() { red.enableAirplaneMode(!avion); PlasmaNM.Configuration.airplaneModeEnabled = !avion }
    function fijarBrillo(v) { brillo = v; orden.ejecutar("qdbus6 org.kde.ScreenBrightness /org/kde/ScreenBrightness/display0 org.kde.ScreenBrightness.Display.SetBrightness " + Math.round(v) + " 0") }
    function fijarVolumen(v) { volumen = v; orden.ejecutar("wpctl set-volume @DEFAULT_AUDIO_SINK@ " + (v / 100).toFixed(2) + (silencio ? " && wpctl set-mute @DEFAULT_AUDIO_SINK@ 0" : "")); silencio = false }
    function cambiarPerfil() {
        const orden2 = ["power-saver", "balanced", "performance"]
        perfil = orden2[(orden2.indexOf(perfil) + 1) % 3]
        orden.ejecutar("powerprofilesctl set " + perfil)
    }

    readonly property string iconoBateria: {
        const n = Math.max(0, Math.min(100, Math.round(bateria / 10) * 10))
        return "battery-" + String(n).padStart(3, "0") + (cargando ? "-charging" : "")
    }
    function textoRestante() {
        if (cargando) return bateria >= 100 ? "· cargada" : "· cargando"
        if (restanteMs <= 0) return ""
        const min = Math.round(restanteMs / 60000)
        return "· quedan " + Math.floor(min / 60) + " h " + (min % 60) + " min"
    }

    // ---------- iconos de la barra ----------
    compactRepresentation: MouseArea {
        id: compacto
        hoverEnabled: true
        Layout.minimumWidth: fila.implicitWidth + 12
        onClicked: raiz.expanded = !raiz.expanded
        Rectangle {
            anchors.fill: parent; anchors.margins: 3; radius: 10
            color: raiz.expanded ? Qt.alpha(Kirigami.Theme.textColor, 0.09) : (compacto.containsMouse ? raiz.relleno : "transparent")
        }
        RowLayout {
            id: fila
            anchors.centerIn: parent
            spacing: 10
            readonly property int tam: Math.min(compacto.height * 0.5, 20)
            Kirigami.Icon { source: raiz.avion ? "network-flightmode-on" : (raiz.wifiActivo ? "network-wireless-signal-good-symbolic" : "network-wireless-disconnected"); implicitWidth: fila.tam; implicitHeight: fila.tam }
            Kirigami.Icon { source: raiz.silencio ? "audio-volume-muted-symbolic" : "audio-volume-high-symbolic"; implicitWidth: fila.tam; implicitHeight: fila.tam }
            Kirigami.Icon { visible: raiz.hayBateria; source: raiz.iconoBateria; implicitWidth: fila.tam; implicitHeight: fila.tam }
            Item {
                implicitWidth: fila.tam; implicitHeight: fila.tam
                Kirigami.Icon { anchors.fill: parent; source: raiz.noMolestar ? "notifications-disabled" : "notifications" }
                Rectangle {
                    visible: raiz.hayAvisosNuevos
                    width: 7; height: 7; radius: 3.5; color: raiz.dorado
                    border.width: 1.5; border.color: Kirigami.Theme.backgroundColor
                    anchors { top: parent.top; right: parent.right; margins: -1 }
                }
            }
        }
    }

    // ---------- piezas ----------
    component Etiqueta: PC3.Label { color: raiz.t3; font.pixelSize: 12; font.weight: Font.DemiBold; font.letterSpacing: 1; font.capitalization: Font.AllUppercase }

    component Ficha: Rectangle {
        id: ficha
        property string icono
        property string titulo
        property string detalle
        property bool activa: false
        signal pulsada()
        Layout.fillWidth: true
        implicitHeight: 58
        radius: 14
        color: activa ? Qt.rgba(47 / 255, 123 / 255, 1, zonaF.containsMouse ? 0.26 : 0.18) : (zonaF.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.08) : raiz.relleno)
        border.width: 1
        border.color: activa ? Qt.rgba(47 / 255, 123 / 255, 1, 0.45) : raiz.linea
        RowLayout {
            anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 10
            spacing: 12
            Rectangle {
                implicitWidth: 36; implicitHeight: 36; radius: 18
                color: ficha.activa ? raiz.azul : Qt.alpha(Kirigami.Theme.textColor, 0.09)
                Kirigami.Icon { anchors.centerIn: parent; source: ficha.icono; implicitWidth: 18; implicitHeight: 18; color: raiz.t1; isMask: true }
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0
                PC3.Label { Layout.fillWidth: true; text: ficha.titulo; color: raiz.t1; font.pixelSize: 14; font.weight: Font.Medium; elide: Text.ElideRight }
                PC3.Label { Layout.fillWidth: true; text: ficha.detalle; color: ficha.activa ? Qt.alpha(Kirigami.Theme.textColor, 0.8) : raiz.t3; font.pixelSize: 12; elide: Text.ElideRight }
            }
        }
        MouseArea { id: zonaF; anchors.fill: parent; hoverEnabled: true; onClicked: ficha.pulsada() }
    }

    component Deslizador: RowLayout {
        id: desl
        property string icono
        property real valor: 0      // 0..1
        property string extra: ""
        signal movido(real v)
        signal icono_pulsado()
        spacing: 14
        Layout.fillWidth: true
        Kirigami.Icon {
            source: desl.icono; implicitWidth: 20; implicitHeight: 20; color: raiz.t2; isMask: true
            MouseArea { anchors.fill: parent; onClicked: desl.icono_pulsado() }
        }
        Item {
            Layout.fillWidth: true
            implicitHeight: 22
            Rectangle {
                id: pista
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width; height: 6; radius: 3
                color: Qt.alpha(Kirigami.Theme.textColor, 0.10)
                Rectangle { width: parent.width * desl.valor; height: parent.height; radius: 3; color: raiz.azul }
            }
            Rectangle {
                x: pista.width * desl.valor - width / 2
                anchors.verticalCenter: parent.verticalCenter
                width: 18; height: 18; radius: 9; color: "white"
            }
            MouseArea {
                anchors.fill: parent
                function mover(m) { desl.movido(Math.max(0, Math.min(1, m.x / width))) }
                onPressed: (m) => mover(m)
                onPositionChanged: (m) => { if (pressed) mover(m) }
            }
        }
        PC3.Label {
            visible: desl.extra !== ""
            text: desl.extra
            color: raiz.t2; font.pixelSize: 12
        }
    }

    // ---------- panel ----------
    fullRepresentation: Item {
        Layout.preferredWidth: 420
        Layout.preferredHeight: columna.implicitHeight + 12
        Layout.minimumWidth: 420
        Layout.minimumHeight: columna.implicitHeight + 12

        ColumnLayout {
            id: columna
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 4 }
            spacing: 14

            // Notificaciones
            RowLayout {
                Layout.fillWidth: true
                Etiqueta { text: "Notificaciones" }
                Item { Layout.fillWidth: true }
                PC3.Label {
                    visible: avisos.count > 0
                    text: "Borrar todo"; color: raiz.t2; font.pixelSize: 12
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: avisos.clear(NotificationManager.Notifications.ClearExpired) }
                }
            }
            PC3.Label {
                visible: avisos.count === 0
                text: raiz.noMolestar ? "No molestar está activado" : "No tienes notificaciones"
                color: raiz.t3; font.pixelSize: 13
            }
            Repeater {
                model: avisos
                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 62
                    radius: 14
                    color: raiz.relleno
                    border.width: 1; border.color: raiz.linea
                    Rectangle {
                        visible: index === 0 && raiz.hayAvisosNuevos
                        x: 6; anchors.verticalCenter: parent.verticalCenter
                        width: 4; height: 24; radius: 2; color: raiz.dorado
                    }
                    RowLayout {
                        anchors.fill: parent; anchors.leftMargin: 16; anchors.rightMargin: 12
                        spacing: 12
                        Kirigami.Icon { source: model.applicationIconName || model.iconName || "preferences-desktop-notification"; implicitWidth: 36; implicitHeight: 36 }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 0
                            PC3.Label { Layout.fillWidth: true; text: model.summary || model.applicationName || ""; color: raiz.t1; font.pixelSize: 14; font.weight: Font.Medium; elide: Text.ElideRight }
                            PC3.Label { Layout.fillWidth: true; text: (model.body || "").replace(/<[^>]*>/g, ""); color: raiz.t2; font.pixelSize: 12; elide: Text.ElideRight; maximumLineCount: 1 }
                        }
                        PC3.Label {
                            Layout.alignment: Qt.AlignTop
                            Layout.topMargin: 10
                            text: {
                                const t = model.updated || model.created
                                if (!t) return ""
                                const min = Math.floor((Date.now() - t.getTime()) / 60000)
                                return min < 1 ? "ahora" : (min < 60 ? min + " min" : Math.floor(min / 60) + " h")
                            }
                            color: raiz.t3; font.pixelSize: 11
                        }
                    }
                }
            }

            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: raiz.linea }

            // Fichas rápidas
            GridLayout {
                Layout.fillWidth: true
                columns: 2; rowSpacing: 8; columnSpacing: 8
                Ficha { icono: "network-wireless-symbolic"; titulo: "Wi-Fi"; detalle: raiz.wifiActivo ? raiz.redActual : "Desactivado"; activa: raiz.wifiActivo && !raiz.avion; onPulsada: raiz.cambiarWifi() }
                Ficha { icono: "network-bluetooth-symbolic"; titulo: "Bluetooth"; detalle: raiz.btActivo ? (raiz.btDispositivo || "Activado") : "Desactivado"; activa: raiz.btActivo; onPulsada: raiz.cambiarBt() }
                Ficha { icono: "weather-clear-night-symbolic"; titulo: "Modo oscuro"; detalle: raiz.oscuro ? "Activado" : "Desactivado"; activa: raiz.oscuro; onPulsada: raiz.cambiarOscuro() }
                Ficha { icono: "redshift-status-on"; titulo: "Luz nocturna"; detalle: raiz.luzNocturna ? "Activada" : "Desactivada"; activa: raiz.luzNocturna; onPulsada: raiz.cambiarLuz() }
                Ficha { icono: "notifications-disabled"; titulo: "No molestar"; detalle: raiz.noMolestar ? "Activado" : "Desactivado"; activa: raiz.noMolestar; onPulsada: raiz.cambiarMolestar() }
                Ficha { icono: "network-flightmode-on"; titulo: "Modo avión"; detalle: raiz.avion ? "Activado" : "Desactivado"; activa: raiz.avion; onPulsada: raiz.cambiarAvion() }
            }

            Deslizador {
                visible: raiz.brilloMax > 0
                icono: "brightness-high-symbolic"
                valor: raiz.brilloMax > 0 ? raiz.brillo / raiz.brilloMax : 0
                onMovido: (v) => raiz.fijarBrillo(Math.max(1, v * raiz.brilloMax))
            }
            Deslizador {
                icono: raiz.silencio ? "audio-volume-muted-symbolic" : "audio-volume-high-symbolic"
                valor: raiz.silencio ? 0 : raiz.volumen / 100
                extra: "Altavoces"
                onMovido: (v) => raiz.fijarVolumen(Math.round(v * 100))
                onIcono_pulsado: { orden.ejecutar("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"); raiz.silencio = !raiz.silencio }
            }

            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: raiz.linea }

            RowLayout {
                Layout.fillWidth: true
                Layout.bottomMargin: 4
                spacing: 8
                Kirigami.Icon { visible: raiz.hayBateria; source: raiz.iconoBateria; implicitWidth: 22; implicitHeight: 22 }
                PC3.Label { visible: raiz.hayBateria; text: raiz.bateria + " %"; color: raiz.t1; font.pixelSize: 13 }
                PC3.Label { visible: raiz.hayBateria; text: raiz.textoRestante(); color: raiz.t3; font.pixelSize: 12 }
                Item { Layout.fillWidth: true }
                Rectangle {
                    implicitWidth: textoPerfil.implicitWidth + 20; implicitHeight: 28; radius: 8
                    color: zonaPerfil.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.12) : Qt.alpha(Kirigami.Theme.textColor, 0.08)
                    PC3.Label {
                        id: textoPerfil
                        anchors.centerIn: parent
                        text: raiz.perfil === "performance" ? "Rendimiento" : (raiz.perfil === "power-saver" ? "Ahorro" : "Equilibrado")
                        color: raiz.t1; font.pixelSize: 12
                    }
                    MouseArea { id: zonaPerfil; anchors.fill: parent; hoverEnabled: true; onClicked: raiz.cambiarPerfil() }
                }
                Rectangle {
                    implicitWidth: 32; implicitHeight: 32; radius: 8
                    color: zonaAjustes.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.10) : "transparent"
                    Kirigami.Icon { anchors.centerIn: parent; source: "configure"; implicitWidth: 18; implicitHeight: 18 }
                    MouseArea { id: zonaAjustes; anchors.fill: parent; hoverEnabled: true; onClicked: { orden.ejecutar("systemsettings"); raiz.expanded = false } }
                }
            }
        }
    }
}
