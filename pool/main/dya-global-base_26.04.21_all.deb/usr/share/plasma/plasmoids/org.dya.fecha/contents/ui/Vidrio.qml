// Tarjeta de cristal de D&A Desktop (mismo aspecto en todos los widgets):
// azul marino en modo oscuro, blanca azulada en modo claro.
import QtQuick
import org.kde.kirigami as Kirigami

Rectangle {
    readonly property bool oscuro: Kirigami.ColorUtils.brightnessForColor(Kirigami.Theme.backgroundColor) === Kirigami.ColorUtils.Dark
    radius: 20
    border.width: 1
    border.color: oscuro ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(16 / 255, 27 / 255, 48 / 255, 0.10)
    gradient: Gradient {
        GradientStop { position: 0; color: oscuro ? Qt.rgba(36 / 255, 62 / 255, 118 / 255, 0.62) : Qt.rgba(1, 1, 1, 0.80) }
        GradientStop { position: 1; color: oscuro ? Qt.rgba(12 / 255, 24 / 255, 52 / 255, 0.78) : Qt.rgba(232 / 255, 240 / 255, 252 / 255, 0.86) }
    }
    // brillo fino en el borde superior
    Rectangle {
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: parent.radius / 2 }
        height: 1
        color: Qt.rgba(1, 1, 1, parent.oscuro ? 0.10 : 0.6)
    }
}
