/*
    Tarjeta de un widget en la galería de D&A Desktop (sustituye a la de
    Plasma; el original queda en AppletDelegate.qml.ubuntu por dpkg-divert).
    Icono en un recuadro de color, nombre y descripción, y a la derecha «+» para
    añadirlo o «✓» si ya está en el escritorio (pulsar el ✓ lo quita).
    Conserva lo de Plasma: arrastrar al escritorio, pulsar para añadir y
    desinstalar los widgets descargados.
    SPDX-FileCopyrightText: 2011 Marco Martin <mart@kde.org>
    SPDX-FileCopyrightText: 2015 Kai Uwe Broulik <kde@privat.broulik.de>
    SPDX-License-Identifier: LGPL-2.0-or-later
*/
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.core as PlasmaCore
import org.kde.kwindowsystem
import org.kde.kirigami as Kirigami

Item {
    id: delegate

    readonly property string pluginName: model.pluginName
    readonly property bool pendingUninstall: pendingUninstallTimer.applets.indexOf(pluginName) > -1
    readonly property bool pressed: tapHandler.pressed
    readonly property bool puesto: (running ?? 0) > 0
    // Color del recuadro según el tipo de widget, como en el diseño
    readonly property color tono: {
        const c = (model.category || "").toLowerCase()
        if (c.indexOf("date") >= 0 || c.indexOf("time") >= 0) return "#2f7bff"
        if (c.indexOf("system") >= 0 || c.indexOf("hardware") >= 0) return "#5ad13b"
        if (c.indexOf("multimedia") >= 0) return "#c084fc"
        if (c.indexOf("weather") >= 0 || c.indexOf("tiempo") >= 0) return "#f2c14e"
        if (c.indexOf("online") >= 0 || c.indexOf("network") >= 0) return "#38bdf8"
        if (c.indexOf("utilit") >= 0 || c.indexOf("productiv") >= 0) return "#f2c14e"
        return "#94a3b8"
    }

    width: list.cellWidth
    height: list.cellHeight

    Accessible.name: i18nc("@action:button accessible only, %1 is widget name", "Add %1", model.name)
    Accessible.description: model.description
    Accessible.role: Accessible.Button

    HoverHandler {
        id: hoverHandler
        onHoveredChanged: if (hovered) delegate.GridView.view.currentIndex = index
    }

    TapHandler {
        id: tapHandler
        enabled: !delegate.pendingUninstall && model.isSupported
        onTapped: widgetExplorer.addApplet(delegate.pluginName)
    }

    PlasmaCore.ToolTipArea {
        anchors.fill: parent
        visible: !model.isSupported
        mainText: i18nc("@info:tooltip", "Unsupported Widget")
        subText: model.unsupportedMessage
    }

    // Arrastrar al escritorio (igual que en Plasma)
    Item {
        anchors.fill: parent
        enabled: model.isSupported
        Drag.dragType: Drag.Automatic
        Drag.supportedActions: Qt.MoveAction | Qt.LinkAction
        Drag.mimeData: { "text/x-plasmoidservicename": delegate.pluginName }
        Drag.onDragStarted: { KWindowSystem.showingDesktop = true; main.draggingWidget = true; delegate.forceActiveFocus() }
        Drag.onDragFinished: main.draggingWidget = false
        DragHandler {
            id: dragHandler
            enabled: !delegate.pendingUninstall && model.isSupported
            onActiveChanged: if (active) {
                icono.grabToImage(function (result) {
                    if (!dragHandler.active) return
                    parent.Drag.imageSource = result.url
                    parent.Drag.active = dragHandler.active
                }, Qt.size(Kirigami.Units.iconSizes.huge, Kirigami.Units.iconSizes.huge))
            } else {
                parent.Drag.active = false
                parent.Drag.imageSource = ""
            }
        }
    }

    // ---------- tarjeta ----------
    Rectangle {
        anchors.fill: parent
        anchors.margins: Kirigami.Units.smallSpacing * 1.5
        radius: 14
        color: hoverHandler.hovered ? Qt.alpha(Kirigami.Theme.textColor, 0.09) : Qt.alpha(Kirigami.Theme.textColor, 0.05)
        border.width: 1
        border.color: delegate.GridView.isCurrentItem && delegate.activeFocus ? "#2f7bff" : Qt.alpha(Kirigami.Theme.textColor, 0.09)
        opacity: delegate.pendingUninstall ? 0.5 : 1

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 14; anchors.rightMargin: 12
            spacing: 14

            Rectangle {
                id: icono
                implicitWidth: 48; implicitHeight: 48; radius: 12
                color: Qt.rgba(delegate.tono.r, delegate.tono.g, delegate.tono.b, 0.16)
                border.width: 1
                border.color: Qt.rgba(delegate.tono.r, delegate.tono.g, delegate.tono.b, 0.38)
                Kirigami.Icon {
                    anchors.centerIn: parent
                    width: 28; height: 28
                    source: model.decoration
                    enabled: model.isSupported
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 1
                PlasmaComponents.Label {
                    Layout.fillWidth: true
                    text: model.name
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    font.pixelSize: 15; font.weight: Font.Medium
                    color: Kirigami.Theme.textColor
                }
                PlasmaComponents.Label {
                    Layout.fillWidth: true
                    text: model.description
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    maximumLineCount: 2; wrapMode: Text.WordWrap
                    font.pixelSize: 12
                    color: Qt.alpha(Kirigami.Theme.textColor, 0.55)
                }
            }

            // Desinstalar (solo widgets descargados)
            PlasmaComponents.ToolButton {
                visible: (model.local && hoverHandler.hovered) ?? false
                icon.name: delegate.pendingUninstall ? "edit-undo" : "edit-delete"
                display: PlasmaComponents.AbstractButton.IconOnly
                text: delegate.pendingUninstall ? "Cancelar desinstalación" : "Desinstalar"
                PlasmaComponents.ToolTip.visible: hovered
                PlasmaComponents.ToolTip.text: text
                onClicked: {
                    let pending = pendingUninstallTimer.applets
                    if (delegate.pendingUninstall) pending.splice(pending.indexOf(pluginName), 1)
                    else pending.push(pluginName)
                    pendingUninstallTimer.applets = pending
                    if (pending.length) pendingUninstallTimer.restart(); else pendingUninstallTimer.stop()
                }
            }

            // «+» añadir / «✓» ya está (pulsarlo lo quita del escritorio)
            Rectangle {
                implicitWidth: 34; implicitHeight: 34; radius: 10
                color: delegate.puesto ? (zonaAccion.containsMouse ? Qt.rgba(242 / 255, 193 / 255, 78 / 255, 0.25) : Qt.rgba(90 / 255, 209 / 255, 59 / 255, 0.14))
                                       : (zonaAccion.containsMouse ? "#4a8dff" : "#2f7bff")
                border.width: delegate.puesto ? 1 : 0
                border.color: zonaAccion.containsMouse ? "#f2c14e" : Qt.rgba(90 / 255, 209 / 255, 59 / 255, 0.4)
                PlasmaComponents.Label {
                    anchors.centerIn: parent
                    text: delegate.puesto ? (zonaAccion.containsMouse ? "✕" : "✓") : "+"
                    color: delegate.puesto ? (zonaAccion.containsMouse ? "#f2c14e" : "#5ad13b") : "white"
                    font.pixelSize: delegate.puesto ? 16 : 22
                    font.weight: Font.DemiBold
                }
                MouseArea {
                    id: zonaAccion
                    anchors.fill: parent
                    hoverEnabled: true
                    enabled: model.isSupported && !delegate.pendingUninstall
                    onClicked: delegate.puesto ? widgetExplorer.removeAllInstances(delegate.pluginName)
                                               : widgetExplorer.addApplet(delegate.pluginName)
                }
                PlasmaComponents.ToolTip.visible: zonaAccion.containsMouse
                PlasmaComponents.ToolTip.text: delegate.puesto ? "Quitar del escritorio" : "Añadir al escritorio"
            }
        }
    }
}
