/*
    Galería de widgets de D&A Desktop (sustituye a la de Plasma; el original
    queda en WidgetExplorer.qml.ubuntu por dpkg-divert). Como en el diseño:
    a la izquierda título, buscador y categorías; a la derecha la cuadrícula de
    tarjetas (AppletDelegate.qml) con «+» para añadir y «✓» si ya está puesto.
    Conserva la lógica de Plasma: categorías, búsqueda, arrastrar, «Obtener
    widgets nuevos» y desinstalar.
    SPDX-FileCopyrightText: 2011 Marco Martin <mart@kde.org>
    SPDX-License-Identifier: GPL-2.0-or-later
*/
import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Window
import QtQuick.Layouts
import org.kde.plasma.components as PC3
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.extras as PlasmaExtras
import org.kde.kwindowsystem
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.shell

PC3.Page {
    id: main

    width: Math.min(Screen.width * 0.64, Kirigami.Units.gridUnit * 68)
    height: 800

    opacity: draggingWidget ? 0.3 : 1

    readonly property int contentMargins: Kirigami.Units.largeSpacing
    readonly property color t1: Kirigami.Theme.textColor
    readonly property color t2: Qt.alpha(Kirigami.Theme.textColor, 0.72)
    readonly property color t3: Qt.alpha(Kirigami.Theme.textColor, 0.55)
    readonly property color azul: "#2f7bff"
    readonly property color linea: Qt.alpha(Kirigami.Theme.textColor, 0.09)

    property QtObject containment
    property PlasmaCore.Dialog sidePanel

    // Ver el original: evita que el panel se cierre mientras se arrastra un
    // widget o hay un menú abierto
    property bool preventWindowHide: draggingWidget || getWidgetsDialog.status !== PlasmaExtras.Menu.Closed
    onPreventWindowHideChanged: {
        if (!preventWindowHide && !sidePanel.active) {
            sidePanel.requestActivate()
        }
    }

    property bool outputOnly: draggingWidget
    property Item categoryButton
    property bool draggingWidget: false
    property string categoriaActual: "Todos los widgets"

    signal closed()

    onClosed: {
        if (root.widgetExplorer.containment &&
            root.widgetExplorer.containment.containmentType == 1 &&
            !root.widgetExplorer.containment.userConfiguring) {
            root.widgetExplorer.containment.internalAction("configure").trigger()
        }
    }

    onVisibleChanged: {
        if (!visible) {
            KWindowSystem.showingDesktop = false
        }
    }

    Component.onCompleted: {
        if (!root.widgetExplorer) {
            root.widgetExplorer = widgetExplorerComponent.createObject(root)
        }
        root.widgetExplorer.containment = main.containment
    }

    Component.onDestruction: {
        if (pendingUninstallTimer.running) {
            widgetExplorer.widgetsModel.filterQuery = ""
            widgetExplorer.widgetsModel.filterType = ""
            widgetExplorer.widgetsModel.searchTerm = ""
        } else {
            root.widgetExplorer.destroy()
            root.widgetExplorer = null
        }
    }

    function addCurrentApplet() {
        var pluginName = list.currentItem ? list.currentItem.pluginName : ""
        if (pluginName) {
            widgetExplorer.addApplet(pluginName)
        }
    }

    function elegirCategoria(nombre, datos, tipo) {
        list.contentX = 0
        list.contentY = 0
        main.categoriaActual = datos ? nombre : "Todos los widgets"
        widgetExplorer.widgetsModel.filterQuery = datos
        widgetExplorer.widgetsModel.filterType = tipo
    }

    // Icono de línea para cada categoría, según su nombre
    function iconoCategoria(nombre, datos) {
        const n = (nombre || "").toLowerCase()
        if (!datos) return "view-list-icons"
        if (n.indexOf("fecha") >= 0 || n.indexOf("hora") >= 0) return "clock"
        if (n.indexOf("sistema") >= 0 || n.indexOf("hardware") >= 0) return "cpu"
        if (n.indexOf("multimedia") >= 0) return "media-playback-start"
        if (n.indexOf("productiv") >= 0 || n.indexOf("utilidad") >= 0) return "document-edit"
        if (n.indexOf("línea") >= 0 || n.indexOf("internet") >= 0 || n.indexOf("red") >= 0) return "network-wireless"
        if (n.indexOf("lanzador") >= 0 || n.indexOf("aplicaci") >= 0) return "applications-all"
        if (n.indexOf("ventana") >= 0 || n.indexOf("tarea") >= 0) return "window"
        if (n.indexOf("tiempo") >= 0 || n.indexOf("meteor") >= 0) return "weather-few-clouds"
        if (n.indexOf("instalad") >= 0 || n.indexOf("descarg") >= 0) return "download"
        if (n.indexOf("ejecuci") >= 0 || n.indexOf("uso") >= 0) return "media-playback-playing"
        if (n.indexOf("divers") >= 0 || n.indexOf("juego") >= 0) return "applications-games"
        if (n.indexOf("accesib") >= 0) return "preferences-desktop-accessibility"
        return "folder"
    }

    QQC2.Action {
        shortcut: "Escape"
        onTriggered: {
            if (searchInput.length > 0) searchInput.text = ""
            else main.closed()
        }
    }
    QQC2.Action { shortcut: "Enter"; onTriggered: addCurrentApplet() }
    QQC2.Action { shortcut: "Return"; onTriggered: addCurrentApplet() }

    Component {
        id: widgetExplorerComponent
        WidgetExplorer {
            onShouldClose: main.closed();
        }
    }

    PlasmaExtras.ModelContextMenu {
        id: getWidgetsDialog
        visualParent: getWidgetsButton
        placement: PlasmaExtras.Menu.TopPosedLeftAlignedPopup
        onClicked: model.trigger()
    }

    Timer {
        id: setModelTimer
        interval: 20
        running: true
        onTriggered: list.model = widgetExplorer.widgetsModel
    }

    RowLayout {
        anchors.fill: parent
        anchors.topMargin: -main.sidePanel.margins.top
        anchors.leftMargin: -main.sidePanel.margins.left
        anchors.bottomMargin: -main.sidePanel.margins.bottom
        spacing: 0

        // ---------- izquierda: título, buscador y categorías ----------
        Rectangle {
            Layout.fillHeight: true
            Layout.preferredWidth: 250
            color: Qt.alpha(Kirigami.Theme.textColor, 0.036)
            Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: main.linea }

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 16
                anchors.topMargin: 22
                spacing: 14

                PC3.Label { text: "Widgets"; color: main.t1; font.pixelSize: 20; font.weight: Font.DemiBold; Layout.leftMargin: 6 }

                PlasmaExtras.SearchField {
                    id: searchInput
                    Layout.fillWidth: true
                    placeholderText: "Buscar"
                    KeyNavigation.down: list
                    onTextChanged: {
                        list.positionViewAtBeginning()
                        list.currentIndex = -1
                        widgetExplorer.widgetsModel.searchTerm = text
                    }
                    Component.onCompleted: if (!Kirigami.InputMethod.willShowOnActive) { forceActiveFocus() }
                }

                ListView {
                    id: categorias
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    spacing: 2
                    model: widgetExplorer ? widgetExplorer.filterModel : null
                    delegate: Item {
                        width: ListView.view.width
                        height: model.separator ? 13 : 40
                        readonly property bool activa: model.filterData ? main.categoriaActual === model.display : main.categoriaActual === "Todos los widgets" && !model.separator
                        Rectangle {
                            visible: model.separator === true
                            anchors.centerIn: parent
                            width: parent.width - 20; height: 1; color: main.linea
                        }
                        Rectangle {
                            visible: !model.separator
                            anchors.fill: parent
                            radius: 10
                            color: activa ? Qt.rgba(47 / 255, 123 / 255, 1, 0.16) : (zonaCat.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.06) : "transparent")
                            Rectangle { visible: activa; width: 2; height: parent.height - 12; anchors.verticalCenter: parent.verticalCenter; color: main.azul }
                            RowLayout {
                                anchors.fill: parent; anchors.leftMargin: 10; anchors.rightMargin: 10
                                spacing: 12
                                Kirigami.Icon { source: main.iconoCategoria(model.display, model.filterData); implicitWidth: 18; implicitHeight: 18; color: activa ? Kirigami.Theme.textColor : main.t2; isMask: true }
                                PC3.Label { Layout.fillWidth: true; text: model.filterData ? model.display : "Todos"; elide: Text.ElideRight; color: activa ? Kirigami.Theme.textColor : main.t2; font.pixelSize: 14 }
                            }
                            MouseArea { id: zonaCat; anchors.fill: parent; hoverEnabled: true; onClicked: main.elegirCategoria(model.display, model.filterData, model.filterType) }
                        }
                    }
                }

                Item {
                    id: getWidgetsButton
                    Layout.leftMargin: 10
                    implicitWidth: filaMas.implicitWidth; implicitHeight: filaMas.implicitHeight
                    RowLayout {
                        id: filaMas
                        spacing: 8
                        Kirigami.Icon { source: "go-next"; implicitWidth: 16; implicitHeight: 16; color: main.t2; isMask: true }
                        PC3.Label { text: "Conseguir más widgets"; color: main.t2; font.pixelSize: 13 }
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { getWidgetsDialog.model = widgetExplorer.widgetsMenuActions; getWidgetsDialog.openRelative() }
                    }
                }
            }
        }

        // ---------- derecha: cabecera, tarjetas y leyenda ----------
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: 22
            Layout.leftMargin: 26
            spacing: 18

            RowLayout {
                Layout.fillWidth: true
                ColumnLayout {
                    spacing: 2
                    PC3.Label { text: main.categoriaActual; color: main.t1; font.pixelSize: 18; font.weight: Font.DemiBold }
                    PC3.Label { text: list.count + " disponibles"; color: main.t3; font.pixelSize: 13 }
                }
                Item { Layout.fillWidth: true }
                PC3.Button {
                    visible: pendingUninstallTimer.applets.length > 0
                    icon.name: "delete"
                    text: "Desinstalar (" + pendingUninstallTimer.applets.length + ")"
                    onClicked: pendingUninstallTimer.uninstall()
                }
                Rectangle {
                    implicitWidth: 34; implicitHeight: 34; radius: 10
                    color: zonaCerrar.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.10) : Qt.alpha(Kirigami.Theme.textColor, 0.05)
                    Kirigami.Icon { anchors.centerIn: parent; source: "window-close"; implicitWidth: 16; implicitHeight: 16; color: main.t2; isMask: true }
                    MouseArea { id: zonaCerrar; anchors.fill: parent; hoverEnabled: true; onClicked: main.closed() }
                }
            }

            GridView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                activeFocusOnTab: true
                cellWidth: Math.floor(width / (width > Kirigami.Units.gridUnit * 40 ? 3 : 2))
                cellHeight: 88
                opacity: setModelTimer.running ? 0 : 1
                Behavior on opacity { OpacityAnimator { duration: Kirigami.Units.longDuration } }
                delegate: AppletDelegate {}
                highlight: null
                KeyNavigation.up: searchInput
                PC3.ScrollBar.vertical: PC3.ScrollBar {}

                PlasmaExtras.PlaceholderMessage {
                    anchors.centerIn: parent
                    width: parent.width - (Kirigami.Units.gridUnit * 4)
                    iconName: "edit-none"
                    text: searchInput.text.length > 0 ? "Ningún widget coincide con la búsqueda" : "No hay widgets disponibles"
                    visible: list.count == 0 && !setModelTimer.running
                }
            }

            RowLayout {
                spacing: 20
                RowLayout {
                    spacing: 8
                    Rectangle { implicitWidth: 18; implicitHeight: 18; radius: 6; color: main.azul }
                    PC3.Label { text: "Pulsa para añadirlo al escritorio"; color: main.t3; font.pixelSize: 13 }
                }
                RowLayout {
                    spacing: 8
                    Rectangle { implicitWidth: 18; implicitHeight: 18; radius: 6; color: Qt.rgba(90 / 255, 209 / 255, 59 / 255, 0.4) }
                    PC3.Label { text: "Ya está en tu escritorio"; color: main.t3; font.pixelSize: 13 }
                }
            }
        }
    }
}
