// Mantener pantalla encendida (D&A): un botón en la barra. Mientras está
// activado, la pantalla no se apaga ni se bloquea y el equipo no se suspende.
// Usa la misma inhibición que KDE ofrece en el widget de batería, y se
// recuerda: si el equipo se reinicia con el modo activo, sigue activo.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PC3
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.batterymonitor as BatteryMonitor

PlasmoidItem {
    id: raiz

    readonly property string motivo: "Mantener pantalla encendida (D&A)"
    readonly property bool activo: control.isManuallyInhibited

    preferredRepresentation: compactRepresentation
    toolTipMainText: activo ? "Pantalla siempre encendida" : "Mantener pantalla encendida"
    toolTipSubText: activo ? "La pantalla no se apagará ni el equipo se suspenderá. Pulsa para desactivarlo."
                           : "Pulsa para que la pantalla no se apague ni el equipo se suspenda"

    BatteryMonitor.InhibitionControl { id: control }

    function cambiar() {
        if (activo) {
            control.uninhibit()
            Plasmoid.configuration.activo = false
        } else {
            control.inhibit(motivo)
            Plasmoid.configuration.activo = true
        }
    }

    // Al arrancar la sesión se recupera el modo si estaba activo
    Timer {
        interval: 3000; running: true
        onTriggered: if (Plasmoid.configuration.activo && !control.isManuallyInhibited) control.inhibit(raiz.motivo)
    }
    // Si se cambia desde otro sitio (p. ej. el widget de batería), se recuerda igual
    onActivoChanged: if (!arrancado.running) Plasmoid.configuration.activo = activo
    Timer { id: arrancado; interval: 6000; running: true }
    // Con un atajo de teclado asignado al widget también se activa/desactiva
    onExpandedChanged: function () { if (expanded) { cambiar(); expanded = false } }

    compactRepresentation: MouseArea {
        id: boton
        hoverEnabled: true
        Layout.minimumWidth: height
        onClicked: raiz.cambiar()
        Rectangle {
            anchors.fill: parent
            anchors.margins: 3
            radius: 10
            color: raiz.activo ? Qt.alpha("#2f7bff", boton.containsMouse ? 0.45 : 0.32)
                               : (boton.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.08) : "transparent")
            border.width: raiz.activo ? 1 : 0
            border.color: Qt.alpha("#2f7bff", 0.7)
        }
        Kirigami.Icon {
            anchors.centerIn: parent
            implicitWidth: Math.min(parent.width, parent.height) * 0.5; implicitHeight: implicitWidth
            source: raiz.activo ? "system-suspend-inhibited" : "system-suspend-uninhibited"
        }
    }
    fullRepresentation: Item {}
}
