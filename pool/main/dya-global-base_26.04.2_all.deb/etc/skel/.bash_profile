[ -f ~/.bashrc ] && . ~/.bashrc
