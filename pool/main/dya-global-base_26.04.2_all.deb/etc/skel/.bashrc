# D&A Global OS — configuración de Bash para sesiones interactivas
case $- in *i*) ;; *) return;; esac

# Historial amplio y sin duplicados
HISTCONTROL=ignoreboth
HISTSIZE=10000
HISTFILESIZE=20000
shopt -s histappend checkwinsize
shopt -s globstar 2>/dev/null

# Colores de ls y grep
export LS_OPTIONS='--color=auto'
[ -x /usr/bin/dircolors ] && eval "$(dircolors -b 2>/dev/null)"
alias ls='ls --color=auto'
alias ll='ls -lh --color=auto'
alias la='ls -lha --color=auto'
alias grep='grep --color=auto'

# Prompt: usuario@equipo con color y ruta
PS1='\[\e[1;36m\]\u@\h\[\e[0m\]:\[\e[1;34m\]\w\[\e[0m\]\$ '

# Autocompletado de apt y demás
if ! shopt -oq posix; then
  [ -f /usr/share/bash-completion/bash_completion ] && . /usr/share/bash-completion/bash_completion
  [ -f /etc/bash_completion ] && . /etc/bash_completion
fi

# Sugerir el paquete cuando falta una orden
[ -x /usr/lib/command-not-found ] && command_not_found_handle() {
  /usr/lib/command-not-found -- "$1"; return $?
}
