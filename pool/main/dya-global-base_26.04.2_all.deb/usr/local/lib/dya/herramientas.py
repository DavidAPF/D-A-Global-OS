"""
herramientas — acciones que la IA de D&A Global OS ejecuta por el usuario.

En vez de limitarse a abrir una aplicación, la IA puede CREAR el resultado:
una presentación (.odp), un documento (.odt), una hoja de cálculo (.xlsx) o un
PDF, y abrirlo. El modelo redacta el contenido (en JSON) y estas funciones lo
convierten en el archivo final con bibliotecas locales (odfpy, openpyxl), sin
internet.

El asistente invoca una herramienta devolviendo en su JSON:
    "herramienta": {"nombre": "crear_presentacion", "args": {...}}
y aquí se ejecuta con ejecutar(nombre, args) -> (ok, mensaje).
"""
import os
import subprocess
import datetime


# ---------- utilidades ----------

def _carpeta_destino():
    """Carpeta donde guardar lo creado: Documentos del usuario, si existe."""
    for var in ("Documentos", "Documents"):
        ruta = os.path.join(os.path.expanduser("~"), var)
        if os.path.isdir(ruta):
            return ruta
    return os.path.expanduser("~")


def _nombre_archivo(titulo, extension):
    base = "".join(c for c in titulo if c.isalnum() or c in " -_").strip()
    base = base.replace(" ", "_")[:60] or "documento"
    marca = datetime.datetime.now().strftime("%Y%m%d-%H%M")
    return os.path.join(_carpeta_destino(), f"{base}-{marca}.{extension}")


def abrir_archivo(ruta):
    try:
        subprocess.Popen(["xdg-open", ruta],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError:
        pass


# ---------- presentación (.odp) ----------

def crear_presentacion(titulo="Presentación", diapositivas=None, **_):
    """diapositivas: lista de {"titulo": str, "puntos": [str, ...], "notas": str}.
    La primera se usa como portada si no hay puntos."""
    from odf.opendocument import OpenDocumentPresentation
    from odf.style import (Style, MasterPage, PageLayout,
                           PageLayoutProperties, TextProperties,
                           GraphicProperties, ParagraphProperties,
                           DrawingPageProperties)
    from odf.text import P, List, ListItem
    from odf.draw import Page, Frame, TextBox

    diapositivas = diapositivas or []
    doc = OpenDocumentPresentation()

    layout = PageLayout(name="dya-layout")
    doc.automaticstyles.addElement(layout)
    layout.addElement(PageLayoutProperties(
        margin="0cm", pagewidth="25.4cm", pageheight="14.29cm",
        printorientation="landscape"))

    master = MasterPage(name="dya", pagelayoutname=layout)
    doc.masterstyles.addElement(master)

    # Fondo oscuro D&A para cada diapositiva
    dp = Style(name="dp-dya", family="drawing-page")
    dp.addElement(DrawingPageProperties(
        fill="solid", fillcolor="#0a1220", transitiontype="automatic"))
    doc.automaticstyles.addElement(dp)

    # Estilo del título (grande, claro)
    est_tit = Style(name="est-titulo", family="presentation")
    est_tit.addElement(GraphicProperties(fill="none", stroke="none"))
    est_tit.addElement(ParagraphProperties(textalign="start"))
    est_tit.addElement(TextProperties(fontsize="30pt", fontweight="bold",
                                      color="#2ec4b6"))
    doc.automaticstyles.addElement(est_tit)

    # Estilo del contenido
    est_con = Style(name="est-contenido", family="presentation")
    est_con.addElement(GraphicProperties(fill="none", stroke="none"))
    est_con.addElement(TextProperties(fontsize="18pt", color="#e8eef7"))
    doc.automaticstyles.addElement(est_con)

    def anadir(titulo_d, puntos, notas=None):
        page = Page(stylename=dp, masterpagename=master)
        doc.presentation.addElement(page)
        # Título
        fr_t = Frame(stylename=est_tit, width="23cm", height="3cm",
                     x="1.2cm", y="0.8cm")
        page.addElement(fr_t)
        tb_t = TextBox()
        fr_t.addElement(tb_t)
        tb_t.addElement(P(stylename=est_tit, text=titulo_d or ""))
        # Contenido (viñetas)
        if puntos:
            fr_c = Frame(stylename=est_con, width="23cm", height="9cm",
                         x="1.2cm", y="4.2cm")
            page.addElement(fr_c)
            tb_c = TextBox()
            fr_c.addElement(tb_c)
            for p in puntos:
                tb_c.addElement(P(stylename=est_con, text="•  " + str(p)))
        if notas:
            from odf.presentation import Notes
            nt = Notes()
            page.addElement(nt)
            fr_n = Frame(width="17cm", height="5cm", x="2cm", y="12cm")
            nt.addElement(fr_n)
            tbn = TextBox()
            fr_n.addElement(tbn)
            tbn.addElement(P(text=str(notas)))

    # Portada
    anadir(titulo, [], None)
    for d in diapositivas:
        if isinstance(d, dict):
            anadir(d.get("titulo", ""), d.get("puntos", []), d.get("notas"))

    ruta = _nombre_archivo(titulo, "odp")
    doc.save(ruta)
    abrir_archivo(ruta)
    return True, f"Presentación creada: {ruta}"


# ---------- documento (.odt) ----------

def crear_documento(titulo="Documento", contenido="", **_):
    """contenido: texto plano; los saltos de línea separan párrafos y las
    líneas que empiezan por '# ' se tratan como encabezados."""
    from odf.opendocument import OpenDocumentText
    from odf.style import Style, TextProperties, ParagraphProperties
    from odf.text import H, P

    doc = OpenDocumentText()
    est_h = Style(name="EncabezadoDyA", family="paragraph")
    est_h.addElement(TextProperties(fontsize="18pt", fontweight="bold"))
    est_h.addElement(ParagraphProperties(margintop="0.4cm",
                                         marginbottom="0.2cm"))
    doc.styles.addElement(est_h)

    doc.text.addElement(H(outlinelevel=1, stylename=est_h, text=titulo))
    for linea in str(contenido).split("\n"):
        linea = linea.rstrip()
        if not linea:
            continue
        if linea.startswith("# "):
            doc.text.addElement(H(outlinelevel=2, stylename=est_h,
                                  text=linea[2:].strip()))
        else:
            doc.text.addElement(P(text=linea))

    ruta = _nombre_archivo(titulo, "odt")
    doc.save(ruta)
    abrir_archivo(ruta)
    return True, f"Documento creado: {ruta}"


# ---------- hoja de cálculo (.xlsx) ----------

def crear_hoja(titulo="Hoja", datos=None, **_):
    """datos: lista de filas (cada fila es una lista de celdas)."""
    import openpyxl
    datos = datos or []
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = (titulo or "Hoja")[:30]
    for fila in datos:
        if isinstance(fila, list):
            ws.append(fila)
        else:
            ws.append([fila])
    ruta = _nombre_archivo(titulo, "xlsx")
    wb.save(ruta)
    abrir_archivo(ruta)
    return True, f"Hoja de cálculo creada: {ruta}"


# ---------- despachador ----------

HERRAMIENTAS = {
    "crear_presentacion": crear_presentacion,
    "crear_documento": crear_documento,
    "crear_hoja": crear_hoja,
}


def ejecutar(nombre, args):
    """Ejecuta una herramienta. Devuelve (ok, mensaje)."""
    fn = HERRAMIENTAS.get(nombre)
    if not fn:
        return False, f"Herramienta desconocida: {nombre}"
    if not isinstance(args, dict):
        args = {}
    try:
        return fn(**args)
    except Exception as e:  # noqa: BLE001
        return False, f"No se pudo completar «{nombre}»: {e}"
