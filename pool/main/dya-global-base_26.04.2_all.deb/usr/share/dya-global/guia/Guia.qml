// Guía de bienvenida de D&A Global OS: funciones y atajos, en pocas páginas.
// La abre dya-bienvenida (la primera vez de cada usuario, o desde el menú).
// Al salir: código 0 = cerrada u omitida, 3 = el usuario pulsó «Instalar».
import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kirigami as Kirigami

Kirigami.ApplicationWindow {
    id: ventana
    readonly property bool enVivo: Qt.application.arguments.indexOf("--vivo") !== -1

    title: "Guía de D&A Global OS"
    width: Kirigami.Units.gridUnit * 50
    height: Kirigami.Units.gridUnit * 34
    minimumWidth: Kirigami.Units.gridUnit * 36
    minimumHeight: Kirigami.Units.gridUnit * 28
    pageStack.globalToolBar.style: Kirigami.ApplicationHeaderStyle.None

    // Contenido de cada página: icono, título, texto y filas [teclas, qué hace]
    readonly property var paginas: [
        { icono: "", titulo: "¡Bienvenido a D&A Global OS!",
          texto: "En un minuto te enseñamos lo más útil: los asistentes, los atajos de teclado y los gestos del touchpad.\n\nPuedes omitir esta guía cuando quieras y volver a verla en el menú → «Guía de D&A Global OS».",
          filas: [] },
        { icono: "dialog-messages", titulo: "Pídeselo a la IA, en español",
          texto: "Si no sabes cómo hacer algo, díselo al asistente con tus palabras y lo hace por ti. Funciona sin internet.",
          filas: [ ["Meta+A", "Asistente IA: «instálame un editor de vídeo», «créame una presentación sobre el reciclaje»"],
                   ["Meta+C", "Asistente de ciberseguridad (solo para tus equipos y redes, o con permiso)"] ] },
        { icono: "preferences-desktop-keyboard-shortcut", titulo: "Atajos de teclado",
          texto: "La tecla Meta es la del logotipo, entre Ctrl y Alt.",
          filas: [ ["Meta", "Abrir el menú (escribe para buscar)"],
                   ["Alt+Espacio", "Buscar programas, archivos o hacer cuentas"],
                   ["Meta+W", "Ver todas las ventanas abiertas"],
                   ["Alt+Tab", "Cambiar de ventana"],
                   ["Meta+D", "Mostrar el escritorio"],
                   ["Meta+← / Meta+→", "Poner la ventana en media pantalla"],
                   ["Meta+RePág", "Maximizar la ventana"],
                   ["Alt+F4", "Cerrar la ventana"],
                   ["Meta+E", "Abrir tus archivos"],
                   ["Ctrl+Alt+T", "Abrir la terminal"],
                   ["Meta+V", "Historial del portapapeles (lo último que copiaste)"],
                   ["Meta+.", "Emojis 😀"],
                   ["Meta+L", "Bloquear la pantalla"] ] },
        { icono: "media-record", titulo: "Capturas y grabar la pantalla",
          texto: "Las capturas se guardan en Imágenes y las grabaciones en Vídeos (en MP4, para abrirlas en cualquier sitio).",
          filas: [ ["Impr Pant", "Capturar toda la pantalla"],
                   ["Meta+Shift+S", "Capturar una zona"],
                   ["Meta+Impr Pant", "Capturar la ventana activa"],
                   ["Meta+R", "Grabar la pantalla (Kooha)"] ] },
        { icono: "input-touchpad", titulo: "Gestos del touchpad",
          texto: "Para el portátil, sin tocar el teclado.",
          filas: [ ["1 toque", "Clic"],
                   ["2 dedos: toque", "Clic derecho"],
                   ["2 dedos: deslizar", "Desplazarse por la página"],
                   ["2 dedos por el borde izquierdo", "Arriba sube el brillo, abajo lo baja"],
                   ["2 dedos por el borde derecho", "Arriba sube el volumen, abajo lo baja"],
                   ["Meta+Ctrl+T", "Activar o desactivar el touchpad"] ] },
        { icono: "plasmadiscover", titulo: "Programas",
          texto: "Todo listo para usar desde el primer momento.",
          filas: [ ["Discover", "La tienda: instala programas con un clic"],
                   ["Archivo .exe", "Doble clic para usar programas de Windows"],
                   ["Archivo .apk", "Doble clic para instalar apps de Android"],
                   ["Vídeos", "Se abren con mpv; la música, con Rhythmbox"],
                   ["Preferencias", "Wifi, bluetooth, sonido, impresoras y pantalla"] ] },
        { icono: "checkmark", titulo: "¡Todo listo!",
          texto: "Ya puedes empezar. Si olvidas algo, abre el menú y busca «Guía de D&A Global OS», o pregúntale a la IA con Meta+A.",
          filas: [] }
    ]

    component Tecla: Rectangle {
        property alias texto: etiqueta.text
        implicitWidth: etiqueta.implicitWidth + Kirigami.Units.largeSpacing * 2
        implicitHeight: etiqueta.implicitHeight + Kirigami.Units.smallSpacing * 2
        radius: Kirigami.Units.cornerRadius
        color: Kirigami.Theme.alternateBackgroundColor
        border.color: Kirigami.ColorUtils.linearInterpolation(
            Kirigami.Theme.backgroundColor, Kirigami.Theme.textColor, 0.25)
        QQC2.Label {
            id: etiqueta
            anchors.centerIn: parent
            font.weight: Font.DemiBold
        }
    }

    pageStack.initialPage: Kirigami.Page {
        padding: 0

        ColumnLayout {
            anchors.fill: parent
            spacing: 0

            QQC2.SwipeView {
                id: vista
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true

                Repeater {
                    model: ventana.paginas
                    delegate: QQC2.ScrollView {
                        id: hoja
                        required property var modelData
                        required property int index
                        contentWidth: availableWidth

                        ColumnLayout {
                            width: hoja.availableWidth
                            spacing: Kirigami.Units.largeSpacing

                            Item { Layout.preferredHeight: Kirigami.Units.gridUnit }

                            Kirigami.Icon {
                                Layout.alignment: Qt.AlignHCenter
                                Layout.preferredWidth: Kirigami.Units.iconSizes.huge
                                Layout.preferredHeight: Kirigami.Units.iconSizes.huge
                                source: hoja.modelData.icono || "file:///usr/share/pixmaps/dya-global.png"
                            }
                            Kirigami.Heading {
                                Layout.fillWidth: true
                                Layout.leftMargin: Kirigami.Units.gridUnit * 2
                                Layout.rightMargin: Kirigami.Units.gridUnit * 2
                                horizontalAlignment: Text.AlignHCenter
                                wrapMode: Text.WordWrap
                                level: 1
                                text: hoja.modelData.titulo
                            }
                            QQC2.Label {
                                Layout.fillWidth: true
                                Layout.leftMargin: Kirigami.Units.gridUnit * 3
                                Layout.rightMargin: Kirigami.Units.gridUnit * 3
                                horizontalAlignment: Text.AlignHCenter
                                wrapMode: Text.WordWrap
                                text: hoja.modelData.texto
                            }

                            // Sistema en vivo: instalar desde la primera página
                            Kirigami.AbstractCard {
                                visible: ventana.enVivo && hoja.index === 0
                                Layout.fillWidth: true
                                Layout.leftMargin: Kirigami.Units.gridUnit * 4
                                Layout.rightMargin: Kirigami.Units.gridUnit * 4
                                Layout.topMargin: Kirigami.Units.largeSpacing
                                contentItem: ColumnLayout {
                                    spacing: Kirigami.Units.largeSpacing
                                    QQC2.Label {
                                        Layout.fillWidth: true
                                        horizontalAlignment: Text.AlignHCenter
                                        wrapMode: Text.WordWrap
                                        text: "Estás probando el sistema sin instalarlo: nada se guarda en el disco."
                                    }
                                    QQC2.Button {
                                        Layout.alignment: Qt.AlignHCenter
                                        icon.name: "system-software-install"
                                        text: "Instalar D&&A Global OS"   // && = un & (uno solo marca la tecla de acceso)
                                        font.pointSize: Kirigami.Theme.defaultFont.pointSize * 1.3
                                        onClicked: Qt.exit(3)
                                    }
                                }
                            }

                            GridLayout {
                                visible: hoja.modelData.filas.length > 0
                                Layout.alignment: Qt.AlignHCenter
                                Layout.maximumWidth: hoja.availableWidth - Kirigami.Units.gridUnit * 4
                                Layout.topMargin: Kirigami.Units.largeSpacing
                                columns: 2
                                columnSpacing: Kirigami.Units.gridUnit
                                rowSpacing: Kirigami.Units.mediumSpacing

                                Repeater {
                                    model: hoja.modelData.filas
                                    delegate: Tecla {
                                        required property var modelData
                                        required property int index
                                        Layout.row: index
                                        Layout.column: 0
                                        Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
                                        texto: modelData[0]
                                    }
                                }
                                Repeater {
                                    model: hoja.modelData.filas
                                    delegate: QQC2.Label {
                                        required property var modelData
                                        required property int index
                                        Layout.row: index
                                        Layout.column: 1
                                        Layout.fillWidth: true
                                        Layout.maximumWidth: Kirigami.Units.gridUnit * 26
                                        wrapMode: Text.WordWrap
                                        text: modelData[1]
                                    }
                                }
                            }
                            Item { Layout.preferredHeight: Kirigami.Units.gridUnit }
                        }
                    }
                }
            }

            Kirigami.Separator { Layout.fillWidth: true }

            RowLayout {
                Layout.fillWidth: true
                Layout.margins: Kirigami.Units.largeSpacing

                QQC2.Button {
                    flat: true
                    text: "Omitir guía"
                    icon.name: "go-next-skip"
                    visible: vista.currentIndex < vista.count - 1
                    onClicked: Qt.exit(0)
                }
                Item { Layout.fillWidth: true }
                QQC2.PageIndicator {
                    count: vista.count
                    currentIndex: vista.currentIndex
                    interactive: true
                    onCurrentIndexChanged: vista.currentIndex = currentIndex
                }
                Item { Layout.fillWidth: true }
                QQC2.Button {
                    text: "Atrás"
                    icon.name: "go-previous"
                    enabled: vista.currentIndex > 0
                    onClicked: vista.decrementCurrentIndex()
                }
                QQC2.Button {
                    id: siguiente
                    readonly property bool ultima: vista.currentIndex === vista.count - 1
                    text: ultima ? "¡Empezar!" : "Siguiente"
                    icon.name: ultima ? "dialog-ok-apply" : "go-next"
                    highlighted: true
                    focus: true
                    onClicked: ultima ? Qt.exit(0) : vista.incrementCurrentIndex()
                }
            }
        }
    }
}
