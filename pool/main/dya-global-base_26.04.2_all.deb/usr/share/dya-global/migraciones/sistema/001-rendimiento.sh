# Temperatura de la CPU, protección ante falta de RAM y TRIM semanal del SSD
for s in thermald.service systemd-oomd.service fstrim.timer; do
	systemctl enable "$s" 2>/dev/null || true
done
