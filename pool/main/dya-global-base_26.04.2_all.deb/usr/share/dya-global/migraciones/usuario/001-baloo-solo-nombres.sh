# El buscador de archivos indexa solo nombres (el contenido gasta CPU y disco)
kwriteconfig6 --file baloofilerc --group General --key "only basic indexing" true
